import { log } from "util";
import { ReflectiveInjector, Injectable, EventEmitter, ViewChild, ElementRef, Renderer2 } from "@angular/core";
import { Router } from "@angular/router";
import { NgZone } from "@angular/core";
import SimpleWebRTC from "simplewebrtc";
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Rx";
import * as RecordRTC from 'recordrtc';
import { UUID } from 'angular2-uuid';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import 'rxjs/add/operator/map';
import { Message } from '@stomp/stompjs';
import { StompConfig, StompService } from '@stomp/ng2-stompjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

declare var simpleWebRTCExtObject: any;
// Mediarecorder Global variable
declare const MediaRecorder: any;

interface FileShare {
  msg: any;
  meetingId: any;
  from: any;
}

@Injectable()
export class DataServiceService {

  text: any = {};

  userDetail: any;
  loggedInUser: any;
  remoteUsers: any;
  host: any;
  session: any;
  partnerId: any;
  meetingId: any;
  contactHistory: any = [];
  payload: any = null;
  currentPartnerId: any;
  ongoingVedioPartnerId: any;
  private group: any;
  private groups: any;
  private sid: any;

  private serverUrl = "https://192.168.2.10:10391/Web_RTC/socket";
  public cloudImageUrl = "https://storage.googleapis.com/jetc-webrtc/";
  public staticUserProfilePic = "assets/images/app2.png";
  public staticGroupIcon = "assets/images/grp2.png";

  static stompClient;
  //private baseUrl = "https://backend.urssystems.com/jetc6/socket";
  private baseUrl = "https://192.168.2.10:10391/Web_RTC/";
  private multiLanguageSupport: boolean = false;
  private refreshStatusInterval: number = 5 * 1000; // user status refresh time in milliseconds

  public clientId = "my-trusted-client";
  public clientSecret = "secret";
  public sessionId: any;

  private apiKey = "AIzaSyDkBgE1t1AlxkAPtsZ6jvARhIEf8VCFuCw";
  private baseTranslationURL = "https://translation.googleapis.com/language/translate/v2";
  private cloudUploadUrl = "https://www.googleapis.com/upload/storage/v1/b/jetc-webrtc/o";
  private baseCloudUrl = "https://storage.googleapis.com/jetc-webrtc/urs199";
  private baseXirsysUrl = "https://global.xirsys.net/_turn/video-channel/";
  public fileSharing: EventEmitter<FileShare> = new EventEmitter<FileShare>();

  private mediaRecorder: any; //MediaRecorder object to be created.  

  //*****************Start******************* *//
  private sTextChats: any = {};
  private sFileShares: any = {};
  private sAudioChats: any = {};
  private sVideoChats: any = {};
  private sGroupChats: any = {};

  private connectionInProgress: any = {};
  private isAnsweringCall: boolean = false;

  //******************End****************** *//

  private FileWebRTC: any;
  public payloadForFileSharing: any;

  private friends: any = [];

  private groupPeers: any;
  private groupAnswerWaiting: any = 25000;
  private groupAnswerWaitingStatus: any = false;
  //vk
  private groupAdminStatus: any = false;

  constructor(public http: HttpClient,
    private spinnerService: Ng4LoadingSpinnerService) {
  }

  initializeWebSocketConnection() {
    let stomp_subscription = this.stompService.subscribe('/chat');
    stomp_subscription.map((message: Message) => {
      return message.body;
    }).subscribe((msg_body: string) => {
      if (msg_body && msg_body == "friendRequestRequested" || msg_body == "friendRequestAccepted") {
        return;
      }
      let chatDTOReceived = JSON.parse(msg_body);
      if (chatDTOReceived && chatDTOReceived.body) {
        // console.log("Status=>", (chatDTOReceived.body.payload.status));
        chatDTOReceived.body.payload = {
          'from': +chatDTOReceived.body.payload.from,
          'gId': +chatDTOReceived.body.payload.gId,
          'gid': +chatDTOReceived.body.payload.gid,
          'id': chatDTOReceived.body.payload.id,
          'mid': chatDTOReceived.body.payload.mid,
          'partnerId': +chatDTOReceived.body.payload.partnerId,
          'pid': +chatDTOReceived.body.payload.pid,
          'sid': chatDTOReceived.body.payload.sid,
          'status': JSON.parse(chatDTOReceived.body.payload.status),
          'to': +chatDTOReceived.body.payload.to,
          'type': chatDTOReceived.body.payload.type,
          'uid': +chatDTOReceived.body.payload.uid,
          'unreadMessage': +chatDTOReceived.body.payload.unreadMessage,
          'userId': +chatDTOReceived.body.payload.userId,
          'userStatusIcon': chatDTOReceived.body.payload.userStatusIcon,
          'username': chatDTOReceived.body.payload.username,
          'message': chatDTOReceived.body.payload.message,
          'userProfilePic': chatDTOReceived.body.payload.userProfilePic
        };
        this.onReceivingData(chatDTOReceived.body);
      } else {
        // console.log("ReceivedElsePArt=>",msg_body);
        // do something else here
      }
    });
  }

  setFriends(friendList) {
    this.friends = friendList;
  }

  getFriends() {
    return this.friends;
  }

  getFriendById(friendId) {
    if (this.friends && this.friends.length > 0)
      for (let index = 0; index < this.friends.length; index++) {
        if (friendId == this.friends[index].userId) {
          return this.friends[index];
        }
      }
    return null;
  }

  searchUsers(searchTerm, loggedInUserId, pageNo, pageSize) {
    return this.http.get(this.baseUrl + "urs/people/" + searchTerm + "/" + loggedInUserId + "/" + pageNo + "/" + pageSize, {});
  }

  addNewFriends(friendList, loggedInUserId) {
    return this.http.post(this.baseUrl + "urs/friends/" + loggedInUserId, friendList, {});
  }

  getFriendList(loggedInUserId) {
    return this.http.get(this.baseUrl + "urs/friends/" + loggedInUserId, {});
  }

  acceptFriendRequest(loggedInUserId, partnerId) {
    return this.http.get(this.baseUrl + "urs/friends/activate/" + loggedInUserId + "/" + partnerId, {});
  }

  cancelFriendRequest(loggedInUserId, partnerId) {
    return this.http.get(this.baseUrl + "urs/friends/reject/" + loggedInUserId + "/" + partnerId, {});
  }

  doUnfriend(loggedInUserId, partnerId) {
    return this.http.get(this.baseUrl + "urs/friends/unfriend/" + loggedInUserId + "/" + partnerId, {});
  }

  addMemberToGroup(groupId, users): any {
    let Params = new HttpParams();
    Params = Params.append("groupId", groupId);
    return this.http.post(this.baseUrl + "urs/group/add/member/", users, { params: Params });
  }

  doUserRegistration(userInfo): any {
    return this.http.post(this.baseUrl + "registration/guest/", userInfo, {});
  }

  disableGuestUser(userId) {
    return this.http.put(this.baseUrl + "urs/disable/guest/" + userId, {});
  }


  saveUserImageData(filename, userId) {
    return this.http.put(this.baseUrl + "urs/user/images/" + userId + "/file/" + filename, {});
  }

  updateUserInfo(userDTO) {
    console.log("userDTO==>", userDTO);
    return this.http.put(this.baseUrl + "urs/user/info", userDTO, {});
  }

  forgotPassword(email) {
    console.log("Calling Backend==>", email);

    let Params = new HttpParams();
    Params = Params.append("email", email);
    return this.http.post(this.baseUrl + "forgot/password/", {}, { responseType: 'text', params: Params });
  }

  setNewPassword(password, userId, token): any {
    let Params = new HttpParams();
    Params = Params.append("userId", userId);
    Params = Params.append("password", password);
    Params = Params.append("token", token);

    return this.http.post(this.baseUrl + "reset/password/", {}, { responseType: 'text', params: Params });
  }

  deleteSelectedUserImages(userId, imageList) {
    return this.http.put(this.baseUrl + "urs/user/profile/delete/image/" + userId, imageList);
  }

  // private currentGroupDetail: any;
  // private groupStatesubscription: any;

  // setCurrentGroup(group) {
  //   this.currentGroupDetail = group;
  // }

  // getCurrentGroup(): any {
  //   return this.currentGroupDetail;
  // }

  // keepGroupAlive() {
  //   console.log("Keep Group Alive.....RefreshInterval =>", this.refreshStatusInterval);
  //   let timer = Observable.timer(0, this.refreshStatusInterval);
  //   this.groupStatesubscription = timer.subscribe((data) => {
  //     //service to activate group chat
  //     let group = this.getCurrentGroup();
  //     console.log("Calling to keep group alive ->", group);
  //     if (group && group.type && group.type != "Undefined") {
  //       this.activateGroupChat(group.id, group.type, group.status).subscribe(
  //         (res) => {
  //           console.log("Backend Updated",res);
  //         }, (err) => {
  //           console.log("GroupAlive Err=>",err);
  //         }
  //       );
  //     }
  //   });
  //   return this.groupStatesubscription;
  // }

  //vk
  setGroupAdminStatus(status) {
    this.groupAdminStatus = status;
    // console.log("admin.............", status);
  }

  getGroupAdminStatus() {
    return this.groupAdminStatus;
  }

  //--Modification start Prem--

  isMultiLanguageSupported() {
    return this.multiLanguageSupport;
  }

  getRefreshStatusInterval(): any {
    return this.refreshStatusInterval;
  }

  getUserStatus(): any {
    return this.http.get(this.baseUrl + "urs/userstatus/");
  }

  getUserById(id) {
    return this.http.get(this.baseUrl + "urs/user/" + id);
  }

  updateUserStatus(userId, statusId) {
    return this.http.put(this.baseUrl + "urs/user/" + userId + "/status/" + statusId, {});
  }

  activateGroupChat(groupdId, type, status) {
    //console.log("UpdateGroup=>", groupdId, type, status);
    return this.http.put(this.baseUrl + "urs/group/" + groupdId + "/type/" + type + "/status/" + status, {});
  }

  //for video call
  setOngoingVedioPartenerId(id: any) {
    this.ongoingVedioPartnerId = id;
  }

  getOngoingVedioPartenerId() {
    return this.ongoingVedioPartnerId;
  }

  //--Modofication End Prem--

  setGroupPeers(peers) {
    this.groupPeers = peers;
  }

  getGroupPeers() {
    return this.groupPeers;
  }

  setGroupAnswerWaitingStatus(status) {
    this.groupAnswerWaitingStatus = status;
  }

  sendStopEvents(type, obj) {
    this.sendInfo(type, obj);
  }

  stopChat(type, status, isPeerCaller) {
    this.fileSharing.emit({
      msg: type,
      meetingId: status,
      from: isPeerCaller
    });
  }

  // Der start
  setAnsweringCall(isAnswering) {
    this.isAnsweringCall = isAnswering;
  }

  setconnectionInProgress(typeOfConenction) {
    this.connectionInProgress[this.currentPartnerId] = { "currentConn": typeOfConenction };
  }

  getCurrentConnection() {
    return this.connectionInProgress[this.currentPartnerId];
  }

  getBaseUrl() {
    return this.baseUrl;
  }

  getGroupUsers(): any {
    return this.http.get(this.baseUrl + "urs/users/" + this.loggedInUser.uid);
  }

  createGroupService(obj): Observable<any> {
    console.log(obj);
    return null//this.http.post(this.baseUrl + "urs/groups", obj, {});
  }

  getGroup(id) {
    if (this.groups) {
      for (let i = 0; i < this.groups.length; i++) {
        if (this.groups[i].id === id) {
          return this.groups[i];
        }
      }
    }
  }

  setGroup(group) {
    //console.log("Comming soon.....");
  }

  getGroups() {
    return this.groups;
  }

  setGroups(groups) {
    this.groups = groups;
  }

  getPayload(): any {
    return this.payload;
  }

  getUserGroups(id): any {
    return this.http.get(this.baseUrl + "urs/groups/" + id);
  }

  muteAll(peers, muteStatus) {
    let peersArray = [];
    for (let i = 0; i < peers.length; i++) {
      peersArray.push({ "id": peers[i].id, "sid": peers[i].sid });
    }

    if (muteStatus)
      this.sendInfo("mute", { message: JSON.stringify(peersArray) });
    else
      this.sendInfo("unmute", { message: JSON.stringify(peersArray) });
  }


  stopAllScreens(peers, screenStatus) {
    let peersArray = [];
    for (let i = 0; i < peers.length; i++) {
      peersArray.push({ "id": peers[i].id, "sid": peers[i].sid });
    }

    if (screenStatus)
      this.sendInfo("stop_screen", { message: JSON.stringify(peersArray) });
    else
      this.sendInfo("share_screen", { message: JSON.stringify(peersArray) });
  }

  closebaseWebRTC() {
    this.stompService.disconnect();
    this.friends = [];
    console.log("baseWebRTC has been destroyed !!");
  }

  getStompService() {
    if (this.stompService) {
      return this.stompService
    }
    return null;
  }


  private stompService: any;

  afterLogin(user, peerConnectionConfigg) {

    const stompConfig: StompConfig = {
      url: new SockJS('https://192.168.2.10:10391/Web_RTC/socket'),
      headers: {
        userId: user.uid,
        username: user.username,
        authorities: user.authorities
      },
      heartbeat_in: 0,
      heartbeat_out: 20000,
      reconnect_delay: 3000,
      debug: false
    };
    this.stompService = new StompService(stompConfig);

    this.stompService.connectObservable.subscribe((status: string) => {
      console.log(`Stomp connection status ::`, status);
      this.fileSharing.emit({
        msg: "websocketconnection",
        meetingId: "",
        from: null
      });
      this.initializeWebSocketConnection();
    });

    let userProfilePic = undefined;

    if (user.userImages && user.userImages.length > 0) {
      user.userImages.forEach(element => {
        if (element.selectedAsDP) {
          userProfilePic = this.cloudImageUrl + element.imageName;
        }
      });
    } else {
      userProfilePic = this.staticUserProfilePic;
    }
    if (!userProfilePic) {
      userProfilePic = this.staticUserProfilePic;
    }
  }

  onReceivingData(data) {
    // console.log("onReceivingData => ", data);

    if (data.type === "StopAudio") {
      console.log("Data Service Closing audio", data)

      if (data.payload.gid) {
        let group = this.getGroup(data.payload.gid);
        this.setCurrentGroupId(data.payload.gid);
        if (group && group.users) {
          for (let i = 0; i < group.users.length; i++) {
            if (group.users[i].userId === this.loggedInUser.uid) {

              if (data.payload.uid === this.loggedInUser.uid) {
                if (!data.payload.status) {
                  this.groupAnswerWaitingStatus = true;
                  this.stopChat(data.type, false, false);
                }
                if (!this.groupAnswerWaitingStatus) {
                  this.groupAnswerWaitingStatus = true;
                  setTimeout(() => {
                    if (!(this.groupPeers && this.groupPeers.type === "audio" && this.groupPeers.peers.length > 0)) {
                      this.stopChat(data.type, true, false);
                    }
                  }, this.groupAnswerWaiting);
                }
              }
              else if (data.payload.type === "self") {
                this.stopChat(data.type, data.payload.status, false);
              }
              break;
            }
          }
        }
      } else if (data.payload.pid === this.loggedInUser.uid) {

        this.stopChat(data.type, data.payload.status, true);
      }
    } else if (data.type === "StopVideo") {
      if (data.payload.gid) {
        let group = this.getGroup(data.payload.gid);
        this.setCurrentGroupId(data.payload.gid);
        if (group && group.users) {
          for (let i = 0; i < group.users.length; i++) {
            if (group.users[i].userId === this.loggedInUser.uid) {
              if (data.payload.uid === this.loggedInUser.uid) {
                if (!data.payload.status) {
                  this.groupAnswerWaitingStatus = true;
                  this.stopChat(data.type, false, false);
                }
                if (!this.groupAnswerWaitingStatus) {
                  this.groupAnswerWaitingStatus = true;
                  setTimeout(() => {
                    if (!(this.groupPeers && this.groupPeers.type === "video" && this.groupPeers.peers.length > 0)) {
                      this.stopChat(data.type, true, false);
                    }
                  }, this.groupAnswerWaiting);
                }
              } else if (data.payload.type === "self") {
                this.stopChat(data.type, data.payload.status, false);
              }
              break;
            }
          }
        }
      } else if (data.payload.pid === this.loggedInUser.uid) {
        this.stopChat(data.type, data.payload.status, true);
      }
    } else if (data.type === "StopScreen") {
      if (data.payload.gid) {
        let group = this.getGroup(data.payload.gid);
        this.setCurrentGroupId(data.payload.gid);
        if (group && group.users) {
          for (let i = 0; i < group.users.length; i++) {
            if (group.users[i].userId === this.loggedInUser.uid) {
              if (data.payload.uid === this.loggedInUser.uid) {
                if (!data.payload.status) {
                  this.groupAnswerWaitingStatus = true;
                  this.stopChat(data.type, false, false);
                }
                if (!this.groupAnswerWaitingStatus) {
                  this.groupAnswerWaitingStatus = true;
                  setTimeout(() => {
                    if (!(this.groupPeers && this.groupPeers.type === "screen" && this.groupPeers.peers.length > 0)) {
                      this.stopChat(data.type, true, false);
                    }
                  }, this.groupAnswerWaiting);
                }
              } else if (data.payload.type === "self") {
                this.stopChat(data.type, data.payload.status, false);
              }
              break;
            }
          }
        }
      } else if (data.payload.pid === this.loggedInUser.uid) {
        this.stopChat(data.type, data.payload.status, true);
      }
    } else if (data.type === "mute") {
      this.fileSharing.emit({
        msg: "mute",
        meetingId: "",
        from: JSON.parse(data.payload.message)
      });
    } else if (data.type === "unmute") {
      this.fileSharing.emit({
        msg: "unmute",
        meetingId: "",
        from: JSON.parse(data.payload.message)
      });
    } else if (data.type === "stop_screen") {
      console.log("screen event ... ", data.payload);
      this.fileSharing.emit({
        msg: "stop_screen",
        meetingId: "",
        from: JSON.parse(data.payload.message)
      });
    } else if (data.type === "share_screen") {
      this.fileSharing.emit({
        msg: "share_screen",
        meetingId: "",
        from: JSON.parse(data.payload.message)
      });
    } else if (data.type === "group") {
      if (data.payload.type === "screen") {
        let group = this.getGroup(data.payload.gId);
        this.setCurrentGroupId(data.payload.gId);
        if (group && group.users) {
          for (let i = 0; i < group.users.length; i++) {
            if (group.users[i].userId === this.loggedInUser.uid) {
              this.fileSharing.emit({
                msg: "AnswerGroupScreen",
                meetingId: "Screen_" + group.name,
                from: data.payload.userId
              });
              //console.log("Recieve Screen Event log.");
            }
          }
        }
      } else if (data.payload.type === "audio") {
        let group = this.getGroup(data.payload.gId);
        this.setCurrentGroupId(data.payload.gId);
        if (group && group.users) {
          for (let i = 0; i < group.users.length; i++) {
            if (group.users[i].userId === this.loggedInUser.uid) {
              this.fileSharing.emit({
                msg: "AnswerGroupAudio",
                meetingId: "Audio_" + group.name,
                from: data.payload.userId
              });
              //console.log("Recieve Audio Event log.");
            }
          }
        }
      }
      //----new group file share method
      else if (data.payload.type === "file") {
        if (data.payload.from != this.loggedInUser.uid) {
          let group = this.getGroup(data.payload.gId);
          this.setCurrentGroupId(data.payload.gId);
          if (group && group.users) {
            for (let i = 0; i < group.users.length; i++) {
              if (group.users[i].userId === this.loggedInUser.uid) {
                this.payloadForFileSharing = data;
                // this.fileSharing.emit({
                //   msg: "ReceivedFile",
                //   meetingId: data.payload,
                //   from: data.payload.userId
                // });
              }
            }
          }
        }
      }
      //----
      else if (data.payload.type === "video") {
        let group = this.getGroup(data.payload.gId);
        this.setCurrentGroupId(data.payload.gId);
        if (group && group.users) {
          for (let i = 0; i < group.users.length; i++) {
            if (group.users[i].userId === this.loggedInUser.uid) {
              this.fileSharing.emit({
                msg: "AnswerGroupVideo",
                meetingId: "Video_" + group.name,
                from: data.payload.userId
              });
              //console.log("Recieve Video Event log.");
            }
          }
        }
      } else if (data.payload && data.payload.type === "text" && data.payload.from != this.loggedInUser.uid) {
        let group = this.getGroup(data.payload.gId);
        if (group && group.users) {
          for (let i = 0; i < group.users.length; i++) {
            if (group.users[i].userId === this.loggedInUser.uid) {
              if (!this.sGroupChats[data.payload.gId]) {
                this.setSGroupTextChats(data.payload.gId, data.payload.from);
              }
              if (this.sGroupChats[data.payload.gId]) {
                this.sGroupChats[data.payload.gId].messages.push({
                  timeStamp: "" + Date.now(),
                  message: data.payload,
                  from: data.payload.from
                });
              }
              break;
            }
          }
        }
      }
    } else if (data.type === "meet") {
      if (data.payload.type === "text") {
        if (data.payload.partnerId === this.loggedInUser.uid) {
          this.setSTextChats("", data.payload.partnerId);
          this.payload = data.payload;
          //console.log("Recieve Text Event log msg");
        }
      } else if (data.payload.type === "file") {
        if (data.payload.partnerId === this.loggedInUser.uid) {
          this.payloadForFileSharing = data;
          //console.log("Do File Sharing Here..");
          //this.receiveFileSharing();
          // this.fileSharing.emit({
          //   msg: "ReceivedFile",
          //   meetingId: data.payload,
          //   from: data.payload.userId
          // });
        }
      } else if (data.payload.type === "video") {
        if (data.payload.partnerId === this.loggedInUser.uid) {
          this.fileSharing.emit({
            msg: "AnswerVideo",
            meetingId: data.payload.mid,
            from: data.payload.userId
          });
          //console.log("Recieve Video Event log.");
        }
      } else if (data.payload.type === "screen") {
        if (data.payload.partnerId === this.loggedInUser.uid) {
          this.fileSharing.emit({
            msg: "ShareScreen",
            meetingId: data.payload.mid,
            from: data.payload.userId
          });
          //console.log("Recieve Video Event log.");
        }
      } else if (data.payload.type === "audio") {
        if (data.payload.partnerId === this.loggedInUser.uid) {
          this.fileSharing.emit({
            msg: "AnswerAudio",
            meetingId: data.payload.mid,
            from: data.payload.userId
          });
          //console.log("Recieve Audio Event log.");
        }
      }
    } else if (data && data.type === "text") {
      if (data.payload.to === this.loggedInUser.uid) {
        if (!this.sTextChats[data.payload.from]) {
          this.setSTextChats("", data.payload.from);
        }
        if (this.sTextChats[data.payload.from]) {
          this.sTextChats[data.payload.from].messages.push({
            timeStamp: "" + Date.now(),
            message: data.payload
          });

          this.fileSharing.emit({
            msg: "updateTextChat",
            meetingId: "updateTextChat",
            from: data.payload.userId
          });
        }
      }
    }
  }

  // -------- group-chat ------start-----------//
  private currentGroupId: any;

  setCurrentGroupId(groupID) {
    this.currentGroupId = groupID;
  }

  getCurrGroupID() {
    return this.currentGroupId;
  }

  sendGroupTextMessage(gid, msg) {
    let loggedInUserProfilePic = this.getUserProficPic();
    this.sendInfo('group', {
      message: msg,
      from: this.loggedInUser.uid,
      username: this.loggedInUser.username,
      userProfilePic: loggedInUserProfilePic,
      gId: gid,
      type: 'text'
    });
    // this.baseWebRTC.sendToAll('group', {
    //   message: msg,
    //   from: this.loggedInUser.uid,
    //   username: this.loggedInUser.username,
    //   gId: gid,
    //   type: 'text'
    // });
    if (!this.sGroupChats[gid]) {
      this.setSGroupTextChats(gid, this.loggedInUser.uid);
    }
    this.updateGroupChatMessages(msg, gid, this.loggedInUser.uid);
  }

  updateGroupChatMessageWithFile(message, groupId, sender, file) {
    if (this.sGroupChats[groupId]) {
      this.sGroupChats[groupId].messages.push(
        {
          timeStamp: "" + Date.now(),
          message: {
            message: message,
            from: sender,
            to: groupId,
            username: sender,
            file: file
          }
        }
      );
    } else {
      this.sGroupChats[groupId] = {
        messages: []
      };
      this.sGroupChats[groupId].messages.push({
        timeStamp: "" + Date.now(),
        message: {
          message: message,
          from: sender,
          to: groupId,
          username: sender,
          file: file
        }
      });
    }
  }

  updateGroupChatMessages(message, groupId, senderId) {
    if (this.sGroupChats[groupId]) {
      this.sGroupChats[groupId].messages.push(
        {
          timeStamp: "" + Date.now(),
          message: {
            message: message,
            from: senderId,
            to: groupId,
            username: "",
            file: undefined
          }
        }
      );
    } else {
      console.log(" ===>>>> Restiing the message array .... 811 ");

      this.sGroupChats[groupId] = {
        messages: []
      };
      this.sGroupChats[groupId].messages.push({
        timeStamp: "" + Date.now(),
        message: {
          message: message,
          from: senderId,
          to: groupId,
          username: this.loggedInUser.username,
          file: undefined
        }
      });
    }
  }


  // updateGroupChatMessages(message, groupId, senderId) {
  //   if (this.sGroupChats[groupId]) {
  //     this.sGroupChats[groupId].messages.push({
  //       timeStamp: "" + Date.now(),
  //       message: {
  //         message: message,
  //         from: senderId,
  //         to: groupId
  //       }
  //     });
  //   } else {
  //     this.sGroupChats[groupId] = {
  //       messages: []
  //     };
  //     this.sGroupChats[groupId].messages.push(message);
  //   }
  // }

  setSGroupTextChats(groupID, senderId) {
    if (this.sGroupChats[groupID]) {
      return;
    }
    console.log(" ===>>>> Reseting the message array .... 849 ");
    this.sGroupChats[groupID] = {
      messages: []
    };
  }

  getSGroupTextChats(groupID) {
    if (this.sGroupChats.hasOwnProperty(groupID)) {
      return this.sGroupChats[groupID];
    }
    return null;
  }
  // -------- group-chat ------end-----------//



  setUserSession(uid, pid) {
    this.session = {
      userId: uid,
      partnerId: pid
    };
  }

  getUserSession(): any {
    return this.session;
  }

  testSpecificUser(message) {
    this.stompService.publish('/app/user/specific/message', JSON.stringify(message));
  }

  sendInfo(type, obj) {
    //console.log("sendInfo OBJ =>", obj);
    //console.log("Info message Sent !!");
    this.stompService.publish('/app/send/message', JSON.stringify({ type: type, payload: obj }));
    // this.baseWebRTC.sendToAll(type, obj);
  }

  getCurrentPartnerId() {
    return this.currentPartnerId;
  }

  setCurrentPartnerId(partnerId) {
    this.currentPartnerId = partnerId;
  }
  startTextChat(partnerId) {
    if (!partnerId) {
      return;
    }
    // this.currentPartnerId = partnerId;
    this.payload = null;

    let userId = this.loggedInUser.uid;
    let partnerFound = false;
    this.meetingId = "" + Date.now();
    let Session = {
      userId: userId,
      partnerId: partnerId,
      meetingId: this.meetingId
    };

    if (this.contactHistory.length == 0) {
      this.contactHistory.push(Session);
    } else {
      partnerFound = false;
      for (let i = 0; i < this.contactHistory.length; i++) {
        if (this.contactHistory[i].partnerId === partnerId) {
          console.log(
            "Same partner. Previous Meeting Id->",
            this.contactHistory[i].meetingId
          );
          this.meetingId = this.contactHistory[i].meetingId;
          partnerFound = true;
          break;
        }
      }
      if (!partnerFound) {
        this.contactHistory.push(Session);
      }
    }

    this.setMeetingId(this.meetingId);
    this.sendInfo("meet", {
      userId: userId,
      partnerId: partnerId,
      mid: this.meetingId,
      username: this.getLoggedInUser().username
    });
    this.setSTextChats("", partnerId);
  }

  startVideoChatting(isPeerCaller) {
    let userId = this.loggedInUser.uid;
    let partnerId = this.currentPartnerId;
    let meetingId = "video" + Date.now();

    if (isPeerCaller) {
      if (!this.isAnsweringCall) {
        this.sendInfo("meet", {
          userId: userId,
          partnerId: partnerId,
          mid: meetingId,
          username: this.getLoggedInUser().username,
          type: "video"
        });
      }
    } else {
      this.sendInfo("group", {
        userId: userId,
        gId: this.getCurrGroupID(),
        username: this.getLoggedInUser().username,
        type: "video"
      });
    }
    return meetingId;
  }



  startAudioChatting(isPeerCaller): any {
    let userId = this.loggedInUser.uid;
    let partnerId = this.currentPartnerId;
    let meetingId = "Audio" + Date.now();

    if (isPeerCaller) {
      if (!this.isAnsweringCall) {
        this.sendInfo("meet", {
          userId: userId,
          partnerId: partnerId,
          mid: meetingId,
          username: this.getLoggedInUser().username,
          type: "audio"
        });
      }
    } else {
      this.sendInfo("group", {
        userId: userId,
        gId: this.getCurrGroupID(),
        username: this.getLoggedInUser().username,
        type: "audio"
      });
    }
    return meetingId;
  }

  startScreenSharing(isPeerCaller): any {
    let userId = this.loggedInUser.uid;
    let partnerId = this.currentPartnerId;
    console.log("startScreenSharing - partnerId : ", partnerId);
    let meetingId = "Screen_" + Date.now();

    if (isPeerCaller) {
      this.sendInfo("meet", {
        userId: userId,
        partnerId: partnerId,
        mid: meetingId,
        username: this.getLoggedInUser().username,
        type: "screen"
      });
    } else {
      this.sendInfo("group", {
        userId: userId,
        gId: this.getCurrGroupID(),
        username: this.getLoggedInUser().username,
        type: "screen"
      });
    }
    return meetingId;
  }

  setMeetingId(meetingId) {
    this.meetingId = meetingId;
  }

  getMeetingId(): any {
    return this.meetingId;
  }



  doLogin(username, password): Observable<any> {
    let Params = new HttpParams();
    Params = Params.append("grant_type", "password");
    Params = Params.append("username", username);
    Params = Params.append("password", password);

    return this.http.post(
      this.baseUrl + "oauth/token",
      {},
      {
        headers: new HttpHeaders().set(
          "Authorization",
          "Basic " + btoa(this.clientId + ":" + this.clientSecret)
        ),
        params: Params
      }
    );
  }

  //Get the Xirsys servers.
  getTurnServers(): Observable<any> {
    //console.log("Xirsys Calls for turn servers");
    //  var room = UUID.UUID();

    // // This object will take in an array of XirSys STUN / TURN servers
    // // and override the original peerConnectionConfig object
    // var peerConnectionConfig;

    //       var x_data = {
    //                   ident: "shashankasthana"
    //                   , secret: "772c5554-dfda-11e7-b50c-2b393d987705"
    //                   , domain: "Domain"
    //                   , application: "Application"
    //                   , secure: 1
    //               };
    //if no room defined default into 'default' room
    //         x_data.room = room != null && room.length > 0 ? room : 'default';

    //    $.ajax ({
    //      url: "https://global.xirsys.net/_turn/video-channel/",
    //      type: "PUT",
    //      async: false,
    //      headers: {
    //        "Authorization": "Basic " + btoa("shashankasthana:772c5554-dfda-11e7-b50c-2b393d987705")
    //      },
    //      success: function (res){
    //          //console.log(res);
    //          peerConnectionConfig = res.v;
    //             if(peerConnectionConfig !=null){
    //                 start(peerConnectionConfig);
    //             }else{
    //                 //console.log('/ice error - ', res);
    //             }
    //        //console.log("ICE List: "+res.v.iceServers);
    //      }
    //  });





    let Params = new HttpParams();
    // Begin assigning parameters
    // Params = Params.append("grant_type", "password");
    // Params = Params.append("username", username);
    // Params = Params.append("password", password);

    return this.http.put(
      this.baseXirsysUrl,
      {},
      {
        headers: new HttpHeaders().set(
          "Authorization",
          "Basic " + btoa("shashankasthana:772c5554-dfda-11e7-b50c-2b393d987705")
        ),
        params: Params
      }
    );
  }

  setRemoteUsers(users) {
    this.remoteUsers = users;
    //console.log("remote USers -", this.remoteUsers);
  }

  setLoggedInUser(response) {
    localStorage.setItem('token', response);
    this.loggedInUser = JSON.parse(response);
  }

  getLoggedInUser(): any {
    if (localStorage.getItem('token')) {
      this.loggedInUser = JSON.parse(localStorage.getItem('token'));
    }
    return this.loggedInUser;
    //return localStorage.getItem('token');
  }


  // setLoggedInUser(response) {
  //   this.loggedInUser = JSON.parse(response);
  //   //console.log(this.loggedInUser.uid);
  // }

  // getLoggedInUser(): any {
  //   return this.loggedInUser;
  // }





  getUser(id) {
    let isUserOnline: boolean = false;
    // console.log("userList==>", this.userList);
    // for (let i = 0; i < this.userList.length; i++) {
    //   if (id === this.userList[i].userId) {
    //     isUserOnline = true;
    //     this.userDetail = this.userList[i];
    //   }
    // }
    // console.log("Online??->", isUserOnline);
    if (!isUserOnline && this.userDetail) {
      this.friends.forEach(element => {
        if (element.userId === id) {
          console.log("Offline User =>", element);
          this.userDetail.username = element.firstName + " " + element.lastName;
          this.userDetail.userStatusIcon = element.userStatus.userStatusIcon;
          if (element.userImages)
            element.userImages.forEach(image => {
              if (image.selectedAsDP) {
                this.userDetail.userProfilePic = this.cloudImageUrl + image.imageName;
              }
            });
        }
      });
    }
    return this.userDetail;
  }

  fetchUser(id) {
    for (let i = 0; i < this.remoteUsers.length; i++) {
      if (id === this.remoteUsers[i].userId) {
        this.userDetail = this.remoteUsers[i];
      }
    }
    return this.userDetail;
  }

  // *******************Start*********************************//

  sendTextMessage(message, partnerId) {
    //console.log("Sending the text message ===>", message);
    this.sendInfo("text", {
      message: message,
      from: this.loggedInUser.uid,
      to: partnerId,
      username: this.loggedInUser.username,
      type: "text"
    });
    // this.baseWebRTC.sendToAll("text", {
    //   message: message,
    //   from: this.loggedInUser.uid,
    //   to: partnerId,
    //   username: this.loggedInUser.username
    // });

    if (!this.sTextChats[partnerId]) {
      this.setSTextChats("" + Date.now(), partnerId);
    }

    this.updateChatMessages(message, partnerId);

    this.fileSharing.emit({
      msg: "updateTextChat",
      meetingId: "updateTextChat",
      from: this.loggedInUser.uid
    });
  }

  getUserProficPic(): any {
    let loggedInUserProfilePic = undefined;
    if (this.loggedInUser.userImages) {
      this.loggedInUser.userImages.forEach(element => {
        if (element.selectedAsDP) {
          loggedInUserProfilePic = this.cloudImageUrl + element.imageName;
        }
      });
    }
    if (!loggedInUserProfilePic) {
      loggedInUserProfilePic = this.staticUserProfilePic;
    }
    return loggedInUserProfilePic;
  }

  //Username added by prem
  updateChatMessages(message, partnerId) {
    if (this.sTextChats[partnerId]) {
      this.sTextChats[partnerId].messages.push({
        timeStamp: "" + Date.now(),
        message: {
          message: message,
          from: this.loggedInUser.uid,
          to: partnerId
        }
      });
    }
  }

  setSTextChats(meetingId, partnerId) {
    if (this.sTextChats[partnerId]) {
      return;
    }

    // let sTextMessages = [];
    console.log("=====reseting the Stext")
    this.sTextChats[partnerId] = {
      messages: []
    };
  }

  getSTextChats(partnerId) {
    return this.sTextChats[partnerId];
  }
  // *******************End*********************************/

  /***********************************audio chat start *****/

  showVolume(el, volume) {
    if (!el) return;
    if (volume < -45) { // vary between -45 and -20
      el.style.height = '0px';
    } else if (volume > -20) {
      el.style.height = '100%';
    } else {
      el.style.height = '' + Math.floor((volume + 100) * 100 / 25 - 220) + '%';
    }
  }


  //---------Audio Recording start----------//
  recordRTC: any;
  startRecording(peer) {
    let options = {
      mimeType: 'video/webm', // or video/webm\;codecs=h264 or video/webm\;codecs=vp9
      audioBitsPerSecond: 128000,
      videoBitsPerSecond: 128000
    };
    this.recordRTC = RecordRTC(peer.stream, options);
    //console.log("REcordRTC ==>", this.recordRTC);
    this.recordRTC.startRecording();
  }

  stopRecording(type) {
    this.recordRTC.stopRecording(
      () => {
        //console.log("AudioRecordingStopped==>", this.recordRTC.blob);
        // let recordedBlob = Object.assign({}, this.recordRTC.blob);
        let recordedBlob = this.recordRTC.blob;
        let videoFlle = "jetc_" + type + UUID.UUID() + ".webm";
        this.doUploadOnGoogleCloud(recordedBlob, videoFlle);
      }
    );
  }
  /***********************************audio chat end *****/

  // start file Share 

  droppedFile: any;
  mydata: any;
  dynamicFile: any;

  setDrpoFile(dropFile, conditional: boolean) {
    this.droppedFile = dropFile;
  }

  getFile(): any {
    return this.droppedFile;
  }

  setSTexChatMessage(meetingId, partnerId, message) {
    if (this.sTextChats[partnerId]) {
      this.sTextChats[partnerId].messages.push(message);
    }
  }


  startFileSharing(isPeerCaller) {
    let loggedInUserProfilePic = this.getUserProficPic();
    if (isPeerCaller) {
      this.sendInfo("meet", {
        userId: this.loggedInUser.uid,
        partnerId: this.currentPartnerId,
        username: this.getLoggedInUser().username,
        userProfilePic: loggedInUserProfilePic,
        type: "file"
      });
    } else {
      this.sendInfo("group", {
        userId: this.loggedInUser.uid,
        gId: this.currentGroupId,
        username: this.getLoggedInUser().username,
        userProfilePic: loggedInUserProfilePic,
        type: "file"
      });
    }
    //this.fileWebRTCPeer.sendFile(this.droppedFile);
  }

  //--New FileSharing method--websocket
  receiveFileSharing(file) {
    if (this.payloadForFileSharing) {
      // this.dynamicFile = URL.createObjectURL(this.droppedFile);
      console.log("PayloadForFileSharing==>", this.payloadForFileSharing.payload);
      if (this.payloadForFileSharing.type == "meet") {
        console.log("peer fileshare...");
        let message = {
          timeStamp: new Date(),
          message: {
            message: file.originalName + ", " + file.fileSize + " KB",
            username: this.payloadForFileSharing.payload.username,
            userProfilePic: this.payloadForFileSharing.payload.userProfilePic
          },
          name: file.originalName,
          mediaLink: file.mediaLink,
          fileSize: file.fileSize
        }
        if (!this.sTextChats[this.payloadForFileSharing.payload.userId]) {
          this.sTextChats[this.payloadForFileSharing.payload.userId] = {
            messages: []
          }
          this.sTextChats[this.payloadForFileSharing.payload.userId].messages.push(message);
        } else {
          this.setSTexChatMessage("meetingId", this.payloadForFileSharing.payload.userId, message);
        }

        // let messageObject = [
        //   { "partnerMessage": JSON.stringify(message), "timestamp": Date.now(), "uid": this.loggedInUser.uid, "pid": this.getCurrentPartnerId(), "type": "file" }
        // ];
        // this.saveFilesForHistory(messageObject,true)
      } else if (this.payloadForFileSharing.type == "group") {
        console.log("group fileshare...", this.payloadForFileSharing);
        if (this.loggedInUser.uid != this.payloadForFileSharing.payload.userId) {
          let fileInfo = {
            "mediaLink": file.mediaLink,
            "name": file.originalName,
            "dragedFileName": "dragedFileName",
            "fIcon": 'glyphicon glyphicon-file iconSize',
            "fileSize": file.fileSize,
            userProfilePic: this.payloadForFileSharing.payload.userProfilePic
          }
          this.updateGroupChatMessageWithFile(file.originalName + ", " + file.fileSize + " KB", this.payloadForFileSharing.payload.gId,
            this.payloadForFileSharing.payload.username, fileInfo);
          // this.updateGroupChatMessages({
          //   timeStamp: "" + Date.now(),
          //   name: file.name,
          //   mediaLink: file.mediaLink,
          //   username: this.payloadForFileSharing.payload.username,
          //   message: {
          //     message: 'file received...',
          //     username: this.payloadForFileSharing.payload.username,
          //     from: this.payloadForFileSharing.payload.userId,
          //   }
          // }, this.payloadForFileSharing.payload.gId, this.payloadForFileSharing.payload.userId);
        }

      }
      this.payloadForFileSharing = null;
    }
  }
  //--end new file sharing

  private metadata;
  getMetaData() {
    return this.metadata;
  }
  // end file share 


  //-------REST API------------//Start//
  saveTextMessages(messageObject, isPeerCaller) {
    if (isPeerCaller) {
      return this.http.post(this.baseUrl + "urs/messages", messageObject);
    } else {
      return this.http.post(this.baseUrl + "urs/group/messages", messageObject);
    }

  }

  getOldMesseges(id, pid, isPeerCaller, firstResult, maxSize): Observable<any> {
    if (isPeerCaller) {
      return this.http.get(this.baseUrl + "urs/messages/" + id + "/" + pid + "/" + firstResult + "/" + maxSize);
    } else {
      return this.http.get(this.baseUrl + "urs/group/messages/" + id + "/" + firstResult + "/" + maxSize);
    }
  }

  clearUnreadMesseges(id, pid, isPeerCaller): Observable<any> {
    if (isPeerCaller) {
      return this.http.get(this.baseUrl + "urs/messages/clear/" + id + "/" + pid);
    } else {
      return this.http.get(this.baseUrl + "urs/group/messages/clear/" + id + "/" + pid);
    }
  }

  // *******************Prashant*********************************//

  fileUpload(acceptedFile, fileObj, fileName, isPeerCaller) {
    //console.log("File uploading to cloud...", acceptedFile);
    let messageObject = [];
    this.doUploadOnGoogleCloud(acceptedFile, fileName).subscribe(
      (res) => {
        //console.log("CloudRes->", res);
        fileObj[0].mediaLink = res['mediaLink'];
        console.log("FileObj=>", fileObj[0]);
        this.http.post(this.baseUrl + "urs/files", fileObj,
          { responseType: 'text' }).subscribe(
            (res) => {
              //("Uploaded the file to backend=> " + res);
            },
            (err) => {
              console.log(err);
            }
          );
        //--file in history--//
        if (!isPeerCaller) {
          console.log("Group File in History==>");
          let loggedInUserProfilePic = this.getUserProficPic();
          messageObject = [
            {
              "gid": this.currentGroupId, "ownerMessage": JSON.stringify(fileObj[0]),
              "timestamp": Date.now(), "uid": this.loggedInUser.uid, "pid": this.getCurrentPartnerId(),
              "type": "file", "userProfilePic": loggedInUserProfilePic
            }
          ];
        } else {
          console.log("Peer File in History==>");
          messageObject = [
            { "ownerMessage": JSON.stringify(fileObj[0]), "timestamp": Date.now(), "uid": this.loggedInUser.uid, "pid": this.getCurrentPartnerId(), "type": "file" }
          ];
        }
        //--for file in history--//
        this.saveFilesForHistory(messageObject, isPeerCaller);
      }, (err) => {
        //console.log("CloudErr->", err);
      }
    );
  }

  saveFilesForHistory(messageObject, isPeerCaller) {
    this.saveTextMessages(messageObject, isPeerCaller)
      .subscribe((res) => {
        console.log("File==> ", res);
      }, (err) => {
        console.log("Error in storing messages : ", err);
      });
  }

  doUploadOnGoogleCloud(imageData: Blob, imageName: any) {
    //console.log("for Cloud post  ", imageData);
    let Params = new HttpParams();
    Params = Params.append('uploadType', 'media');
    Params = Params.append('name', imageName);
    return this.http.post(this.cloudUploadUrl, imageData, {
      params: Params
    });
  }
  // *******************End*********************************//

  //-------REST API------------//End//

  //-------Google Languages------------//Start//
  getSupportedLanguages() {

    let Params = new HttpParams();
    // Begin assigning parameters
    Params = Params.append("key", this.apiKey);

    return this.http.get(this.baseTranslationURL + "/languages",
      {
        params: Params
      });
  }

  translateMessageText(msg, code) {
    let tranlateOptions = {
      'q': msg,
      'target': code
    }
    let Params = new HttpParams();
    Params = Params.append("key", this.apiKey);
    return this.http.post(this.baseTranslationURL, tranlateOptions,
      {
        params: Params
      });
  }


  //*********************GAURAV Code START */
  /********************* GAURAV ****************************/

  completeUserList: any = [];

  /****** Get comlete user list Detail ******/
  getUserList(): Observable<any> {
    return this.http.get(this.baseUrl + "urs/users");
  }

  getGuestUserList(): Observable<any> {
    return this.http.get(this.baseUrl + "urs/guest");
  }

  setCompleteUserList(usersList: any): any {
    this.completeUserList = usersList;
  }

  getTextFileContents(fileName: any): Observable<any> {

    return this.http.get(this.baseUrl + "urs/storageFile/" + fileName);
  }

  getCompleteUserList(): any {
    return this.completeUserList;
  }
  /***** Get comlete user list Detail *****/

  /***** Get records history as per page and size *****/
  getRecordsHistory(recordName: any, pageNo: any, pageSize: any): Observable<any> {

    let userLogindetail = JSON.parse(localStorage.getItem("loginUserDetail"));
    return this.http.get(this.baseUrl + "urs/stat/" + userLogindetail.uid + "/" + recordName + "/" + pageNo + "/" + pageSize);
  }
  /***** Get records history as per page and size *****/

  /***** logout *****/

  logout(): any {

    let userLogindetail = JSON.parse(localStorage.getItem("loginUserDetail"));

    let Params = new HttpParams();
    Params = Params.append("access_token", userLogindetail.access_token);

    return this.http.post(this.baseUrl + 'urs/logout', {}, { params: Params, responseType: 'text' });

  }//logout()
  /***** logout *****/


  flushAllGroupChat(groupId) {
    this.sGroupChats[groupId] = {
      messages: []
    };
  }

  flushAllTextChats(partnerId) {
    this.sTextChats[partnerId] = {
      messages: []
    };
  }

  updateGroupMissedCallsMessages(message, groupId, senderId) {
    let username = "";
    let groupUsers = this.getGroup(groupId)['users'];

    if (groupUsers) {
      for (const userKey in groupUsers) {
        if (groupUsers[userKey]['userId'] == senderId) {
          username = groupUsers[userKey]['firstName'] + " " + groupUsers[userKey]['lastName'];
          break;
        }
      }
    } else {
      username = 'Unknown';
    }

    if (this.sGroupChats[groupId]) {
      this.sGroupChats[groupId].messages.push({
        timeStamp: "" + Date.now(),
        message: {
          message: message,
          from: senderId,
          to: groupId,
          username: username,
          file: undefined
        }
      });
    } else {
      this.sGroupChats[groupId] = {
        messages: []
      };
      this.sGroupChats[groupId].messages.push({
        timeStamp: "" + Date.now(),
        message: {
          message: message,
          from: senderId,
          to: groupId,
          username: username,
          file: undefined
        }
      });
    }
  }

  updatePeerMissedCallsMessages(message, partnerId, OwnerId) {
    this.setSTextChats("meetingId", partnerId);
    if (this.sTextChats[partnerId]) {
      if (OwnerId) {
        this.sTextChats[partnerId].messages.push({
          timeStamp: "" + Date.now(),
          message: {
            message: message,
            from: this.loggedInUser.uid,
            to: partnerId,
            username: this.loggedInUser.username
          }
        });
      } else {
        this.sTextChats[partnerId].messages.push({
          timeStamp: "" + Date.now(),
          message: {
            message: message,
            from: partnerId,
            to: this.loggedInUser.uid,
            username: this.getFriendById(+partnerId)['firstName'] + " " + this.getFriendById(+partnerId)['lastName']
          }
        });
      }
    }
  }


  //****************GAURAV CODE END */

}



