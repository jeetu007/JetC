import { Injectable, EventEmitter } from '@angular/core';
import SimpleWebRTC from 'simplewebrtc';
import * as RecordRTC from 'recordrtc';
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs/Rx';
import { UUID } from 'angular2-uuid';
import { DataServiceService } from "../data/data-service.service";
import { ToasterService } from 'angular2-toaster';
import 'rxjs/add/operator/map';
import { Message } from '@stomp/stompjs';
import { StompConfig, StompService } from '@stomp/ng2-stompjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

import { log } from 'util';

interface FileShare {
  msg: any;
  meetingId: any;
  from: any;
}

declare const MediaRecorder: any;

@Injectable()
export class ScreenService {

  private AudioWebRTC: any;
  private ScreenWebRTC: any;
  private screenPeerId: any;
  private audioPeerId: any;
  private groupPeers: any = [];
  private isPeerCaller: any = true;
  private state: any = false;
  private isAnsweringCall: boolean = false;
  private meetingId: any;
  private startTime: any;
  private endTime: any;
  private callDuration: any;

  //drshn
  mainWindow: any;
  remoteHeaderrow: any;

  //vk
  private audioMuteType = "self"
  private screenType = "self";


  constructor(public http: HttpClient, private dataService: DataServiceService,
    public toasterService: ToasterService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.dataService.fileSharing.subscribe({
      next: (event: FileShare) => {
        if (event.msg === "websocketconnection"){
          this.initializeWebSocketConnection();
        }
        if (event.msg === "mute") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.audioPeerId === event.from[i].id) {
              //console.log("Peer Id Matched For Mute: ", event.from[i].id);
              if (this.AudioWebRTC) {
                this.AudioWebRTC.mute();
                this.audioMuteType = "admin_mute";
              }
            }
          }
        } else if (event.msg === "unmute") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.audioPeerId === event.from[i].id) {
              //console.log("Peer Id Matched For UnMute: ", event.from[i].id);
              if (this.AudioWebRTC) {
                this.AudioWebRTC.unmute();
                this.audioMuteType = "admin_unmute";
              }
            }
          }
        } else if (event.msg === "stop_screen") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.screenPeerId === event.from[i].id) {
              //console.log("Peer Id Matched For stop_screen: ", event.from[i].id);
              if (this.ScreenWebRTC) {
                this.ScreenWebRTC.stopScreenShare();
                this.screenType = "admin_stop";
                document.getElementById("screenShareBtn").innerText = "Share Screen";
              }
            }
          }
        } else if (event.msg === "share_screen") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.screenPeerId === event.from[i].id) {
              //console.log("Peer Id Matched For share_screen : ", event.from[i].id);
              this.screenType = "admin_start";
              this.isAnsweringCall = true;
              this.createScreenObj(true);
              document.getElementById("screenShareBtn").innerText = "Stop Screen";
            }
          }
        }
      }
    });
  }

  initializeWebSocketConnection() {
    console.log("websocketConnectionInit");
    let stomp_subscription = this.dataService.getStompService().subscribe('/screenChat');
    stomp_subscription.map((message: Message) => {
      return message.body;
    }).subscribe((msg_body: string) => {
      console.log(`Received:=>`, msg_body);
      let chatDTOReceived = JSON.parse(msg_body);
      chatDTOReceived.body.payload = {
        'from': +chatDTOReceived.body.payload.from,
        'gId': +chatDTOReceived.body.payload.gId,
        'gid': +chatDTOReceived.body.payload.gid,
        'id': chatDTOReceived.body.payload.id,
        'mid': chatDTOReceived.body.payload.mid,
        'partnerId': +chatDTOReceived.body.payload.partnerId,
        'pid': +chatDTOReceived.body.payload.pid,
        'sid': chatDTOReceived.body.payload.sid,
        'status': JSON.parse(chatDTOReceived.body.payload.status),
        'to': +chatDTOReceived.body.payload.to,
        'type': chatDTOReceived.body.payload.type,
        'uid': +chatDTOReceived.body.payload.uid,
        'unreadMessage': +chatDTOReceived.body.payload.unreadMessage,
        'userId': +chatDTOReceived.body.payload.userId,
        'userStatusIcon': chatDTOReceived.body.payload.userStatusIcon,
        'username': chatDTOReceived.body.payload.username,
        'message': chatDTOReceived.body.payload.message,
        'audioPeerId': chatDTOReceived.body.payload.audioPeerId,
        'screenPeerId': chatDTOReceived.body.payload.screenPeerId

      };
      this.receiveAudioMessage(chatDTOReceived.body);
    })

  }
  sendSecreenInfo(type, obj) {
    this.dataService.getStompService().publish('/app/send/screen', JSON.stringify({ type: type, payload: obj }));
  }

  receiveAudioMessage(data) {
    if (data.type == "join") {
      this.addRemotePeer(data.payload);
    } else if (data.type === "acknowledge") {
      this.updateRemotePeer(data.payload);
    } else if (data && data.payload.screenPeerId) {
      this.spinnerService.hide();
    }
  }
  setAnsweringCall(isAnswering) {
    this.isAnsweringCall = isAnswering;
  }


  muteAll(muteStatus) {
    if (this.AudioWebRTC) {
      this.dataService.muteAll(this.AudioWebRTC.getPeers(), muteStatus);
    }
  }

  mutePeer(peerId, muteStatus) {
    if (this.AudioWebRTC) {
      let peersArray = [];
      peersArray.push({ "id": peerId });
      this.dataService.muteAll(peersArray, muteStatus);
    }
  }

  stopAllScreens(screenStatus) {
    if (this.ScreenWebRTC) {
      this.dataService.stopAllScreens(this.ScreenWebRTC.getPeers(), screenStatus);
    }
  }

  stopPeerScreen(peerId, screenStatus) {
    if (this.ScreenWebRTC) {
      let peersArray = [];
      peersArray.push({ "id": peerId });
      this.dataService.stopAllScreens(peersArray, screenStatus);
    }
  }


  addRemotePeer(remotePeer) {

    let status = true;
    if (remotePeer.uid != this.dataService.getLoggedInUser().uid) {
      for (let i = 0; i < this.groupPeers.length; i++) {
        if (this.groupPeers[i].uid === remotePeer.uid) {
          this.groupPeers[i] = remotePeer;
          status = false;
        }
      }
      if (status && remotePeer.audioPeerId && remotePeer.audioPeerId != this.audioPeerId) {
        this.groupPeers.push(remotePeer);
      }
      setTimeout(() => {
        if (this.AudioWebRTC)
          //this.AudioWebRTC.sendToAll("acknowledge", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
          this.sendSecreenInfo("acknowledge", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid })
      }, 2000);
      return;
    }

    // if(remotePeer.uid === this.dataService.getLoggedInUser().uid){
    //   //doing nothing as u should not add ur self as peer.
    //   return;
    // }
    // setTimeout(() => {
    //   if(this.AudioWebRTC)
    //   //this.AudioWebRTC.sendToAll("acknowledge", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
    //   this.sendSecreenInfo("acknowledge", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid })
    // }, 2000);

    // let status = true;
    // for (let i = 0; i < this.groupPeers.length; i++) {
    //   if (this.groupPeers[i].audioPeerId === remotePeer.audioPeerId) {
    //     this.groupPeers[i] = remotePeer;
    //     status = false;
    //   }
    // }

    // if (status && remotePeer.audioPeerId && remotePeer.audioPeerId != this.audioPeerId) {
    //   this.groupPeers.push(remotePeer);
    // }
    console.log("AddRemotePeer=>", this.groupPeers);
    //console.log("add...", remotePeer);
  }

  updateRemotePeer(remotePeer) {
    let status = true;
    if (remotePeer.uid != this.dataService.getLoggedInUser().uid) {
      for (let i = 0; i < this.groupPeers.length; i++) {
        if (this.groupPeers[i].uid === remotePeer.uid) {
          this.groupPeers[i] = remotePeer;
          status = false;
        }
      }
      if (status && remotePeer.audioPeerId && remotePeer.audioPeerId != this.audioPeerId) {
        this.groupPeers.push(remotePeer);
      }
      return;
    }

    // for (let i = 0; i < this.groupPeers.length; i++) {
    //   if (this.groupPeers[i].audioPeerId === remotePeer.audioPeerId) {
    //     this.groupPeers[i] = remotePeer;
    //     status = false;
    //   }
    // }

    // if (status && remotePeer.audioPeerId && remotePeer.audioPeerId != this.audioPeerId) {
    //   this.groupPeers.push(remotePeer);
    // }
    console.log("UpdateRemotePeer=>", this.groupPeers);

    //console.log("update...", remotePeer);
  }

  removeRemotePeer(peerId) {
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].audioPeerId === peerId) {
        //console.log("deleted...", this.groupPeers[i]);
        this.groupPeers.splice(i, 1);
        break;
      }
    }
  }

  getRemotePeer(peerId) {
    let remotePeer;
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].audioPeerId === peerId) {
        remotePeer = this.groupPeers[i];
        break;
      }
      if (this.groupPeers[i].screenPeerId === peerId) {
        remotePeer = this.groupPeers[i];
        break;
      }
    }
    if (!remotePeer)
      return null;
    return remotePeer;
  }

  createScreenObj(state) {
    this.deleteScreenObj();
    this.ScreenWebRTC = new SimpleWebRTC({
      localVideoEl: '',
      remoteVideosEl: '',
      autoRequestMedia: false,
      debug: false,
      media: { video: false, audio: false },
      nick: 'Screen Share',
      peerConnectionConfig: {
        "iceServers": [{
          urls: "stun:stun.l.google.com:19302"
        },
        {
          urls: "turn:139.59.58.0",
          username: "prouser",
          credential: "mypassword"
        }
        ]
      },
      // url: "https://192.168.2.10:10000"
      url: "https://192.168.2.10:8888/"
    });

    
    //this.ScreenWebRTC.config.peerConnectionConfig.iceTransports = "relay";

    this.ScreenWebRTC.once('readyToCall', () => {
      this.ScreenWebRTC.joinRoom(this.meetingId, (err, roomDescription) => { });
    });

    this.ScreenWebRTC.on("connectionReady", screenPeerId => {
      this.screenPeerId = screenPeerId;
    });

    this.ScreenWebRTC.on("joinedRoom", room => {
      //this.AudioWebRTC.sendToAll("join", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
      this.sendSecreenInfo("join", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });

    });

    if (this.isAnsweringCall) {
      if (state) {
        setTimeout(() => {
          this.ScreenWebRTC.shareScreen((err) => {
            //console.log("Error" + err)
          });
        }, 5000);

      }

      this.ScreenWebRTC.on('localScreenAdded', (video) => {
        //console.log("Added Screen....................");
      });

      this.ScreenWebRTC.on('localScreenRemoved', (video) => {
        //console.log("Screen Removed...............");
      });

      this.ScreenWebRTC.on('localScreenStopped', () => {
        //console.log("Screen Stopped..............");
      });
    }

    this.ScreenWebRTC.on('videoAdded', (video, peer) => {
      console.log('Screen added.......', peer);
      //----
      console.log("Publishing screen start event....");
      let payload = { "type": "SharingStarted" };
      this.dataService.sendInfo("ScreenAdded", payload);
      //----
      var remoteScreens = document.getElementById('remoteScreens');
      var groupScreens = document.getElementById('groupScreens');
      this.spinnerService.hide();
      if (this.isPeerCaller) {
        var div = document.createElement('div');
        div.className = 'videoContainer';
        video.style.position = 'fixed';
        video.style.display = 'block';
        video.style.top = 0 + 'px';
        video.style.left = 0 + 'px';
        video.style.right = 0 + 'px';
        video.style.bottom = 0 + 'px';
        video.style.overflow = 'visible';
        video.style.width = 100 + '%';
        video.style.height = 100 + '%';
        video.style.background = '#ccc';
        div.appendChild(video);
        video.oncontextmenu = () => { return false; };
        remoteScreens.appendChild(div);
      } else {
        let timer: any = Observable.timer(0, 100);
        let subscription = timer.subscribe(data => {
          let peerObj = this.getRemotePeer(peer.id);
          if (peerObj) {
            var mainContainer = document.getElementById("" + peerObj.audioPeerId);
            if (mainContainer) {
              let screenBtn = document.getElementById("share_" + peerObj.audioPeerId);

              if (this.dataService.getGroupAdminStatus()) {
                if (!screenBtn) {
                  screenBtn = document.createElement("button");
                  screenBtn.id = "share_" + peerObj.audioPeerId;
                  screenBtn.innerText = "Stop";

                  screenBtn.style.width = 65 + 'px';
                  screenBtn.style.height = 30 + 'px';
                  screenBtn.style.background = '#ec8d69';
                  screenBtn.style.borderStyle = 'none';
                  screenBtn.style.borderRadius = '15px';
                  screenBtn.style.margin = '10%';
                  screenBtn.onclick = () => {
                    if (screenBtn.innerText == "Stop") {
                      this.stopPeerScreen(peer.id, true);
                      screenBtn.innerText = "Share";
                    } else {
                      this.stopPeerScreen(peer.id, false);
                      screenBtn.innerText = "Stop";
                    }
                  };

                  mainContainer.appendChild(screenBtn);
                } else {
                  screenBtn.onclick = () => {
                    if (screenBtn.innerText == "Stop") {
                      this.stopPeerScreen(peer.id, true);
                      screenBtn.innerText = "Share";
                    } else {
                      this.stopPeerScreen(peer.id, false);
                      screenBtn.innerText = "Stop";
                    }
                  };
                }
              }

              let videoBox = document.createElement("div");
              videoBox.id = "video_" + peerObj.audioPeerId;
              videoBox.className = "videoBox";
              videoBox.style.width = 100 + '%';
              videoBox.style.padding = 5 + '%';

              video.oncontextmenu = () => { console.log("Right click........"); return false; };
              video.style.width = 100 + '%';

              videoBox.ondblclick = () => {
                this.setFullScreenStyles(video.id, videoBox.id, peer);

              };

              videoBox.appendChild(video);




              let lastBox = document.getElementById("video_" + peerObj.audioPeerId);
              if (lastBox) {
                mainContainer.removeChild(lastBox);
                mainContainer.appendChild(videoBox);
              } else {
                mainContainer.appendChild(videoBox);
              }

              subscription.unsubscribe();
            }

          }
        });
      }

    });

    this.ScreenWebRTC.on('videoRemoved', (video, peer) => {
      console.log('Screen removed.....', peer);
      this.spinnerService.hide();
      var remoteScreens = document.getElementById('remoteScreens');
      var groupScreens = document.getElementById('groupScreens');

      if (this.isPeerCaller) {
        remoteScreens.innerHTML = "";
      } else {
        let timer: any = Observable.timer(0, 100);
        let subscription = timer.subscribe(data => {
          let peerObj = this.getRemotePeer(peer.id);
          if (peerObj) {
            let videoBox = document.getElementById("video_" + peerObj.audioPeerId);
            var mainContainer = document.getElementById("" + peerObj.audioPeerId);

            if (mainContainer && videoBox) {
              if (document.getElementById("big_screen_" + "video_" + peerObj.audioPeerId)) {
                this.mainWindow.innerHTML = "";
              }
              mainContainer.removeChild(videoBox);
              subscription.unsubscribe();
            }

          }
        });
      }

    });
  }

  deleteScreenObj() {
    if (this.ScreenWebRTC) {
      this.ScreenWebRTC.stopScreenShare();
      this.ScreenWebRTC.stopLocalVideo();
      this.ScreenWebRTC.connection.disconnect();
      this.ScreenWebRTC = null;
    }
  }

  startScreenSharing(meetingId, isPeerCaller, state) {
    if (document.getElementById('remoteScreens'))
      document.getElementById('remoteScreens').innerHTML = "";
    if (document.getElementById('groupScreens'))
      document.getElementById('groupScreens').innerHTML = "";
    this.isPeerCaller = isPeerCaller;
    this.meetingId = meetingId;
    this.state = state;
    this.audioPeerId = null;
    this.screenPeerId = null;
    this.audioMuteType = "self";
    this.screenType = "self";

    if (!this.isPeerCaller) {
      this.dataService.setGroupAnswerWaitingStatus(false);
      this.dataService.setGroupPeers(null);

      let selfMuteBtn = document.createElement("button");
      selfMuteBtn.style.position = 'fixed';
      selfMuteBtn.style.top = 2 + '%';
      selfMuteBtn.style.right = 2 + '%';
      selfMuteBtn.style.zIndex = '1001';
      selfMuteBtn.innerText = 'Mute';
      selfMuteBtn.style.borderStyle = 'none';
      selfMuteBtn.style.background = '#d9534f';
      selfMuteBtn.style.padding = '5px';
      selfMuteBtn.style.borderRadius = '5px';
      selfMuteBtn.style.color = 'white';

      selfMuteBtn.addEventListener("click", () => {
        if (selfMuteBtn.innerText == 'Mute' && (this.audioMuteType == 'self' || this.audioMuteType == 'admin_unmute') && this.AudioWebRTC) {
          this.AudioWebRTC.mute();
          selfMuteBtn.style.background = 'yellowgreen';
          selfMuteBtn.innerText = 'Unmute';

          console.log('***********mute');
        } else if (selfMuteBtn.innerText == 'Unmute' && this.audioMuteType != 'admin_mute' && this.AudioWebRTC) {
          this.AudioWebRTC.unmute();
          selfMuteBtn.style.background = '#d9534f';
          selfMuteBtn.innerText = 'Mute';
          console.log('***********Unmute');
        } else if (this.audioMuteType == 'admin_mute') {
          this.toasterService.pop('info', 'Permission denied !!', 'Audio Muted By Group Admin');
        }
      });

      let screenShareBtn: any = selfMuteBtn.cloneNode(true);
      screenShareBtn.id = "screenShareBtn";
      screenShareBtn.style.top = 8 + '%';
      screenShareBtn.style.borderStyle = 'none';
      screenShareBtn.style.padding = '5px';
      screenShareBtn.style.borderRadius = '5px';
      screenShareBtn.style.color = 'white';


      if (this.state && this.isAnsweringCall) {
        screenShareBtn.innerText = 'Stop Screen';
        screenShareBtn.style.background = '#d9534f';
      } else {
        screenShareBtn.innerText = 'Share Screen';
        screenShareBtn.style.background = 'yellowgreen';
      }


      screenShareBtn.addEventListener("click", () => {
        if (screenShareBtn.innerHTML == "Share Screen" && (this.screenType == 'self' || this.screenType == 'admin_stop') && this.ScreenWebRTC) {
          screenShareBtn.style.background = '#d9534f';
          screenShareBtn.innerHTML = "Stop Screen";
          this.isAnsweringCall = true;
          this.createScreenObj(true);
        } else if (screenShareBtn.innerHTML == "Stop Screen" && this.screenType != 'admin_start' && this.ScreenWebRTC) {
          if (this.ScreenWebRTC) {
            screenShareBtn.style.background = 'yellowgreen';
            screenShareBtn.innerHTML = "Share Screen";
            this.ScreenWebRTC.stopScreenShare();
          }
        } else if (this.screenType == 'admin_start') {
          this.toasterService.pop('info', 'Permission denied !!', 'Screen Stopped By Group Admin');
        }
      });

      if (document.getElementById('groupScreens')) {
        document.getElementById('groupScreens').appendChild(selfMuteBtn);
        document.getElementById('groupScreens').appendChild(screenShareBtn);
      }
    }

    this.AudioWebRTC = new SimpleWebRTC({
      localVideoEl: 'localAudioWithScreen',
      remoteVideosEl: '',
      autoRequestMedia: true,
      debug: false,
      media: { video: false, audio: true },
      detectSpeakingEvents: true,
      nick: 'Audio Chat',
      localVideo: {
        autoplay: true,
        mirror: false,
        muted: true
      },
      peerConnectionConfig: {
        "iceServers": [{
          urls: "stun:stun.l.google.com:19302"
        },
        {
          urls: "turn:139.59.58.0",
          username: "prouser",
          credential: "mypassword"
        }
        ]
      },
      // url: "https://192.168.2.10:10000"
      url: "https://192.168.2.10:8888/"
    });

    //this.AudioWebRTC.config.peerConnectionConfig.iceTransports = "relay";
    
    this.AudioWebRTC.once('readyToCall', () => {
    this.AudioWebRTC.joinRoom(meetingId + "_Audio", (err, roomDescription) => { });
    });


    this.AudioWebRTC.on("connectionReady", audioPeerId => {
      this.audioPeerId = audioPeerId;
    });

    this.AudioWebRTC.connection.on("remove", peer => {
      this.removeRemotePeer(peer.id);
    });

    this.AudioWebRTC.on("joinedRoom", room => {
      //----Update the msg also
      let users = this.dataService.getFriends();
      let user = " ";
      for (let i = 0; i < users.length; i++) {
        if (this.dataService.getCurrentPartnerId() === users[i].userId) {
          user = users[i].username;
        }
      }
      this.startTime = new Date();
      this.spinnerService.show();
     
      //---
      //this.AudioWebRTC.sendToAll("join", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
      this.sendSecreenInfo("join", { "audioPeerId": this.audioPeerId, "screenPeerId": this.screenPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
      this.createScreenObj(state);
    });

    // this.AudioWebRTC.connection.on("message__", data => {
    //   if (data.type == "join") {
    //     this.addRemotePeer(data.payload);
    //   } else if (data.type === "acknowledge") {
    //     this.updateRemotePeer(data.payload);
    //   }
    // });



    this.AudioWebRTC.on('videoAdded', (video, peer) => {
      console.log('Audio added........', peer);
      var remoteScreens = document.getElementById('remoteScreens');
      var groupScreens = document.getElementById('groupScreens');
      // video.setAttribute('controls', 'controls');
      if (this.isPeerCaller) {
        this.dataService.updateChatMessages("Screen sharing started." , this.dataService.getCurrentPartnerId());
      } else {
        this.dataService.updateGroupChatMessages("Group screen share started.", this.dataService.getCurrGroupID(), this.dataService.getLoggedInUser().uid);
      }
      if (this.isPeerCaller) {
        var div = document.createElement('div');
        div.className = 'CssClass';
        div.style.position = 'fixed';
        div.style.display = 'block';
        div.style.right = 15 + '%';
        div.style.bottom = 50 + '%';
        div.style.width = 120 + 'px';
        div.style.height = 60 + 'px';
        div.style.margin = 4 + 'px';
        div.style.zIndex = "99";
        div.appendChild(video);
        remoteScreens.appendChild(div);
      } else {
        var mainContainer = document.createElement('div');
        mainContainer.className = 'CssClass';
        mainContainer.id = '' + peer.id;
        mainContainer.style.position = 'relative';
        mainContainer.style.display = 'block';
        mainContainer.style.width = 100 + '%';
        mainContainer.style.margin = '5% 0 0 0';
        mainContainer.style.backgroundColor = 'grey';

        let screenContainer = document.createElement('div');
        screenContainer.style.position = 'fixed';
        screenContainer.style.display = 'block';
        screenContainer.style.backgroundColor = '#c1c1c1';
        screenContainer.style.top = '0%';
        screenContainer.style.bottom = '0%';
        screenContainer.style.left = '0%';
        screenContainer.style.right = '0%';


        let sideBar = document.createElement('div');
        sideBar.setAttribute('class', 'col-lg-3 col-md-3 col-sm-3');
        sideBar.setAttribute('id', 'div3');
        sideBar.style.height = '100%';
        sideBar.style.backgroundColor = '#c1c1c1';
        sideBar.style.overflow = 'auto';

        this.mainWindow = document.createElement('div');
        this.mainWindow.setAttribute('class', 'col-lg-9 col-md-9 col-sm-9');
        this.mainWindow.setAttribute('id', 'div9');
        this.mainWindow.style.backgroundColor = 'grey';
        this.mainWindow.style.height = '100%';

        setInterval(() => {
          const mq = window.matchMedia('(max-width:767px)');
          if (mq.matches) {
            sideBar.style.height = '50%';
            this.mainWindow.style.height = '50%';
            mainContainer.style.width = 50 + '%';
          } else {
            sideBar.style.height = '100%';
            this.mainWindow.style.height = '100%';
            mainContainer.style.width = 100 + '%';
          }
        }, 1000);


        let muteBtn = document.createElement("button");
        if (this.dataService.getGroupAdminStatus()) {

          muteBtn.innerHTML = "Mute";
          muteBtn.style.width = 65 + 'px';
          muteBtn.style.height = 30 + 'px';
          muteBtn.style.background = 'yellowgreen';
          muteBtn.style.borderStyle = 'none';
          muteBtn.style.borderRadius = '15px';
          muteBtn.style.margin = '10%';

          muteBtn.addEventListener("click", () => {
            if (muteBtn.innerHTML == "Mute") {
              this.mutePeer(peer.id, true);
              muteBtn.innerHTML = "UnMute";
            } else {
              this.mutePeer(peer.id, false);
              muteBtn.innerHTML = "Mute";
            }
          });
        }

        video.style.display = 'none';

        this.remoteHeaderrow = document.createElement('div');
        this.remoteHeaderrow.setAttribute('class', 'row');
        let ColHeaderMuteBtn = document.createElement('div');
        ColHeaderMuteBtn.setAttribute('class', 'col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6');
        if (this.dataService.getGroupAdminStatus())
          ColHeaderMuteBtn.appendChild(muteBtn);

        let ColHeaderUsername = document.createElement('div');
        ColHeaderUsername.setAttribute('class', 'col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6');


        let timer: any = Observable.timer(0, 100);
        let subscription = timer.subscribe(data => {
          let peerObj = this.getRemotePeer(peer.id);
          if (peerObj) {
            var username = document.createElement('label');
            username.innerHTML = peerObj.username + " ";
            username.style.color = 'cyan';
            username.style.zIndex = '99';
            username.style.fontSize = '18';
            username.style.padding = '10%';

            ColHeaderUsername.appendChild(document.getElementById("" + peerObj.audioPeerId).appendChild(username));
            subscription.unsubscribe();
          }
        });

        this.remoteHeaderrow.appendChild(ColHeaderMuteBtn);
        this.remoteHeaderrow.appendChild(ColHeaderUsername);

        mainContainer.appendChild(this.remoteHeaderrow);
        groupScreens.appendChild(mainContainer);

        var mainRow = document.getElementById('mainRowForScreen');
        sideBar.appendChild(groupScreens);
        screenContainer.appendChild(sideBar);
        screenContainer.appendChild(this.mainWindow);
        mainRow.appendChild(screenContainer);

      }

    });


    this.AudioWebRTC.on('videoRemoved', (video, peer) => {
      console.log('Audio removed.....', peer);
      this.spinnerService.hide();
      var remoteScreens = document.getElementById('remoteScreens');
      var groupScreens = document.getElementById('groupScreens');

      if (this.isPeerCaller) {
        remoteScreens.innerHTML = "";
        this.stopScreenSharing();
        this.dataService.stopChat("StopScreen", true, this.isPeerCaller);
      } else {
        if (document.getElementById("big_screen_" + "video_" + peer.id)) {
          this.mainWindow.innerHTML = "";
        }

        let ele = document.getElementById("" + peer.id);
        document.getElementById('groupScreens').removeChild(ele);

        if (this.AudioWebRTC.getPeers() && this.AudioWebRTC.getPeers().length == 0) {
          this.stopScreenSharing();
          this.dataService.stopChat("StopScreen", true, this.isPeerCaller);
        }
      }

    });

    this.AudioWebRTC.on("createdPeer", peer => {
      if (!this.isPeerCaller)
        this.dataService.setGroupPeers({ "type": "screen", "peers": this.AudioWebRTC.getPeers() });
    });

    this.AudioWebRTC.on('channelMessage', (peer, label, data) => {
      if (data.type == 'volume') { this.showVolume(document.getElementById('volume_' + peer.id), data.volume); }
    });

    this.AudioWebRTC.on('volumeChange', (volume, treshold) => {
      this.showVolume(document.getElementById('localVolumeAudioWithScreen'), volume);
    });

  }

  stopScreenSharing() {
    //End time
    //---
    this.spinnerService.hide();
    if (this.startTime) {
      this.endTime = new Date();
      this.callDuration = Math.round((this.endTime - this.startTime) / 1000);
      if (this.isPeerCaller) {
        this.dataService.updateChatMessages("Screen sharing ended, duration: " + this.callDuration + " s", this.dataService.getCurrentPartnerId());
      } else {
        this.dataService.updateGroupChatMessages("Group screen share ended, duration: " + this.callDuration + " s", this.dataService.getCurrGroupID(), this.dataService.getLoggedInUser().uid);
      }
      this.startTime = null;
      this.endTime = null;
    }
    //----
    if (this.AudioWebRTC) {
      this.AudioWebRTC.stopScreenShare();
      this.AudioWebRTC.stopLocalVideo();
      this.AudioWebRTC.connection.disconnect();
      this.AudioWebRTC = null;
    }
    if (this.ScreenWebRTC) {
      this.ScreenWebRTC.stopScreenShare();
      this.ScreenWebRTC.stopLocalVideo();
      this.ScreenWebRTC.connection.disconnect();
      this.ScreenWebRTC = null;
    }
    this.dataService.setGroupAnswerWaitingStatus(false);
    this.dataService.setGroupPeers(null);
  }

  showVolume(el, volume) {
    if (!el) return;
    if (volume < -45) { // vary between -45 and -20
      el.style.height = '0px';
    } else if (volume > -20) {
      el.style.height = '100%';
    } else {
      el.style.height = '' + Math.floor((volume + 100) * 100 / 25 - 220) + '%';
    }
  }


  //drshn
  setFullScreenStyles(videoId, divId, peerV) {
    var bigScreen = document.createElement('video');
    bigScreen.id = "big_screen_" + divId;
    bigScreen.setAttribute('src', window.URL.createObjectURL(peerV.stream));
    bigScreen.style.width = 100 + '%';
    bigScreen.style.height = 100 + '%';
    bigScreen.play();
    this.mainWindow.innerHTML = "";
    this.mainWindow.appendChild(bigScreen);
  }


}