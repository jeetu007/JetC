import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'recordsFilterPipe'
})
export class RecordsFilterPipe implements PipeTransform {

  transform(items: any[], filter: any): any {

    if (!items || !filter || (filter.length < 3)) {
      return items;
    }

    let filterItems = [];

    for (var i in items) {

      if (items[i].toUId.toLowerCase().indexOf(filter.toLowerCase()) !== -1 ||
        items[i].fromUId.toLowerCase().indexOf(filter.toLowerCase()) !== -1 ||
        items[i].name.toLowerCase().indexOf(filter.toLowerCase()) !== -1) {
          filterItems.push(items[i]);
      }//if

    }//for

    if (filterItems.length != 0) {
      return filterItems;
    } else {
      return items;
    }

    // filter items array, items which match and return true will be
    // kept, false will be filtered out
    // if (items.filter(item => item.toUId.toLowerCase().indexOf(filter.toLowerCase()) !== -1).length != 0) {
    //   return items.filter(item => item.toUId.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
    // } else if (items.filter(item => item.fromUId.toLowerCase().indexOf(filter.toLowerCase()) !== -1).length != 0) {
    //   return items.filter(item => item.fromUId.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
    // } else if (items.filter(item => item.name.toLowerCase().indexOf(filter.toLowerCase()) !== -1).length != 0) {
    //   return items.filter(item => item.name.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
    // } else {
    //   return items;
    // }
    //return items.filter(item => item.toUId.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
  }

}
