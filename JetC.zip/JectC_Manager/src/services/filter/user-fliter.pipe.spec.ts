import { UserFliterPipe } from './user-fliter.pipe';

describe('UserFliterPipe', () => {
  it('create an instance', () => {
    const pipe = new UserFliterPipe();
    expect(pipe).toBeTruthy();
  });
});
