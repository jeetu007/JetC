import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myFilterPipe'
})
export class MyFilterPipePipe implements PipeTransform {

  transform(items: any[], filter: any): any {

    if (!items || !filter) {
      return items;
    }
    // filter items array, items which match and return true will be
    // kept, false will be filtered out
    if (items.filter(item => item.username.toLowerCase().indexOf(filter.toLowerCase()) !== -1).length == 0) {
      return [-1];
    } else {
      return items.filter(item => item.username.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
    }
    // return items.filter(item => item.username.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
  }



}
