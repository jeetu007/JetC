import { Injectable, EventEmitter } from '@angular/core';
import SimpleWebRTC from 'simplewebrtc';
import * as RecordRTC from 'recordrtc';
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { UUID } from 'angular2-uuid';
import { DataServiceService } from "../data/data-service.service";
import { Observable } from 'rxjs/Rx';
import { ToasterService } from 'angular2-toaster';
import 'rxjs/add/operator/map';
import { Message } from '@stomp/stompjs';
import { StompConfig, StompService } from '@stomp/ng2-stompjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

interface FileShare {
  msg: any;
  meetingId: any;
  from: any;
}

declare const MediaRecorder: any;


@Injectable()
export class AudioService {

  private objStatus: any = false;
  private AudioWebRTC: any;
  private callsInProgress: any = {};
  public fileSharing: EventEmitter<FileShare> = new EventEmitter<FileShare>();
  private mediaRecorder: any;
  private cloudUploadUrl = "https://www.googleapis.com/upload/storage/v1/b/jetc-webrtc/o";
  private baseCloudUrl = "https://storage.googleapis.com/jetc-webrtc/urs199";
  private isPeerCaller: any = true;
  private groupPeers: any = [];
  private audioPeerId: any;
  private loggedInUser: any;
  private currentGroupId: any;
  private currentPartnerId: any;
  private ismute: boolean = true;
  // private baseUrl = "http://localhost:8090/WebRTC/";
  private baseUrl = "https://192.168.2.10:10391/Web_RTC/";
  private audioMuteType = "self";
  private endTime: any;
  private startTime: any;
  private callDuration: any;
  private currentGroupPeerId: any

  constructor(public http: HttpClient, private dataService: DataServiceService,
    public toasterService: ToasterService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.dataService.fileSharing.subscribe({
      next: (event: FileShare) => {
        if (event.msg === "websocketconnection") {
          this.initializeWebSocketConnection();
        }
        if (event.msg === "mute") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.audioPeerId === event.from[i].id) {
              console.log("Peer Id Matched For Mute: ", event.from[i].id);
              if (this.AudioWebRTC) {
                this.AudioWebRTC.mute();
                this.audioMuteType = "admin_mute";
              }
            }
          }
        } else if (event.msg === "unmute") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.audioPeerId === event.from[i].id) {
              console.log("Peer Id Matched For UnMute: ", event.from[i].id);
              if (this.AudioWebRTC) {
                this.AudioWebRTC.unmute();
                this.audioMuteType = "admin_unmute";
              }
            }
          }
        }
      }
    });
  }


  initializeWebSocketConnection() {
    console.log("websocketConnectionInit");
    let stomp_subscription = this.dataService.getStompService().subscribe('/audioChat');
    stomp_subscription.map((message: Message) => {
      return message.body;
    }).subscribe((msg_body: string) => {

      let chatDTOReceived = JSON.parse(msg_body);
      console.log("AudioPeerId=>", chatDTOReceived.body.payload.audioPeerId);
      chatDTOReceived.body.payload = {
        'from': +chatDTOReceived.body.payload.from,
        'gId': +chatDTOReceived.body.payload.gId,
        'id': chatDTOReceived.body.payload.id,
        'mid': chatDTOReceived.body.payload.mid,
        'partnerId': +chatDTOReceived.body.payload.partnerId,
        'pid': +chatDTOReceived.body.payload.pid,
        'sid': chatDTOReceived.body.payload.sid,
        'status': JSON.parse(chatDTOReceived.body.payload.status),
        'to': +chatDTOReceived.body.payload.to,
        'type': chatDTOReceived.body.payload.type,
        'uid': +chatDTOReceived.body.payload.uid,
        'unreadMessage': +chatDTOReceived.body.payload.unreadMessage,
        'userId': +chatDTOReceived.body.payload.userId,
        'userStatusIcon': chatDTOReceived.body.payload.userStatusIcon,
        'username': chatDTOReceived.body.payload.username,
        'message': chatDTOReceived.body.payload.message,
        'audioPeerId': chatDTOReceived.body.payload.audioPeerId
      };
      this.receiveAudio(chatDTOReceived.body);
      console.log(`AudioReceived:=>`, chatDTOReceived.body);
    });
  }

  receiveAudio(data) {
    if (data.type == "join") {
      this.addRemotePeer(data.payload);
    } else if (data.type === "acknowledge") {
      this.updateRemotePeer(data.payload);
    }
  }



  getCurrentPartnerId() {
    return this.currentPartnerId;
  }

  setCurrentPartnerId(partnerId) {
    this.currentPartnerId = partnerId;
  }

  setCurrentUser(loggedInUser) {
    this.loggedInUser = loggedInUser;
  }

  setCurrentGroupId(groupID) {
    this.currentGroupId = groupID;
  }

  getCurrGroupID() {
    return this.currentGroupId;
  }

  setMeetingId(partnerId, meetingId) {
    this.callsInProgress[partnerId] = { "meeting": meetingId };
  }

  muteAll(muteStatus) {
    if (this.AudioWebRTC) {
      this.dataService.muteAll(this.AudioWebRTC.getPeers(), muteStatus);
    }
  }

  mutePeer(domId, muteStatus) {
    if (this.AudioWebRTC) {
      let peersArray = [];
      peersArray.push({ "id": domId });
      this.dataService.muteAll(peersArray, muteStatus);
    }
  }

  startAudioChatting(partnerId, meetingId, isPeerCaller) {
    console.log("Start Audio Chat :: ", meetingId);

    if (document.getElementById('remoteAudios'))
      document.getElementById('remoteAudios').innerHTML = "";
    this.isPeerCaller = isPeerCaller;
    this.audioMuteType = "self";

    if (this.isPeerCaller) {
      if (this.callsInProgress[partnerId]) {
        meetingId = this.callsInProgress[partnerId]["meeting"];
      }
      else {
        this.callsInProgress[partnerId] = { "meeting": meetingId };
      }
    } else {
      this.dataService.setGroupAnswerWaitingStatus(false);
      this.dataService.setGroupPeers(null);

      let selfMuteBtn = document.createElement("button");
      selfMuteBtn.style.position = 'fixed';
      selfMuteBtn.style.top = 2 + '%';
      selfMuteBtn.style.right = 2 + '%';
      selfMuteBtn.innerText = 'Mute';

      selfMuteBtn.addEventListener("click", () => {
        if (selfMuteBtn.innerText == 'Mute' && (this.audioMuteType == 'self' || this.audioMuteType == 'admin_unmute') && this.AudioWebRTC) {
          this.AudioWebRTC.mute();
          selfMuteBtn.innerText = 'Unmute';
          console.log('***********mute');
        } else if (selfMuteBtn.innerText == 'Unmute' && this.audioMuteType != 'admin_mute' && this.AudioWebRTC) {
          this.AudioWebRTC.unmute();
          selfMuteBtn.innerText = 'Mute';
          console.log('***********Unmute');
        } else if (this.audioMuteType == 'admin_mute') {
          this.toasterService.pop('info', 'Permission denied !!', 'Muted By Group Admin');
        }
      });

      if (document.getElementById('remoteAudios'))
        document.getElementById('remoteAudios').appendChild(selfMuteBtn);
    }

    this.AudioWebRTC = new SimpleWebRTC({
      localVideoEl: 'localAudio',
      remoteVideosEl: '',
      autoRequestMedia: true,
      debug: false,
      media: { video: false, audio: true },
      detectSpeakingEvents: true,
      nick: 'Audio Chat',
      localVideo: {
        autoplay: true,
        mirror: false,
        muted: true
      } ,peerConnectionConfig: {
        "iceServers": [{
          urls: "stun:stun.l.google.com:19302"
        },
        {
          urls: "turn:139.59.58.0",
          username: "prem",
          credential: "mypassword@11"
        }
        ]
      },
      // url: "https://192.168.2.10:10000"
      url: "https://192.168.2.210:8888/"
    });

    //this.AudioWebRTC.config.peerConnectionConfig.iceTransports = "relay";

    this.AudioWebRTC.once('readyToCall', () => {
      this.AudioWebRTC.joinRoom(meetingId);
    });

    this.AudioWebRTC.on('channelMessage', (peer, label, data) => {
      if (data.type == 'volume') {
        this.showVolume(document.getElementById('volume_' + peer.id), data.volume);
      }
    });

    this.AudioWebRTC.on('volumeChange', (volume, treshold) => {
      this.showVolume(document.getElementById('localVolumeAudio'), volume);
    });
    //change...
    this.AudioWebRTC.on("connectionReady", audioPeerId => {
      this.audioPeerId = audioPeerId;
    });

    this.AudioWebRTC.on("joinedRoom", room => {
      //----Update the msg also
      let users = this.dataService.getFriends();
      let user = " ";
      for (let i = 0; i < users.length; i++) {
        if (partnerId === users[i].userId) {
          user = users[i].username;
        }
      }
      this.startTime = new Date();
      this.spinnerService.show();
      //----
      let payload = { "type": "messages" };
      this.dataService.sendInfo("group", payload);
      //----
      //---
      this.sendInfo("join", {
        "audioPeerId": this.audioPeerId,
        "username": this.dataService.getLoggedInUser().username,
        "uid": this.dataService.getLoggedInUser().uid
      });
      // this.AudioWebRTC.sendToAll("join", { "audioPeerId": this.audioPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
    });

    // this.AudioWebRTC.connection.on("message", data => {
    //   if (data.type == "join") {
    //     this.addRemotePeer(data.payload);
    //   } else if (data.type === "acknowledge") {
    //     this.updateRemotePeer(data.payload);
    //   }
    // });

    this.AudioWebRTC.on("createdPeer", peer => {
      if (!this.isPeerCaller)
        this.dataService.setGroupPeers({ "type": "audio", "peers": this.AudioWebRTC.getPeers() });
    });


    this.AudioWebRTC.on('videoAdded', (video, peer) => {
      this.dataService.setGroupPeers({ "type": "audio", "peers": this.AudioWebRTC.getPeers() });
      console.log('Audio added', peer);
      var audios = document.getElementById('remoteAudios');
      if (audios) {
        if (this.isPeerCaller) {
          let muteBtn = document.createElement("button");
          let iconmute = document.createElement('span');
          iconmute.className = 'glyphicon glyphicon-volume-off';
          let iconUnmute = document.createElement('span');
          iconUnmute.className = 'glyphicon glyphicon-volume-up';
          muteBtn.appendChild(iconmute)
          muteBtn.style.position = 'fixed';
          muteBtn.style.display = 'block';
          muteBtn.style.visibility = 'visible';
          muteBtn.style.bottom = 10 + '%';
          muteBtn.style.left = 40 + '%';

          muteBtn.style.background = '#4CAF50';
          muteBtn.style.border = 'none';
          muteBtn.style.color = 'white';
          muteBtn.style.padding = 15 + 'px';
          muteBtn.style.textAlign = 'center';
          muteBtn.style.textDecoration = 'none';
          muteBtn.style.display = 'inline-block';
          muteBtn.style.borderRadius = 30 + 'px';
          muteBtn.addEventListener("click", () => {
            if (this.ismute) {
              this.mutePeer(peer.id, true);
              this.ismute = false;
              muteBtn.removeChild(iconmute);
              muteBtn.appendChild(iconUnmute)
            } else {
              this.mutePeer(peer.id, false);
              this.ismute = true;
              muteBtn.removeChild(iconUnmute)
              muteBtn.appendChild(iconmute)
            }
          });

          let rowDiv = document.createElement('div');
          rowDiv.id = "" + peer.id;
          rowDiv.setAttribute('class', 'row');

          let colDiv = document.createElement('div');
          colDiv.setAttribute('class', 'col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12');

          colDiv.appendChild(muteBtn);
          colDiv.appendChild(video);

          rowDiv.appendChild(colDiv);
          audios.appendChild(rowDiv);
        } else {
          var container = document.getElementById("audio_container");
          if (!container) {
            container = document.createElement('div');
            container.id = "audio_container";
            container.style.position = 'fixed';
            container.style.display = 'block';
            container.style.left = 1 + '%';
            container.style.top = 10 + '%';
            container.style.minWidth = 150 + 'px';
            container.style.height = 95 + '%';
            //container.style.backgroundColor = 'cyan';
            container.style.overflow = 'auto';
            container.style.padding = 10 + 'px';
            container.style.zIndex = '199';
          }

          var box = document.createElement('div');
          box.id = "" + peer.id;
          box.style.margin = 10 + 'px';
          box.style.textAlign = 'center';
          box.style.margin = 10 + 'px';
          box.style.border = '5px solid white';
          box.style.borderStyle = 'dotted';
          box.style.borderRadius = 15 + 'px';

          let timer: any = Observable.timer(0, 100);
          let subscription = timer.subscribe(data => {
            let peerObj = this.getRemotePeer(peer.id);
            if (peerObj) {
              var username = document.createElement('div');
              this.currentGroupPeerId = peerObj.uid;
              username.innerHTML = "<center>" + peerObj.username + "</center>";
              username.style.display = 'block';
              username.style.color = 'teal';
              username.style.fontSize = 18 + 'px';
              username.style.margin = 10 + 'px';
              box.insertAdjacentElement('afterbegin', username)
              subscription.unsubscribe();
            }
          });

          if (this.dataService.getGroupAdminStatus()) {
            let muteBtn = document.createElement("button");
            muteBtn.innerHTML = "Mute";
            muteBtn.style.width = 70 + 'px';
            muteBtn.style.height = 30 + 'px';
            muteBtn.style.background = '#4CAF50';
            muteBtn.style.border = 'none';
            muteBtn.style.color = 'white';
            muteBtn.style.textAlign = 'center';
            muteBtn.style.margin = 10 + 'px';
            muteBtn.style.borderRadius = 30 + 'px';

            muteBtn.addEventListener("click", () => {
              if (muteBtn.innerHTML == "Mute") {
                this.mutePeer(peer.id, true);
                muteBtn.innerHTML = "UnMute";
              } else {
                this.mutePeer(peer.id, false);
                muteBtn.innerHTML = "Mute";
              }
            });

            box.appendChild(muteBtn);
          }

          video.style.width = 5 + 'px';
          video.style.width = 5 + 'px';

          box.appendChild(video);
          container.appendChild(box);
          audios.appendChild(container);
        }

      }
      this.startRecording(peer);
    });

    this.AudioWebRTC.on('videoRemoved', (video, peer) => {
      console.log('audio removed ', peer);
      this.stopRecording();
      this.dataService.setGroupPeers({ "type": "audio", "peers": this.AudioWebRTC.getPeers() });

      if (this.isPeerCaller) {
        var audios = document.getElementById('remoteAudios');
        var el = document.getElementById("" + peer.id);
        audios.removeChild(el);
      } else {
        var audios = document.getElementById("audio_container");
        var el = document.getElementById("" + peer.id);
        audios.removeChild(el);
      }

      if (this.isPeerCaller) {
        this.closeAudioChat();
        console.log("Closing Call Audio Service");

        this.dataService.stopChat("StopAudio", true, this.isPeerCaller);
      } else if (this.AudioWebRTC.getPeers() && this.AudioWebRTC.getPeers().length == 0) {
        this.closeAudioChat();
        this.dataService.stopChat("StopAudio", true, this.isPeerCaller);
      }
    });
  }

  showVolume(el, volume) {
    if (!el) return;
    if (volume < -45) { // vary between -45 and -20
      el.style.height = '0px';
    } else if (volume > -20) {
      el.style.height = '100%';
    } else {
      el.style.height = '' + Math.floor((volume + 100) * 100 / 25 - 220) + '%';
    }
  }

  closeAudioChat() {
    //---
    this.spinnerService.hide();
    if (this.startTime) {
      this.endTime = new Date();
      this.callDuration = Math.round((this.endTime - this.startTime) / 1000);
      if (this.isPeerCaller) {
        this.dataService.updateChatMessages("Voice call ended, duration: " + this.callDuration + " s", this.dataService.getCurrentPartnerId());
      } else {
        this.dataService.updateGroupChatMessages("Group audio call ended, duration: " + this.callDuration + " s", this.dataService.getCurrGroupID(), this.dataService.getLoggedInUser().uid);
      }
      //----
      let payload = { "type": "messages" };
      this.dataService.sendInfo("group", payload);
      //----
      this.startTime = null;
      this.endTime = null;
    }
    //----
    if (this.AudioWebRTC && this.AudioWebRTC.connection) {
      this.AudioWebRTC.stopLocalVideo();
      this.AudioWebRTC.connection.disconnect();
      this.AudioWebRTC = null;
      this.dataService.setGroupAnswerWaitingStatus(false);
      this.dataService.setGroupPeers(null);
    }
    this.callsInProgress = {};
  }

  //----------------new RTC ------//
  recordRTC: any;
  startRecording(peer) {
    this.spinnerService.hide();
    if (this.isPeerCaller) {
      this.dataService.updateChatMessages("Voice call Started.", this.currentPartnerId);
    } else {
      this.dataService.updateGroupChatMessages("Group audio call started.", this.dataService.getCurrGroupID(), this.dataService.getLoggedInUser().uid);
    }
    let options = {
      mimeType: 'video/webm', // or video/webm\;codecs=h264 or video/webm\;codecs=vp9
      audioBitsPerSecond: 128000,
      videoBitsPerSecond: 128000
    };
    this.recordRTC = RecordRTC(peer.stream, options);
    //console.log("REcordRTC ==>", this.recordRTC);
    this.recordRTC.startRecording();


    // let mediaConstraints = {
    //   video: {
    //     mandatory: {
    //       minWidth: 1280,
    //       minHeight: 720
    //     }
    //   }, audio: true
    // };
    // navigator.mediaDevices
    //   .getUserMedia(mediaConstraints)
    //   .then(this.successCallback.bind(this), this.errorCallback.bind(this));


  }

  stopRecording() {
    this.spinnerService.hide();
    this.recordRTC.stopRecording(
      () => {
        //console.log("RecordingStopped==>", this.recordRTC.blob);
        // let recordedBlob = Object.assign({}, this.recordRTC.blob);
        let recordedBlob = this.recordRTC.blob;
        let audioFlle = "jetc_audio" + UUID.UUID() + ".webm";
        this.doUploadOnGoogleCloud(recordedBlob, audioFlle);
      }
    );
  }

  // stopRecording() {
  //   let recordRTC = this.recordRTC;
  //   recordRTC.stopRecording();
  //   let recordedBlob = Object.assign({}, recordRTC.blob);

  //   //console.log("for Cloud post  ", recordRTC.blob);
  //   let audioFlle = "jetc_audio" + UUID.UUID() + ".webm";
  //   // let saved = recordRTC.save(recordRTC.blob);
  //   // let recordedBlob = recordRTC.blob;
  //   this.doUploadOnGoogleCloud(recordedBlob, audioFlle);
  //   // .subscribe(
  //   //   (res) => {
  //   //     //console.log(res);
  //   //      this.http.post(this.baseUrl + "urs/videos", {name:videoFlle, fromUId:this.loggedInUser.uid, toUId:this.currentPartnerId, timestamp:Date.now()}).subscribe(
  //   //     (res) => {
  //   //       //console.log("Uploaded the file to backend"+ res);
  //   //     },
  //   //     (err) => {
  //   //       //console.log(err);
  //   //     }
  //   //   );
  //   //     //recordRTC.stopRecording();
  //   //   }
  //   // );
  // }

  //---------------new RTC -----///

  doUploadOnGoogleCloud(imageData: Blob, imageName: any) {

    //console.log("for Cloud post  ", imageData);
    let Params = new HttpParams();
    Params = Params.append('uploadType', 'media');
    Params = Params.append('name', imageName);
    this.http.post(this.cloudUploadUrl, imageData, {
      params: Params
    }).subscribe(
      (res) => {
        //console.log(res);
        let currentPartnerId = this.dataService.getCurrentPartnerId();
        if (this.currentGroupPeerId && !this.isPeerCaller) {
          currentPartnerId = this.currentGroupPeerId;
        }
        this.http.post(this.baseUrl + "urs/audios", [{
          name: imageName, fromUId: this.dataService.getLoggedInUser().uid, toUId: currentPartnerId,
          timestamp: Date.now(), duration: this.callDuration, group: { id: this.getCurrGroupID }
        }]).subscribe(
          (res) => {
            console.log("Uploaded the file to backend" + res);
          },
          (err) => {
            console.log(err);
          }
        );
        //recordRTC.stopRecording();
      }
    );
  }


  //vinod
  addRemotePeer(remotePeer) {
    setTimeout(() => {

      this.sendInfo("acknowledge", {
        "audioPeerId": this.audioPeerId,
        "username": this.dataService.getLoggedInUser().username,
        "uid": this.dataService.getLoggedInUser().uid
      });
      // this.AudioWebRTC.sendToAll("acknowledge", { "audioPeerId": this.audioPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
    }, 2000);

    let status = true;
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].audioPeerId === remotePeer.audioPeerId) {
        this.groupPeers[i] = remotePeer;
        status = false;
      }
    }

    if (status && remotePeer.audioPeerId != this.audioPeerId) {
      this.groupPeers.push(remotePeer);
    }

    //console.log("add...", remotePeer);
  }

  updateRemotePeer(remotePeer) {
    let status = true;
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].audioPeerId === remotePeer.audioPeerId) {
        this.groupPeers[i] = remotePeer;
        status = false;
      }
    }

    if (status && remotePeer.audioPeerId != this.audioPeerId) {
      this.groupPeers.push(remotePeer);
    }
    //console.log("update...", remotePeer);
  }

  removeRemotePeer(peerId) {
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].audioPeerId === peerId) {
        //console.log("deleted...", this.groupPeers[i]);
        this.groupPeers.splice(i, 1);
        break;
      }
    }
  }


  getRemotePeer(peerId) {
    let remotePeer;
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].audioPeerId === peerId) {
        remotePeer = this.groupPeers[i];
        break;
      }
    }

    if (!remotePeer)
      return null;
    return remotePeer;
  }

  sendInfo(type, obj) {
    console.log("OBJ=>", obj);
    //console.log("Info message Sent !!");
    this.dataService.getStompService().publish('/app/send/audio', JSON.stringify({ type: type, payload: obj }));
  }



}