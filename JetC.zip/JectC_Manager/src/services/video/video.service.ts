import { Injectable, EventEmitter } from '@angular/core';
import SimpleWebRTC from 'simplewebrtc';
import * as RecordRTC from 'recordrtc';
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { UUID } from 'angular2-uuid';
import { DataServiceService } from "../data/data-service.service";
import { Observable } from 'rxjs/Rx';
import { ToasterService } from 'angular2-toaster';
import 'rxjs/add/operator/map';
import { Message } from '@stomp/stompjs';
import { StompConfig, StompService } from '@stomp/ng2-stompjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

interface FileShare {
  msg: any;
  meetingId: any;
  from: any;
}

declare const MediaRecorder: any;


@Injectable()
export class VideoService {

  private objStatus: any = false;
  private VideoWebRTC: any;
  private callsInProgress: any = {};
  public fileSharing: EventEmitter<FileShare> = new EventEmitter<FileShare>();
  private mediaRecorder: any;
  private cloudUploadUrl = "https://www.googleapis.com/upload/storage/v1/b/jetc-webrtc/o";
  private baseCloudUrl = "https://storage.googleapis.com/jetc-webrtc/urs199";
  private isPeerCaller: any = true;
  private groupPeers: any = [];
  private videoPeerId: any;
  public waiting: any = false;
  public state: any = false;
  // public baseUrl = "http://localhost:8090/WebRTC/";
  private baseUrl = "https://192.168.2.10:10391/Web_RTC/";
  private fullScreenVideoId;
  private fullScreenDivId;
  private fullScreenMuteBtnId;

  private loggedInUser: any;
  private groupPeer: any = [];
  private audioMuteType = "self";
  private startTime: any;
  private endTime: any;
  private callDuration: any;

  //drshn
  fullScreenWindow: any;

  constructor(public http: HttpClient, private dataService: DataServiceService,
    public toasterService: ToasterService,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.dataService.fileSharing.subscribe({
      next: (event: FileShare) => {
        if (event.msg === "websocketconnection") {
          this.initializeWebSocketConnection();
        }
        if (event.msg === "mute") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.videoPeerId === event.from[i].id) {
              //console.log("Peer Id Matched For Mute: ", event.from[i].id);
              if (this.VideoWebRTC) {
                this.VideoWebRTC.mute();
                this.audioMuteType = "admin_mute";
              }
            }
          }
        } else if (event.msg === "unmute") {
          for (let i = 0; i < event.from.length; i++) {
            if (this.videoPeerId === event.from[i].id) {
              //console.log("Peer Id Matched For UnMute: ", event.from[i].id);
              if (this.VideoWebRTC) {
                this.VideoWebRTC.unmute();
                this.audioMuteType = "admin_unmute";
              }
            }
          }
        }
      }
    });
  }


  initializeWebSocketConnection() {
    console.log("websocketConnectionInit");
    let stomp_subscription = this.dataService.getStompService().subscribe('/videoChat');
    stomp_subscription.map((message: Message) => {
      return message.body;
    }).subscribe((msg_body: string) => {
      let chatDTOReceived = JSON.parse(msg_body);
      chatDTOReceived.body.payload = {
        'from': +chatDTOReceived.body.payload.from,
        'gId': +chatDTOReceived.body.payload.gId,
        'id': chatDTOReceived.body.payload.id,
        'mid': chatDTOReceived.body.payload.mid,
        'partnerId': +chatDTOReceived.body.payload.partnerId,
        'pid': +chatDTOReceived.body.payload.pid,
        'sid': chatDTOReceived.body.payload.sid,
        'status': JSON.parse(chatDTOReceived.body.payload.status),
        'to': +chatDTOReceived.body.payload.to,
        'type': chatDTOReceived.body.payload.type,
        'uid': +chatDTOReceived.body.payload.uid,
        'unreadMessage': +chatDTOReceived.body.payload.unreadMessage,
        'userId': +chatDTOReceived.body.payload.userId,
        'userStatusIcon': chatDTOReceived.body.payload.userStatusIcon,
        'username': chatDTOReceived.body.payload.username,
        'message': chatDTOReceived.body.payload.message,
        'audioPeerId': chatDTOReceived.body.payload.audioPeerId
      };
      console.log(`VideoReceived:=>`, chatDTOReceived.body);
      this.receiveVideoMessage(chatDTOReceived.body);
    });
  }
  sendSecreenInfo(type, obj) {
    this.dataService.getStompService().publish('/app/send/video', JSON.stringify({ type: type, payload: obj }));
  }

  receiveVideoMessage(data) {
    if (data.type == "join") {
      this.addRemotePeer(data.payload);
    } else if (data.type === "acknowledge") {
      this.updateRemotePeer(data.payload);
    }
  }

  private currentGroupId: any;
  private currentPartnerId: any;

  getCurrentPartnerId() {
    return this.currentPartnerId;
  }

  setCurrentPartnerId(partnerId) {
    this.currentPartnerId = partnerId;
  }

  setCurrentUser(loggedInUser) {
    this.loggedInUser = loggedInUser;
  }

  setCurrentGroupId(groupID) {
    this.currentGroupId = groupID;
  }

  getCurrGroupID() {
    return this.currentGroupId;
  }

  setMeetingId(partnerId, meetingId) {
    this.callsInProgress[partnerId] = { "meeting": meetingId };
  }

  muteAll(muteStatus) {
    if (this.VideoWebRTC) {
      this.dataService.muteAll(this.VideoWebRTC.getPeers(), muteStatus);
    }
  }

  mutePeer(domId, muteStatus) {
    if (this.VideoWebRTC) {
      let peersArray = [];
      peersArray.push({ "id": domId });
      this.dataService.muteAll(peersArray, muteStatus);
    }
  }

  startVideoChatting(partnerId, meetingId, isPeerCaller, state) {
    if (document.getElementById('remotevideos'))
      document.getElementById('remotevideos').innerHTML = "";
    if (document.getElementById('groupVideos'))
      document.getElementById('groupVideos').innerHTML = "";

    this.isPeerCaller = isPeerCaller;
    this.state = state;
    this.fullScreenVideoId = null;


    let selfMuteBtn = document.createElement("button");
    selfMuteBtn.style.position = 'fixed';
    selfMuteBtn.style.top = 20 + '%';
    selfMuteBtn.style.right = 2 + '%';
    selfMuteBtn.innerText = 'Mute';
    selfMuteBtn.style.zIndex = '20';
    selfMuteBtn.style.borderStyle = 'none';
    selfMuteBtn.style.background = '#d9534f';
    selfMuteBtn.style.padding = '5px';
    selfMuteBtn.style.borderRadius = '5px';
    selfMuteBtn.style.color = 'white';

    selfMuteBtn.addEventListener("click", () => {
      if (selfMuteBtn.innerText == 'Mute' && (this.audioMuteType == 'self' || this.audioMuteType == 'admin_unmute') && this.VideoWebRTC) {
        this.VideoWebRTC.mute();
        selfMuteBtn.innerText = 'Unmute';
        selfMuteBtn.style.background = 'yellowgreen';
        console.log('***********mute');
      } else if (selfMuteBtn.innerText == 'Unmute' && this.audioMuteType != 'admin_mute' && this.VideoWebRTC) {
        this.VideoWebRTC.unmute();
        selfMuteBtn.innerText = 'Mute';
        selfMuteBtn.style.background = '#d9534f';
        console.log('***********Unmute');
      } else if (this.audioMuteType == 'admin_mute') {
        this.toasterService.pop('info', 'Permission denied !!', 'Muted By Group Admin');
      }
    });

    let videoBtn: any = selfMuteBtn.cloneNode(true);
    videoBtn.style.top = 20 + '%';
    videoBtn.style.right = 8 + '%';
    videoBtn.style.borderStyle = 'none';
    videoBtn.style.background = '#d9534f';
    videoBtn.style.padding = '5px';
    videoBtn.style.borderRadius = '5px';
    videoBtn.style.color = 'white';

    if (this.state)
      videoBtn.innerText = 'Pause';
    else
      videoBtn.innerText = 'Resume';

    videoBtn.addEventListener("click", () => {
      if (videoBtn.innerText == 'Pause') {
        this.VideoWebRTC.pause();
        videoBtn.style.background = 'yellowgreen';
        videoBtn.innerText = 'Resume';
      } else if (videoBtn.innerText == 'Resume') {
        this.VideoWebRTC.resume();
        videoBtn.style.background = '#d9534f';
        videoBtn.innerText = 'Pause';
      }
    });

    if (this.isPeerCaller) {
      if (this.callsInProgress[partnerId]) {
        meetingId = this.callsInProgress[partnerId]["meeting"];
      }
      else {
        this.callsInProgress[partnerId] = { "meeting": meetingId };
      }

      if (document.getElementById('remotevideos')) {
        document.getElementById('remotevideos').appendChild(selfMuteBtn);
        document.getElementById('remotevideos').appendChild(videoBtn);
      }

    } else {
      this.dataService.setGroupAnswerWaitingStatus(false);
      this.dataService.setGroupPeers(null);

      if (document.getElementById('groupVideos')) {
        document.getElementById('groupVideos').appendChild(selfMuteBtn);
        document.getElementById('groupVideos').appendChild(videoBtn);
      }

    }

    this.VideoWebRTC = new SimpleWebRTC({
      perMessageDeflate: false,
      localVideoEl: 'localVideo',
      remoteVideosEl: '',
      autoRequestMedia: true,
      debug: false,
      media: { video: true, audio: true },
      detectSpeakingEvents: true,
      nick: 'VK Kushwah',
      localVideo: {
        autoplay: true,
        mirror: false,
        muted: true
      },peerConnectionConfig: {
        "iceServers": [{
          urls: "stun:stun.l.google.com:19302"
        },
        {
          urls: "turn:139.59.58.0",
          username: "prouser",
          credential: "mypassword"
        }
        ]
      },
      // url: "https://192.168.2.10:10000"
      url: "https://192.168.2.210:8888/"
      
    });

    // this.VideoWebRTC.config.peerConnectionConfig.iceTransports = "relay";
    
    this.VideoWebRTC.on('readyToCall', () => {
      this.VideoWebRTC.joinRoom(meetingId);
    });

    this.VideoWebRTC.on('channelMessage', (peer, label, data) => {
      if (data.type == 'volume') {
        this.showVolume(document.getElementById('volume_' + peer.id), data.volume);
      }
    });

    this.VideoWebRTC.on('volumeChange', (volume, treshold) => {
      this.showVolume(document.getElementById('localVolume'), volume);
    });

    this.VideoWebRTC.on("connectionReady", videoPeerId => {
      this.videoPeerId = videoPeerId;
    });

    this.VideoWebRTC.on("joinedRoom", room => {
      //startTime
      //----Update the msg also
      let users = this.dataService.getFriends();
      console.log("OldUserList==> ", users);
      let user = " ";
      for (let i = 0; i < users.length; i++) {
        if (this.dataService.getCurrentPartnerId() === users[i].userId) {
          user = users[i].username;
          console.log("Unused User Matched =>", user);
        }
      }
      this.startTime = new Date();
      this.spinnerService.show();
      //----
      let payload = { "type": "messages" };
      this.dataService.sendInfo("group", payload);
      //----
      //---
      //this.VideoWebRTC.sendToAll("join", { "videoPeerId": this.videoPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
      this.sendSecreenInfo("join", { "videoPeerId": this.videoPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
    });

    // this.VideoWebRTC.connection.on("message__", data => {
    //   if (data.type == "join") {
    //     this.addRemotePeer(data.payload);
    //   } else if (data.type === "acknowledge") {
    //     this.updateRemotePeer(data.payload);
    //   }
    // });

    this.VideoWebRTC.on("createdPeer", peer => {
      if (!state) {
        this.VideoWebRTC.pauseVideo();
      }
      if (!this.isPeerCaller)
        this.dataService.setGroupPeers({ "type": "video", "peers": this.VideoWebRTC.getPeers() });
    });

    this.VideoWebRTC.on('videoAdded', (video, peer) => {
      console.log('video added', peer);
      var groupVideos = document.getElementById('groupVideos');
      // video.setAttribute('controls', 'controls');
      if (this.isPeerCaller) {
        this.dataService.updateChatMessages("Video call started.", partnerId);
      } else {
        this.dataService.updateGroupChatMessages("Group video call started.", this.dataService.getCurrGroupID(), this.dataService.getLoggedInUser().uid);
      }
      var remotevideos = document.getElementById('remotevideos');
      if (this.isPeerCaller && remotevideos) {
        var d = document.createElement('div');
        d.className = 'videoContainer';
        d.id = 'container_' + this.VideoWebRTC.getDomId(peer);
        video.style.position = 'fixed';
        video.style.display = 'block';
        video.style.top = 0 + 'px';
        video.style.left = 0 + 'px';
        video.style.right = 0 + 'px';
        video.style.bottom = 0 + 'px';
        video.style.overflow = 'visible';
        video.style.width = 100 + '%';
        video.style.height = 100 + '%';
        video.style.background = '#ccc';
        d.appendChild(video);

        video.oncontextmenu = () => { return false; };
        remotevideos.appendChild(d);
      } else if (!this.isPeerCaller && groupVideos) {

        let peerObject = { peerId: peer.id, fullScreen: false };

        var mainContainer = document.createElement('div');
        mainContainer.className = 'CssClass';
        mainContainer.id = '' + peer.id;
        mainContainer.style.position = 'relative';
        mainContainer.style.display = 'block';
        mainContainer.style.width = 100 + '%';
        mainContainer.style.height = '100%';

        let videoContainerRemote = document.createElement('div');
        videoContainerRemote.style.position = 'fixed';
        videoContainerRemote.style.display = 'block';
        videoContainerRemote.style.backgroundColor = '#c1c1c1';
        videoContainerRemote.style.top = '0%';
        videoContainerRemote.style.bottom = '0%';
        videoContainerRemote.style.left = '0%';
        videoContainerRemote.style.right = '0%';

        let sideBar = document.createElement('div');//sidebar for remote video
        sideBar.setAttribute('class', 'col-lg-3 col-md-3 col-sm-3');
        sideBar.setAttribute('id', 'div3');
        sideBar.style.height = '100%';
        sideBar.style.backgroundColor = '#c1c1c1';
        sideBar.style.overflow = 'auto';

        this.fullScreenWindow = document.createElement('div');//full screen video
        this.fullScreenWindow.setAttribute('class', 'col-lg-9 col-md-9 col-sm-9');
        this.fullScreenWindow.setAttribute('id', 'div9');
        this.fullScreenWindow.style.backgroundColor = 'grey';
        this.fullScreenWindow.style.height = '100%';

        setInterval(() => {
          const mq = window.matchMedia('(max-width:767px)');

          let localVideo = document.getElementById('localVideo');
          if (mq.matches) {
            sideBar.style.height = '50%';
            this.fullScreenWindow.style.height = '50%';
            mainContainer.style.width = 50 + '%';
            mainContainer.style.display = 'inline-block';
            localVideo.style.display = 'none';

          } else {
            sideBar.style.height = '100%';
            this.fullScreenWindow.style.height = '100%';
            mainContainer.style.width = 100 + '%';
            localVideo.style.display = 'block';
          }

          var mediaQueryList = window.matchMedia("(orientation: landscape)");
          if (mediaQueryList.matches) {
            sideBar.style.height = '100%';
            this.fullScreenWindow.style.height = '100%';
            mainContainer.style.width = 100 + '%';
            mainContainer.style.display = 'block';
            localVideo.style.display = 'block';
          }



        }, 1000);


        let remoteHeaderBar = document.createElement('div');//remtoe header bar row....
        remoteHeaderBar.setAttribute('class', 'row');

        let muteBtnCol = document.createElement('div'); //for remote mute btn col
        muteBtnCol.setAttribute('class', 'col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-4');

        let usernameCol = document.createElement('div'); // for remote username col
        usernameCol.setAttribute('class', 'col-xl-8 col-lg-8 col-md-8 col-sm-8 col-xs-8');

        let muteBtn = document.createElement('button');
        if (this.dataService.getGroupAdminStatus()) {
          muteBtn.innerHTML = "Mute";
          muteBtn.style.width = 65 + 'px';
          muteBtn.style.height = 30 + 'px';
          muteBtn.style.background = 'yellowgreen';
          muteBtn.style.border = 'none';
          muteBtn.style.borderRadius = 15 + 'px';
          muteBtn.style.color = 'white';
          muteBtn.style.margin = '10px';

          muteBtn.addEventListener("click", () => {
            if (muteBtn.innerHTML == "Mute") {
              this.mutePeer(peer.id, true);
              muteBtn.innerHTML = "UnMute";
            } else {
              this.mutePeer(peer.id, false);
              muteBtn.innerHTML = "Mute";
            }
          });

          muteBtnCol.appendChild(muteBtn);
          //mainContainer.appendChild(muteBtn);
        }

        video.style.display = 'block';
        video.style.width = 100 + '%';
        video.style.margin = 5 + 'px';
        video.style.zIndex = '20';
        const mq = window.matchMedia('(max-width:499px)');
        if (mq.matches) {
          mainContainer.style.marginTop = 90 + '%';
        }

        mainContainer.ondblclick = () => {
          //full screen...
          video.play();
          this.setFullScreenStyles(peer);
        };

        let timer: any = Observable.timer(0, 100);
        let subscription = timer.subscribe(data => {
          let peerObj = this.getRemotePeer(peer.id);
          if (peerObj) {
            var username = document.createElement('label');
            username.innerHTML = peerObj.username + " ";
            username.style.color = 'cyan';
            username.style.fontSize = 20 + 'px';
            username.style.margin = 5 + 'px';
            usernameCol.appendChild(username);
            // mainContainer.appendChild(username);
            subscription.unsubscribe();
          }
        })

        video.oncontextmenu = () => { return false; };

        let remoteVideo = document.createElement('div');//remtoe header bar
        remoteVideo.setAttribute('class', 'row');

        let remoteVideoCol = document.createElement('div'); //for remote mute btn
        remoteVideoCol.setAttribute('class', 'col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12');
        remoteVideoCol.appendChild(video);
        remoteVideo.appendChild(remoteVideoCol);

        remoteHeaderBar.appendChild(muteBtnCol);
        remoteHeaderBar.appendChild(usernameCol);

        mainContainer.appendChild(remoteHeaderBar);
        mainContainer.appendChild(remoteVideo);
        groupVideos.appendChild(mainContainer);
        groupVideos.style.overflow = 'auto';
        groupVideos.style.marginTop = '50px';

        var mainRow = document.getElementById('mainRowForVideo');
        sideBar.appendChild(groupVideos);
        videoContainerRemote.appendChild(sideBar);
        videoContainerRemote.appendChild(this.fullScreenWindow);
        mainRow.appendChild(videoContainerRemote);
        // sideBar.appendChild(remoteHeaderBar);
        // sideBar.appendChild(remoteVideo);

        // mainContainer.appendChild(sideBar);
        // mainContainer.appendChild(this.fullScreenWindow);

      }
      this.startRecording(peer);
    });



    this.VideoWebRTC.on('videoRemoved', (video, peer) => {
      console.log('video removed >>>>>', peer);
      this.stopRecording();// stop record      
      if (this.isPeerCaller) {
        var remotes = document.getElementById('remotevideos');
        let localVideoContainer = document.getElementById('videoContainer');
        let localVideo = document.getElementById('localVideo');
        var el = document.getElementById('container_' + this.VideoWebRTC.getDomId(peer));
        if (remotes && el) {
          remotes.removeChild(el);
        }
        this.closeVideoChat();
        this.dataService.stopChat("StopVideo", true, this.isPeerCaller);
      } else {
        let ele = document.getElementById(peer.id);
        let groupVideos = document.getElementById('groupVideos');
        groupVideos.removeChild(ele);

        if (this.VideoWebRTC.getPeers() && this.VideoWebRTC.getPeers().length == 0) {
          this.closeVideoChat();
          this.dataService.stopChat("StopVideo", true, this.isPeerCaller);
        }
      }
    });
  }

  showVolume(el, volume) {
    if (!el) return;
    if (volume < -45) { // vary between -45 and -20
      el.style.height = '0px';
    } else if (volume > -20) {
      el.style.height = '100%';
    } else {
      el.style.height = '' + Math.floor((volume + 100) * 100 / 25 - 220) + '%';
    }
  }

  // end video call
  closeVideoChat() {
    //---
    console.log("!!! CloseVideoChat is called... !!!");
    if (this.startTime) {
      this.endTime = new Date();
      this.callDuration = Math.round((this.endTime - this.startTime) / 1000);
      this.spinnerService.hide();
      if (this.isPeerCaller) {
        this.dataService.updateChatMessages("Video call ended, duration: " + this.callDuration + " s", this.dataService.getCurrentPartnerId());
      } else {
        this.dataService.updateGroupChatMessages("Group video call ended, duration: " + this.callDuration + " s", this.dataService.getCurrGroupID(), this.dataService.getLoggedInUser().uid);
      }
      //----
      let payload = { "type": "messages" };
      this.dataService.sendInfo("group", payload);
      //----
      this.startTime = null;
      this.endTime = null;
    }
    //----
    if (this.VideoWebRTC && this.VideoWebRTC.connection) {
      this.VideoWebRTC.stopLocalVideo();
      this.VideoWebRTC.connection.disconnect();
      this.VideoWebRTC = null;
      this.dataService.setGroupAnswerWaitingStatus(false);
      this.dataService.setGroupPeers(null);
    }
    this.callsInProgress = {};
  }

  //----------------new RTC ------//
  recordRTC: any;
  startRecording(peer) {
    this.spinnerService.hide();
    let options = {
      mimeType: 'video/webm;codecs=vp9', // or video/webm\;codecs=h264 or video/webm\;codecs=vp9
      audioBitsPerSecond: 128000,
      videoBitsPerSecond: 128000,
      video: true,
      audio: true
    };
    this.recordRTC = RecordRTC(peer.stream, options);
    //console.log("REcordRTC ==>", this.recordRTC);
    this.recordRTC.startRecording();
  }

  stopRecording() {
    this.spinnerService.hide();
    this.recordRTC.stopRecording(
      () => {
        //console.log("RecordingStopped==>", this.recordRTC.blob);
        // let recordedBlob = Object.assign({}, this.recordRTC.blob);
        let recordedBlob = this.recordRTC.blob;
        let videoFlle = "jetc_video" + UUID.UUID() + ".webm";
        this.doUploadOnGoogleCloud(recordedBlob, videoFlle);
      }
    );
  }

  //---------------new RTC -----///

  doUploadOnGoogleCloud(imageData: Blob, imageName: any) {

    //console.log("for Cloud post  ", imageData);
    let Params = new HttpParams();
    Params = Params.append('uploadType', 'media');
    Params = Params.append('name', imageName);
    this.http.post(this.cloudUploadUrl, imageData, {
      params: Params
    }).subscribe(
      (res) => {
        console.log(res);

        this.http.post(this.baseUrl + "urs/videos", [{ name: imageName, fromUId: this.loggedInUser.uid, toUId: this.currentPartnerId, timestamp: Date.now(), duration: this.callDuration, group: { id: this.getCurrGroupID } }]).subscribe(
          (res) => {
            console.log("Uploaded the file to backend" + res);
          },
          (err) => {
            console.log("err while video call ... ", err);
          }
        );

      }
    );
  }



  //vinod

  addRemotePeer(remotePeer) {
    setTimeout(() => {
      //this.VideoWebRTC.sendToAll("acknowledge", { "videoPeerId": this.videoPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
      this.sendSecreenInfo("acknowledge", { "videoPeerId": this.videoPeerId, "username": this.dataService.getLoggedInUser().username, "uid": this.dataService.getLoggedInUser().uid });
    }, 2000);

    let status = true;
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].videoPeerId === remotePeer.videoPeerId) {
        this.groupPeers[i] = remotePeer;
        status = false;
      }
    }

    if (status && remotePeer.videoPeerId != this.videoPeerId) {
      this.groupPeers.push(remotePeer);
    }

    //console.log("add...", remotePeer);
  }

  updateRemotePeer(remotePeer) {
    let status = true;
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].videoPeerId === remotePeer.videoPeerId) {
        this.groupPeers[i] = remotePeer;
        status = false;
      }
    }

    if (status && remotePeer.videoPeerId != this.videoPeerId) {
      this.groupPeers.push(remotePeer);
    }
    //console.log("update...", remotePeer);
  }

  removeRemotePeer(peerId) {
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].videoPeerId === peerId) {
        //console.log("deleted...", this.groupPeers[i]);
        this.groupPeers.splice(i, 1);
        break;
      }
    }
  }

  getRemotePeer(peerId) {
    let remotePeer;
    for (let i = 0; i < this.groupPeers.length; i++) {
      if (this.groupPeers[i].videoPeerId === peerId) {
        remotePeer = this.groupPeers[i];
        break;
      }
    }

    if (!remotePeer)
      return null;
    return remotePeer;
  }


  //drshn
  setFullScreenStyles(peerV) {
    var bigScreen = document.createElement('video');
    // bigScreen.id ="big_screen_"+divId;
    bigScreen.setAttribute('src', window.URL.createObjectURL(peerV.stream));
    bigScreen.style.width = 100 + '%';
    bigScreen.style.height = 100 + '%';
    bigScreen.play();
    this.fullScreenWindow.innerHTML = "";
    this.fullScreenWindow.appendChild(bigScreen);
  }

}