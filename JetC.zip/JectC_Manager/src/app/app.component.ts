import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../services/data/data-service.service';
import 'style-loader!angular2-toaster/toaster.css';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  searchName = '';
  loggedInUser: any;
  remoteUser: any;
  
  constructor(private router: Router, private dataService: DataServiceService) { }

}
