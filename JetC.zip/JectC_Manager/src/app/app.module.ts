import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { Ng2FileDropModule } from 'ng2-file-drop';
import { AppComponent } from './app.component';
import { PageNotFoundComponent } from '../pages/page-not-found/page-not-found.component';
import { SignupComponent } from '../pages/sign-up/sign-up.component';
import { DataServiceService } from '../services/data/data-service.service';
import { MyFilterPipePipe } from '../services/filter/my-filter-pipe.pipe';
import { HomeComponent } from '../pages/home/home.component';
import { TokenInterceptorService } from '../services/token-interceptor/token-interceptor.service';
import { LoginPageComponent } from '../pages/login-page/login-page.component';
import { MyProfileComponent } from '../pages/my-profile/my-profile.component';
import { ForgotPasswordComponent } from '../pages/forgot-password/forgot-password';

import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { WebcamModule } from 'ngx-webcam';
import { Ng2CarouselamosModule } from 'ng2-carouselamos';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { AvatarModule } from 'ngx-avatar';
import { PopoverModule } from 'ng2-popover';
import { UserFliterPipe } from '../services/filter/user-fliter.pipe';
import { VideoService } from '../services/video/video.service';
import { AudioService } from '../services/audio/audio.service';
import { ScreenService } from '../services/screen/screen.service';
import { AdminComponent } from '../pages/admin/admin.component';

import { ToasterModule } from 'angular2-toaster';
import { NgxPaginationModule } from 'ngx-pagination';
import { RecordsFilterPipe } from '../services/filter/records-filter-pipe.pipe';
import { UUID } from 'angular2-uuid';
import { ManagerComponent } from '../pages/manager/manager.component';

const appRoutes: Routes = [

  { path: '', component: LoginPageComponent, pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginPageComponent, pathMatch: 'full' },
  { path: 'profile', component: MyProfileComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'manager', component: ManagerComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'resetPassword/:userId/:resetToken', component: ForgotPasswordComponent },
  { path: '**', component: PageNotFoundComponent }

];

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent,
    MyFilterPipePipe,
    HomeComponent,
    LoginPageComponent,
    UserFliterPipe,
    AdminComponent,
    RecordsFilterPipe,
    MyProfileComponent,
    ForgotPasswordComponent,
    SignupComponent,
    ManagerComponent
  ],
  imports: [
    BrowserModule, HttpClientModule, AngularFontAwesomeModule,ReactiveFormsModule,
    FormsModule, Ng2FileDropModule, AvatarModule, WebcamModule,
    PopoverModule, NgxPaginationModule, Ng2CarouselamosModule,
    BrowserAnimationsModule, ToasterModule, InfiniteScrollModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    ),
    Ng4LoadingSpinnerModule.forRoot()
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true
    },
    DataServiceService,
    VideoService,
    AudioService, UUID,
    ScreenService],
  bootstrap: [AppComponent]
})
export class AppModule { }


