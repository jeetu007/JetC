import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataServiceService } from '../../services/data/data-service.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  logginUser: any;
  userList: any = [];
  textChats: any = [];
  videoChats: any = [];
  audioChats: any = [];
  fileShares: any = [];
  searchTerm: any;

  textChatBoolean: boolean = true;
  videoChatBoolean: boolean = false;
  audioChatBoolean: boolean = false;
  fileShareBoolean: boolean = false;

  recordName: any;
  
  //pagination variables
  pageNo: any = 1;
  pageSize: any = 10;
  pagerSize: any = 4;

  totalTextChatRecord: any;
  totalAudioChatRecord: any;
  totalVideoChatRecord: any;
  totalFileShareRecord: any;
  chatHistory: boolean = false;
  chatRecords: any;
  shownGroup: any = null;

  constructor(public dataService: DataServiceService, public router: Router) {

    dataService.getUserList().subscribe(response => {
      this.dataService.setCompleteUserList(response);
    });

    this.getRecordHistory(this.pageNo, "textchat");

    this.logginUser = dataService.getLoggedInUser();

  }//constructor

  getRecordHistory(pageNo: any, recordName: any) {

    this.userList = this.dataService.getCompleteUserList();


 if (this.userList) {
      this.dataService.getRecordsHistory(recordName, pageNo, this.pageSize).subscribe(res => {
        
        if (res.audioChats.length > 0) {
          this.totalAudioChatRecord = res.audioChats[0].totalRecordsOfAudioChats;
          this.audioChats = this.assignName(res.audioChats);
        }
        if (res.fileShares.length > 0) {
          this.totalFileShareRecord = res.fileShares[0].totalRecordsOfFileShare;
          this.fileShares = this.assignName(res.fileShares);
        }
        if (res.textChats.length > 0) {
          this.totalTextChatRecord = res.textChats[0].totalRecordsOfTextChats;
          this.textChats = this.assignName(res.textChats);
        }
        if (res.videoChats.length > 0) {
          this.totalVideoChatRecord = res.videoChats[0].totalRecordsOfVideoChats;
          this.videoChats = this.assignName(res.videoChats);
        }




    // if (this.userList) {
    //   this.dataService.getRecordsHistory(recordName, pageNo, this.pageSize).subscribe(res => {

        // if (res.audioChats) {
        //   if(res.audioChats.length>0){
        //   this.totalAudioChatRecord = res.audioChats[0].totalRecordsOfAudioChats;
        //   }else{
        //     this.totalAudioChatRecord = 0;
        //   }
        //   this.audioChats = this.assignName(res.audioChats);
        // }
        // if (res.fileShares) {
        //   if(res.fileShares.length>0){
        //   this.totalFileShareRecord = res.fileShares[0].totalRecordsOfFileShare;
        //   }else{
        //     this.totalFileShareRecord = 0;
        //   }
        //   this.totalFileShareRecord = res.fileShares[0].totalRecordsOfFileShare;
        //   this.fileShares = this.assignName(res.fileShares);
        // }
        // if (res.textChats) {
        //   if(res.textChats.length > 0){
        //   this.totalTextChatRecord = res.textChats[0].totalRecordsOfTextChats;

        //   }
        //   else{
        //   this.totalTextChatRecord = 0;

        //   }
        //   this.textChats = this.assignName(res.textChats);
        // }
        // if (res.videoChats) {
        //   if(res.videoChats.length > 0){
        //   this.totalVideoChatRecord = res.videoChats[0].totalRecordsOfVideoChats;
        //   }else{
        //   this.totalVideoChatRecord = 0;
        //   }
          
        //   this.videoChats = this.assignName(res.videoChats);
        // }

      }); //get the records detail
    }
  }//getRecordHistory(-,-)

  assignName(chat: any) {

    for (let i in chat) {

      for (let j in this.userList) {

        if (chat[i].fromUId == this.userList[j].userId) {
          chat[i].fromUId = this.userList[j].firstName + " " + this.userList[j].lastName;
        }//if -- checking the sender id

        if (chat[i].toUId == this.userList[j].userId) {
          chat[i].toUId = this.userList[j].firstName + " " + this.userList[j].lastName;
        }//if -- checking the reciever id

      }//inner-for

    }//outer-for

    return chat;

  }//assignName(-)

  getFileContents(fileName: any, index: any) {
    if (this.isGroupShown(index)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = index;
    }

    this.dataService.getTextFileContents(fileName).subscribe(res => {
      //console.log(res);

      for (var i in res) {
        res[i].uid = 1;
      }

      this.chatRecords = res;

      this.chatHistory = true;
    });

  }//getFileContents(-,-)

  openVideo(index: any) {
    if (this.isGroupShown(index)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = index;
    }
  }//openVideo(-)


openAudio(index: any) {
    if (this.isGroupShown(index)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = index;
    }
  }//openVideo(-

  isGroupShown(group) {
    return this.shownGroup === group;
  }//isGroupShown(-)

  ngOnInit() { 

   try{
   
    if(!localStorage.getItem('token') || !localStorage.getItem("loginUserDetail") || !localStorage.getItem("access_token")){
      this.logout();
    }
    // this.loggedInUser =  JSON.parse(localStorage.getItem('token'));
    // peerConnectionConfig = JSON.parse(localStorage.getItem("peerConnectionConfig"));
    
   }catch (err) {
      this.logout(); 
      // return;
    }

  }

  showTextChatTable() {
    this.pageNo = 1;
    this.searchTerm = "";
    this.getRecordHistory(this.pageNo, "textchat");
    this.textChatBoolean = true;
    this.videoChatBoolean = false;
    this.audioChatBoolean = false;
    this.fileShareBoolean = false;
  }//showTextChatTable()

  showAudioChatTable() {
    this.pageNo = 1;
    this.searchTerm = "";
    this.getRecordHistory(this.pageNo, "audiochat");
    this.textChatBoolean = false;
    this.videoChatBoolean = false;
    this.audioChatBoolean = true;
    this.fileShareBoolean = false;
  }//showAudioChatTable()

  showVideoChatTable() {
    this.pageNo = 1;
    this.searchTerm = "";
    this.getRecordHistory(this.pageNo, "videochat");
    this.textChatBoolean = false;
    this.videoChatBoolean = true;
    this.audioChatBoolean = false;
    this.fileShareBoolean = false;
  }//showVideoChatTable()

  showFileShareTable() {
    this.pageNo = 1;
    this.searchTerm = "";
    this.getRecordHistory(this.pageNo, "fileshare");
    this.textChatBoolean = false;
    this.videoChatBoolean = false;
    this.audioChatBoolean = false;
    this.fileShareBoolean = true;
  }//showFileShareTable()

  pageChanged(ev: any) {

    //console.log(ev);

    this.pageNo = ev;

    if (this.textChatBoolean) {
      this.recordName = "textchat";
    } else if (this.videoChatBoolean) {
      this.recordName = "videochat";
    } else if (this.audioChatBoolean) {
      this.recordName = "audiochat";
    } else if (this.fileShareBoolean) {
      this.recordName = "fileshare";
    }

    this.getRecordHistory(ev, this.recordName);

  }//pageChanged(-)

  logout() {

    this.dataService.logout()
      .subscribe(
      res => {
        //console.log(res);
        this.router.navigate(['/login']);
      },
      err => this.router.navigate(['/login'])
      );

  }//logout()

}//class