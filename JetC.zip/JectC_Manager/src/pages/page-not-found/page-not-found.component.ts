import { Component, OnInit } from '@angular/core';
import { DataServiceService } from "../../services/data/data-service.service";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {

  constructor(private dataService: DataServiceService, private route: ActivatedRoute) { }

  loggedInUserId: number;
  public userDetail: any;
  private sub: any;

  ngOnInit() {
  }

  ngAfterViewInit() {
    this.sub = this.route.params.subscribe(params => {
      this.loggedInUserId = +params['userId'];
      console.log("ID=>",this.loggedInUserId);
      this.dataService.getUserById(this.loggedInUserId)
        .subscribe(res => {
          this.userDetail = res;
        }, err => {
          console.log("Error getting userdetail", err);
        });
    });
  }

}
