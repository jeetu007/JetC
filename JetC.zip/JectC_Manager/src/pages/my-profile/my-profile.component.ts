import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataServiceService } from '../../services/data/data-service.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { UUID } from 'angular2-uuid';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ToasterService } from 'angular2-toaster';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {


  loggedInUserId: number;
  public userDetail: any;
  private sub: any;
  public currentProfilePic: any;
  public cloudImageURL: any;
  public showWebcam = false;
  private newImages: any = [];
  public staticUserProfilePic: any;
  private imageList: any = [];

  public user = { firstname: undefined, lastname: undefined, mobile: undefined, username: undefined };

  // latest snapshot
  public webcamImage: any = null;

  constructor(private route: ActivatedRoute, private dataService: DataServiceService,
    private UUID: UUID, private spinnerService: Ng4LoadingSpinnerService, public toasterService: ToasterService) { }

  ngOnInit() {
    this.staticUserProfilePic = this.dataService.staticUserProfilePic;
  }

  ngAfterViewInit() {
    this.cloudImageURL = this.dataService.cloudImageUrl;
    this.sub = this.route.params.subscribe(params => {
      this.loggedInUserId = +params['id'];
      this.getUserDetail();
    });
  }

  getUserDetail() {
    this.dataService.getUserById(this.loggedInUserId)
      .subscribe(res => {
        this.userDetail = res;
        console.log("userDetail =>", res);
        if (this.userDetail && this.userDetail.userImages && this.userDetail.userImages.length > 0) {
          this.userDetail.userImages.forEach(element => {
            if (element.selectedAsDP) {
              this.currentProfilePic = this.dataService.cloudImageUrl + element.imageName;
            }
          });
        }
      }, err => {
        console.log("Error getting userdetail", err);
      });
  }

  selectImageToDelete(image) {
    this.imageList.push({ "imageId": image.imageId });
    console.log("ImageId = > ", image.imageId);
  }

  deleteSelectedUserImage() {
    if (this.userDetail) {
      this.dataService.deleteSelectedUserImages(this.userDetail.userId, this.imageList)
        .subscribe(res => {
          console.log("DeleteImage_RES=>", res);
          this.imageList = [];
          this.getUserDetail();
        }, err => {
          console.log("DeleteImage_ERR=>", err);
        });
    } else {
      console.log("User doesn't exist.");
    }
  }

  presentToast(cssClass, message) {
    this.toasterService.pop(cssClass, message);
  }

  getFile(e) {
    let acceptedFile = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    let filename = UUID.UUID();
    console.log(filename);
    this.newImages.push({
      imageName: filename,
      selectedAsDP: true
    });
    this.userDetail.newImages = this.newImages;
    this.spinnerService.show();
    this.dataService.doUploadOnGoogleCloud(acceptedFile, filename)
      .subscribe(res => {
        console.log(res);
        this.saveOrUpdateUserInformation();
      }, err => {
        console.log(err);
      });
  }

  onSubmit() {
    if (!this.user.firstname && !this.user.lastname &&
      !this.user.mobile && !this.user.username) {
      this.presentToast("danger", "Please choose any one field to update!");
    }
    else {
      if (this.user.firstname) {
        this.userDetail.firstName = this.user.firstname;
      }
      if (this.user.lastname) {
        this.userDetail.lastName = this.user.lastname;
      }
      if (this.user.mobile) {
        this.userDetail.mobile = this.user.mobile;
      }
      if (this.user.username) {
        this.userDetail.username = this.user.username;
      }
      this.userDetail.newImages = this.newImages;
      this.saveOrUpdateUserInformation();
    }
  }

  saveOrUpdateUserInformation() {
    this.dataService.updateUserInfo(this.userDetail)
      .subscribe(res => {
        this.userDetail = res;
        this.spinnerService.hide();
        window.location.reload();
        this.presentToast("success", "Profile Updated!");
      }, err => {
        console.log("Backend==>", err);
      });
  }

  // saveUserImageData(filename) {
  //   this.dataService.saveUserImageData(filename, this.loggedInUserId)
  //     .subscribe(res => {
  //       this.userDetail = res;
  //       console.log("Backend UserDetail==>", this.userDetail);
  //       window.location.reload();
  //     }, err => {
  //       console.log("Backend==>", err);
  //     });
  // }

  // webcam snapshot trigger
  private trigger: Subject<void> = new Subject<void>();

  public triggerSnapshot(): void {
    this.trigger.next();
  }

  public toggleWebcam(): void {
    this.showWebcam = !this.showWebcam;
  }

  public handleImage(webcamImage: any): void {
    console.info("received webcam image", webcamImage);
    this.webcamImage = webcamImage;
    let filename = UUID.UUID();
    this.newImages.push({
      imageName: filename,
      selectedAsDP: true
    });
    this.userDetail.newImages = this.newImages;
    let imageBlob = this.convertImage(this.webcamImage._imageAsDataUrl, "image/jpeg");
    this.spinnerService.show();
    this.dataService.doUploadOnGoogleCloud(imageBlob, filename)
      .subscribe(res => {
        console.log(res);
        this.saveOrUpdateUserInformation();
      }, err => {
        console.log(err);
      });
  }

  convertImage(dataURI, dataTYPE): any {
    var binary = atob(dataURI.split(',')[1]), array = [];
    for (var i = 0; i < binary.length; i++) array.push(binary.charCodeAt(i));
    return new Blob([new Uint8Array(array)], { type: dataTYPE });
  }

  public get triggerObservable(): Observable<void> {
    this.spinnerService.hide();
    return this.trigger.asObservable();
  }

  webcam() {
    this.showWebcam = true;
    this.spinnerService.show();
  }

  cancelWebcam() {
    this.showWebcam = false;
  }

  changeUserProfilePic(image) {
    this.userDetail.userImages.forEach(element => {
      if (element.imageId == image.imageId) {
        element.selectedAsDP = true;
      } else {
        element.selectedAsDP = false;
      }
    });
    this.userDetail.newImages = this.newImages;
    this.spinnerService.show();
    this.saveOrUpdateUserInformation();
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
