import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../../services/data/data-service.service';
import { Router } from '@angular/router';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import { ToasterService } from 'angular2-toaster';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';


@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

  user: any = {};
  private onlineStatusId: any = 1;

  constructor(private dataService: DataServiceService, private router: Router,
    public toasterService: ToasterService, private spinnerService: Ng4LoadingSpinnerService) { }

  ngOnInit() {
  }

  signup() {
    this.router.navigate(['/signup']);
  }

  login(user) {
    this.dataService.doLogin(user.username, user.password).subscribe((authRes) => {
      localStorage.setItem("access_token", authRes.access_token);
      localStorage.setItem("loginUserDetail", JSON.stringify(authRes));
      localStorage.setItem("token", JSON.stringify(authRes));
      localStorage.setItem("loggedInUsername", user.username);
      console.log("AuthRes => ", authRes);
      this.dataService.setLoggedInUser(JSON.stringify(authRes));
      this.dataService.updateUserStatus(authRes.uid, this.onlineStatusId)
        .subscribe(res => {
          if (authRes.authorities === "ADMIN") {
            this.router.navigate(['/admin']);
          } else if (authRes.authorities === "MANAGER") {
            this.router.navigate(['/manager']);
          } else {
            this.router.navigate(['/home']);
          }
        }, err => {
          console.log("OnlinestatusErr=>", err);
        });

    }, (err) => {
      console.log("LoginError=>", err);
      this.toasterService.pop("warning", "Username or password is incorrect.");
      this.user = {};
    });
  }

  validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }

  forgotPassword(email) {
    if (email.length < 1) {
      this.toasterService.pop('warning', "Please enter your email.");
    } else {
      if (this.validateEmail(email)) {
        this.spinnerService.show();
        this.dataService.forgotPassword(email)
          .subscribe(res => {
            this.spinnerService.hide();
            this.toasterService.pop('success', "Please check your email.");
          }, err => {
            console.log("EmailError=>", err);
            this.spinnerService.hide();
            this.toasterService.pop('warning', "User not found !");
          });
      } else {
        this.toasterService.pop('warning', "Please enter a valid email id.");
      }

    }
  }
}

