import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataServiceService } from "../../services/data/data-service.service";
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { UUID } from 'angular2-uuid';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ToasterService } from 'angular2-toaster';


@Component({
  selector: 'forgot-password',
  templateUrl: './forgot-password.html',
  styleUrls: ['./forgot-password.css']
})
export class ForgotPasswordComponent implements OnInit {

  loggedInUserId: number;
  private passwordResetToken : any;
  public userDetail: any;
  private sub: any;

  public user = { newPassword: undefined, confirmNewPassword: undefined };

  // latest snapshot
  public webcamImage: any = null;

  constructor(private router: Router, private route: ActivatedRoute, private dataService: DataServiceService,
    private UUID: UUID, private spinnerService: Ng4LoadingSpinnerService, public toasterService: ToasterService) { }

  ngOnInit() {

  }

  ngAfterViewInit() {
    this.sub = this.route.params.subscribe(params => {
      this.loggedInUserId = +params['userId'];
      this.passwordResetToken = params['resetToken'];
      console.log(this.loggedInUserId, this.passwordResetToken);
    });
  }

  onSubmit() {
    if (!this.user.newPassword && !this.user.confirmNewPassword) {
      this.presentToast("danger", "Please provide the password");
    }
    else if (this.user.newPassword != this.user.confirmNewPassword) {
      this.presentToast("danger", "Passwords do not match. Please try again.");
    } else {
      this.spinnerService.show();
      this.resetPassword(this.user.newPassword, this.loggedInUserId);

    }
  }

  resetPassword(password, userId) {
    this.dataService.setNewPassword(password, userId,this.passwordResetToken)
      .subscribe(res => {
        this.spinnerService.hide();
        this.presentToast("success", res);
        this.router.navigate(['/login']);
      }, err => {
        console.log(err);
        this.spinnerService.hide();
        this.presentToast("danger", err.error);
        this.router.navigate(['/login']);
      });
  }

  presentToast(cssClass, message) {
    this.toasterService.pop(cssClass, message);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
