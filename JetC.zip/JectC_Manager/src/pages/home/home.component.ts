import { Component, OnInit, ElementRef, ViewChild, Renderer2 } from "@angular/core";
import SimpleWebRTC from "simplewebrtc";
import { Router, ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs/Subscription";
import { Observable } from "rxjs";
import { Ng2FileDropAcceptedFile, Ng2FileDropRejectedFile } from 'ng2-file-drop';
import { UUID } from 'angular2-uuid';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import 'rxjs/add/operator/map';
import { Message } from '@stomp/stompjs';
import { StompConfig, StompService } from '@stomp/ng2-stompjs';
import { ToasterService } from 'angular2-toaster';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { MyProfileComponent } from '../my-profile/my-profile.component';

import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
import { DataServiceService } from "../../services/data/data-service.service";
import { VideoService } from "../../services/video/video.service";
import { AudioService } from "../../services/audio/audio.service";
import { ScreenService } from "../../services/screen/screen.service";

interface Online {
  users: any;
}
interface FileShare {
  msg: any;
  meetingId: any;
  from: any;
}

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
  animations: [
    trigger('heroState', [
      // state('inactive', style({
      //   backgroundColor: '#eee',
      //   transform: 'scale(1)'
      // })),
      // state('active',   style({
      //   backgroundColor: '#cfd8dc',
      //   transform: 'scale(1.1)'
      // })),
      transition('inactive => active', animate('100ms ease-in')),
      transition('active => inactive', animate('100ms ease-out'))
    ])
  ]
})
export class HomeComponent implements OnInit {


  groupStatusIcon = 'assets/images/grp2.png';
  searchName = null;
  loggedInUser: any;
  remoteUser: any;
  users: any;
  allUsers: any;
  groups: any;
  partnerId: any;
  internal: any;
  public showWelcomeMessage: boolean = true;
  public openChatWindow: boolean = false;
  private openTextChat: boolean = false;
  private openVideoChat: boolean = false;
  private openAudioChat: boolean = false;
  private openScreenShare: boolean = false;
  private isAnswering: boolean = false;

  private userDetail: any;
  private textMessage: any;
  private preferredLanguage: any = "English";
  private languages: any;
  private langCode: any;
  private meetingId: any;
  private ongoingVedioPartenerId: any;
  private ongoingVedioPartenerName: any;
  private session: any;
  private droppedFile: any;
  private myMessages: any;
  private audio: any;
  private callingTime: any = 30000;
  private clearCallingtime: any;

  //Modifications--prem
  private groupChatMessages: any;
  private isMultiLanguageSupported: boolean;
  private partnerInfo: any;
  private userStatus: any;
  private userStatusIcon: any;
  private credentialStatus: any;
  private currentStatusIcon: any;
  private refreshStatusInterval: any;
  private groupName: any;
  private groupStatesubscription: any;
  private showGroupChat: boolean = false;
  private displayedName: any;
  public searchedUsers: any = [];
  public showSearchedUsers: boolean = false;
  public searchedUserInfo: any;
  public friendList = [];
  public friends: any;
  private offlineStatusId: any = 5;
  private onlineStatusId: any = 1;
  private showSearchButton: boolean = false;
  public staticUserProfilePic: any;

  //Prashant
  userId: number;
  private sub: any;
  usersInSession: any;
  groupDetail: any;
  private isPeerCaller = true;
  userSearch = '';
  selectedUsersList: any;
  flag: boolean = false;
  isValid: boolean = false;
  checkBoxFlag;

  template: string = `<img src="assets/images/loading.gif"/>`

  //drshn
  currentUserForRightSideText: any;

  //webRTC Variables
  private FileWebRTC: any

  isCallInProgress: boolean = false;
  private serverUrl = "https://192.168.2.10:10391/Web_RTC/socket";
  public cloudImageUrl = "https://storage.googleapis.com/jetc-webrtc/";

  private stompClient;
  private socket;
  constructor(private dataService: DataServiceService,
    private router: Router, private videoService: VideoService,
    private audioService: AudioService,
    private screenService: ScreenService,
    private activatedRoute: ActivatedRoute, private renderer: Renderer2,
    public toasterService: ToasterService, private spinnerService: Ng4LoadingSpinnerService,
    private el: ElementRef) {
    this.internal = 2000;
    this.subscribe();
  }


  /**
   * This method is subscribed to the '/chat' message broker to get realtime updates.
   */
  initializeWebSocketConnection() {
    let stomp_subscription = this.dataService.getStompService().subscribe('/chat');
    stomp_subscription.map((message: Message) => {
      return message.body;
    }).subscribe((msg_body: string) => {
      if (msg_body && msg_body == "friendRequestRequested" || msg_body.includes("friendRequestAccepted")
        || msg_body.includes("friendRequestCancelled") || msg_body.includes("friendRemoved")) {
        this.refreshFriendList();
        if (msg_body.includes("friendRequestAccepted")) {
          let friend = msg_body.split("$");
          console.log("Friend Added=>", friend[1]);
        }
        return;
      }
      let data = JSON.parse(msg_body);

      if (data && data['type'] == "unreadMessageForPeer") {
        console.log("unreadMessageForPeer", data);
        if (this.dataService.getLoggedInUser()['uid'] == +data['userId']) {
          if (this.friends && this.friends.length > 0) {
            for (let i = 0; i < this.friends.length; i++) {
              if (this.friends[i].userId == +data['partnerId']) {
                this.friends[i]['unreadMessage'] = +data['unreadMessage'];
              }
            }
          }
        }
      } else if (data && data['type'] == "unreadMessageForGroup") {
        if (data['gId']) {
          for (let i = 0; i < this.groups.length; i++) {
            if (this.groups[i].id == +data['gId']) {
              if (this.dataService.getLoggedInUser()['uid'] == +data['userId']) {
                this.groups[i]['unreadMessage'] = +data['unreadMessage'];
                console.log("data ***** ", data);
                break;
              }
            }
          }
        }

      } else if (data && data.groupAdmin) {
        this.groupDetail = data;
        for (let i = 0; i < this.groups.length; i++) {
          if (this.groupDetail.id === this.groups[i].id) {
            this.groups[i].status = this.groupDetail.status;
            this.groups[i].type = this.groupDetail.type;
          }
        }
      } else if (data && data.userStatus && data.userStatus.userStatusIcon) {
        //This part is used to update the user details whenever any change is detected.
        if (this.loggedInUser && this.loggedInUser.uid == data.userId) {
          this.userStatusIcon = data.userStatus.userStatusIcon;
          this.userStatus = data.userStatus.userStatus;
        }
        if (this.friends) {
          this.friends.forEach(element => {
            if (element.userId === data.userId) {
              element.userStatus = data.userStatus;
              if (this.userDetail) {
                this.userDetail.userStatusIcon = element.userStatus.userStatusIcon;
              }
            }
          });
        }
      } else if (data && data.FileReceived) {
        let filesRecieved = data.FileReceived;
        filesRecieved.forEach(element => {
          console.log("fileReceived...", element);
          this.dataService.receiveFileSharing(element);
          this.watchPeerChat();
          this.watchGroupChat();
        });
      } else if (data && data.body && data.body.type === "group") {
        this.watchGroupChat();
        this.getGroups();
        this.scrollTo(null);
      } else if (data && data.body && data.body.type == "ScreenAdded" && data.body.payload.type == "SharingStarted") {
        this.spinnerService.hide();
        this.watchGroupChat();
      }
    });
  }

  searchUser() {
    this.showSearchButton = false;
    let pageNo = 1;
    let pageSize = 10;
    if (this.searchName) {
      this.dataService.searchUsers(this.searchName, this.loggedInUser.uid, pageNo, pageSize)
        .subscribe(res => {
          console.log("searched==>", res);
          if (res == null) {
            this.toasterService.pop("success", "No matching results found.");
            return;
          }
          this.searchedUsers = res;
          if (this.searchedUsers && this.searchedUsers.indexOf(this.loggedInUser.uid) >= 0) {
            this.searchedUsers.splice(this.searchedUsers.indexOf(this.loggedInUser.uid), 1);
          }
          this.showWelcomeMessage = true;
          this.openChatWindow = false;
          this.openTextChat = false;
          this.openVideoChat = false;
          this.openAudioChat = false;
          this.openScreenShare = false;
        }, err => {
          console.log(err);
        });
    }
  }

  onScroll() {
    console.log("scrolled!!");
  }

  getSearchedUserDetail(user) {
    this.searchedUserInfo = user;
    this.showSearchedUsers = true;
    this.showWelcomeMessage = false;
    this.openChatWindow = false;
    this.openTextChat = false;
    this.openVideoChat = false;
    this.openAudioChat = false;
    this.openScreenShare = false;
  }

  addFriends() {
    let friendPresent: boolean = false;
    this.refreshFriendList();
    if (this.friendList.length == 0 || this.friends.length == 0) {
      this.friendList.push({ "userId": this.searchedUserInfo.userId });
    } else {
      this.friendList.forEach(element => {
        if (element.userId === this.searchedUserInfo.userId) {
          this.toasterService.pop("warning", "Already added.");
          friendPresent = true;
          return;
        }
      });
      this.friendList.push({ "userId": this.searchedUserInfo.userId });
    }
    if (!friendPresent) {
      this.dataService.addNewFriends(this.friendList, this.loggedInUser.uid)
        .subscribe(res => {
          this.toasterService.pop('success', 'Request sent !');
          this.showSearchedUsers = false;
          this.showWelcomeMessage = true;
        }, err => {
          if (err.status == 200) {
            this.toasterService.pop('success', 'Request sent !');
            this.showSearchedUsers = false;
            this.showWelcomeMessage = true;
            this.friendList = [];
          } else {
            this.toasterService.pop('warning', 'Something went wrong.');
            this.showSearchedUsers = false;
            this.showWelcomeMessage = true;
          }
        });
    }
  }

  acceptFriendRequest(user) {
    this.dataService.acceptFriendRequest(this.loggedInUser.uid, user.userId).subscribe(res => {
      this.toasterService.pop("success", "Friend request accepted.");
      this.refreshFriendList();
    }, err => {
      this.toasterService.pop("warning", "Something went wrong.");
      console.log("Acceptance Error=>", err);

    });
  }

  rejectFriendRequest(user) {
    if (this.friends.indexOf(user) >= 0) {
      this.friends.splice(this.friends.indexOf(user), 1);
    }
    this.dataService.cancelFriendRequest(this.loggedInUser.uid, user.userId)
      .subscribe(res => {
        console.log("Reject Res=>", res);
        this.toasterService.pop("warning", "Friend request cancelled.");
        this.refreshFriendList();
      }, err => {
        console.log("Reject Err=>", err);
        this.toasterService.pop("warning", "Something went wrong.");
        this.refreshFriendList();
      });
  }

  unfriend(user) {
    console.log("Unfriend==> ", user.userId, "myId-> ", this.loggedInUser.uid);
    this.dataService.doUnfriend(this.loggedInUser.uid, user.userId)
      .subscribe(res => {
        this.toasterService.pop("success", "Friend removed.");
        this.refreshFriendList();
        this.showSearchedUsers = false;
        this.showWelcomeMessage = true;
        this.openChatWindow = false;
        this.openTextChat = false;
        this.openVideoChat = false;
        this.openAudioChat = false;
        this.openScreenShare = false;
      }, err => {
        this.toasterService.pop("warning", "Something went wrong.");
        console.log("Unfriend Error=>", err);
        this.showSearchedUsers = false;
        this.showWelcomeMessage = true;
        this.openChatWindow = false;
        this.openTextChat = false;
        this.openVideoChat = false;
        this.openAudioChat = false;
        this.openScreenShare = false;
      });
  }

  moveToProfilePage() {
    this.router.navigate(['/profile', { id: this.loggedInUser.uid }]);
  }

  /**************** Gaurav *******************/
  getUserStatus() {
    this.dataService.getUserStatus().subscribe(
      (res) => {
        this.credentialStatus = res;
      }, (err) => {
        //console.log("USER_STATUS_ERROR", err);
      }
    );
  }

  showLoadingSpinner() {
    this.spinnerService.show();
  }

  iconChange(num: any, statusIcon: any) {

    if (num == 0) {
      this.currentStatusIcon = statusIcon;
      this.userStatusIcon = "assets/images/dropDown.png";
    }
    if (num == 1) {
      this.userStatusIcon = this.currentStatusIcon;
      this.currentStatusIcon = "";
    }

  }//iconChange(-,-)

  changeStatus(status: any) {
    this.userStatusIcon = status.userStatusIcon;
    this.userStatus = status.userStatus;
    //Set Do Not Disturb
    this.dataService.updateUserStatus(this.loggedInUser.uid, status.userStatusId).subscribe(
      (res) => {
        //console.log(res);
      }, (err) => {
        //console.log(err);
      }
    );

  }//changeStatus(-)

  linecolor: boolean = true;

  searchElement(newValue: any) {
    console.log("Typing...", newValue);
    this.showSearchButton = true;
    if (newValue.length < 1) {
      this.linecolor = true;
      this.searchedUsers = [];
    }
    else {
      this.linecolor = false;
    }
    this.searchName = newValue;
  }//valueChange(-)

  /**************** Gaurav *******************/


  //Prashant
  //// by Prashant
  getAllUsers() {
    this.dataService.getGroupUsers().subscribe(
      (res) => {
        this.allUsers = res;
      }, (err) => {
        console.log("getting error ", err);
      }

    );
  }
  groupValuechange(newValue) {
    this.userSearch = newValue;
  }

  addUserToCreateGroup(obj, event) {
    //console.log("checkbox", event.target.checked);
    this.checkBoxFlag = event.target.checked;
    if (this.checkBoxFlag) {
      // to make button enable and disable
      this.isValidForm();

      if (this.selectedUsersList && this.selectedUsersList.users && (this.selectedUsersList.users.length == 0)) {
        this.selectedUsersList.users.push({ "userId": obj.userId });
      } else {
        this.flag = false;
        for (var i = 0; i < this.selectedUsersList.users.length; i++) {
          if (obj.userId == this.selectedUsersList.users[i].userId) {
            this.flag = true;
            break;
          }
        }
        if (this.flag == false) {
          this.selectedUsersList.users.push({ "userId": obj.userId });
          this.flag = false;
        }
      }
      //console.log(this.selectedUsersList);
    } else {
      // logic to splice on check box unselected
      //console.log("splice");
      for (var i = 0; i < this.selectedUsersList.users.length; i++) {
        if (obj.userId == this.selectedUsersList.users[i].userId) {
          this.selectedUsersList.users.splice(i, 1);
        }
      }
      //console.log(this.selectedUsersList);
    }
  }
  // to enable and disable create button
  isValidForm() {
    if (this.selectedUsersList.users.length == 0 || this.selectedUsersList.users == 'undefined') {
      if (!this.groupName && this.groupName == 'undefined' || this.groupName == '') {
        this.isValid = false;
      }
    } else {
      this.isValid = true;
    }
    return this.isValid;
  }

  // create group() 
  createGroup(groupName) {
    if (groupName) {
      console.log("ValidateGrpName==>", this.validateGroupName(groupName));
      if (this.validateGroupName(groupName)) {
        this.selectedUsersList.name = groupName;
        console.log("listtt=>", this.selectedUsersList);
        this.dataService.createGroupService(this.selectedUsersList).subscribe((res) => {
          console.log("GrpRes=>", res);
          this.toasterService.pop('success', 'Group Created!');
          this.getGroups();
          let payload = {};
          this.dataService.sendInfo("group", payload);
        }, (err) => {
          this.selectedUsersList = { "id": this.loggedInUser.uid, "name": groupName, users: [] };
          console.log("something went wrong ", err);
          this.toasterService.pop('warning', 'Something went wrong.Try after sometime');
        });
      } else {
        this.toasterService.pop('danger', 'Specify a valid group name!');
      }
    } else {
      this.toasterService.pop('danger', 'Specify group name!');

    }
  }

  validateGroupName(groupName) {
    var re = /^[a-zA-Z]+$/;
    return re.test(String(groupName));
  }

  addGroupMember() {
    this.spinnerService.show();
    if (this.showGroupChat && this.userDetail) {
      this.dataService.addMemberToGroup(this.userDetail.userId, this.selectedUsersList.users)
        .subscribe(res => {
          this.spinnerService.hide();
          this.toasterService.pop('success', 'Members Added !');
          this.dataService.sendInfo("group", this.userDetail);
        }, err => {
          console.log(err);
          this.spinnerService.hide();
          this.toasterService.pop('warning', 'Something went wrong.Try after sometime');
        });
    }
  }

  private timer1Subscribe: any;
  private timer2Subscribe: any;
  public userProfilePic: any;

  ngOnInit() {

    if (this.dataService.getLoggedInUser()) {
      this.dataService.getUserById(this.dataService.getLoggedInUser().uid)
        .subscribe(res => {
          let userInfo = res;
          this.userStatusIcon = userInfo["userStatus"]["userStatusIcon"];
          this.userStatus = userInfo["userStatus"]["userStatus"];
          this.loggedInUser.username = userInfo["firstName"] + " " + userInfo["lastName"];
          if (userInfo['userImages']) {
            userInfo['userImages'].forEach(element => {
              if (element.selectedAsDP) {
                this.userProfilePic = this.cloudImageUrl + element.imageName;
              }
            });

          } if (!this.userProfilePic) {
            this.userProfilePic = this.dataService.staticUserProfilePic;
          }
        }, err => {
          console.log("Error=>", err);
        });
    } else {
      this.router.navigate['/login'];
      window.location.reload();
    }
    this.staticUserProfilePic = this.dataService.staticUserProfilePic;
    this.refreshStatusInterval = this.dataService.getRefreshStatusInterval();
    let peerConnectionConfig;
    this.isMultiLanguageSupported = this.dataService.isMultiLanguageSupported();
    if (!localStorage.getItem('token')) {
      this.logout();
    }
    try {
      this.loggedInUser = JSON.parse(localStorage.getItem('token'));
      if (!this.loggedInUser) {
        this.logout();
      }
      // peerConnectionConfig = JSON.parse(localStorage.getItem("peerConnectionConfig"));

    } catch (err) {
      this.logout();
      // return;
    }

    // this.dataService.afterLogin(this.loggedInUser,peerConnectionConfig);
    this.videoService.setCurrentUser(this.loggedInUser);
    this.dataService.afterLogin(this.loggedInUser, "");
    this.getUserStatus();
    //this.refreshUserStatus();
    this.refreshFriendList();
    this.currentUserForRightSideText = this.dataService.getLoggedInUser().uid;
    // this.timer1Subscribe = Observable.timer(0, this.refreshStatusInterval).subscribe(t => {
    //   this.users = this.dataService.getUsers();
    //   this.getGroups();
    // });
    this.getAllUsers();
    this.loggedInUser = this.dataService.getLoggedInUser();
    this.getGroups();
    // this.userStatusIcon = this.credentialStatus[0].src;
    // this.userStatus = this.credentialStatus[0].name;
    this.languages = this.getSupportedLanguages();

    this.selectedUsersList = {
      "id": this.loggedInUser.uid,
      "name": undefined,
      "status": "Deactive",
      "type": "Undefined",
      "users": []
    };
  }

  refreshFriendList() {
    //--fetch updated frnds lst--start//
    this.dataService.getFriendList(this.loggedInUser.uid).subscribe(res => {
      this.friends = res;
      console.log("Friends ==> ", this.friends);
      this.dataService.setFriends(res);
    }, err => {
      console.log("Frnds==>", err);
    });
    //--fetch updated frnds lst--end//
  }

  translateMessage(myMessages) {
    if (this.langCode) {
      let transaltedMessages = [];
      for (let i = 0; i < myMessages.length; i++) {
        this.dataService.translateMessageText(myMessages[i].message.message, this.langCode).subscribe(
          (res) => {
            //console.log("Translated -> ", res);
          },
          (err) => {
            //console.log(err);
          }
        );
      }
      //console.log("Translated Texts -->", transaltedMessages);
    }
  }

  getGroups() {
    this.dataService.getUserGroups(this.loggedInUser.uid).subscribe(res => {
      this.groups = res;
      if (this.groups) {
        for (let i = 0; i < this.groups.length; i++) {
          for (let j = 0; j < this.groups[i].users.length; j++) {
            if (this.dataService.getLoggedInUser()['uid'] == this.groups[i].users[j].userId) {
              this.groups[i]['unreadMessage'] = this.groups[i].users[j].unreadMessage;
              break;
            }
          }
        }
      }
      this.dataService.setGroups(this.groups);
    }), err => { console.log(err); };
  }

  openUserChatWindow(user) {
    if (user.userId) {
      this.displayedName = user.userId;
      this.showSearchedUsers = false;
      this.showWelcomeMessage = false;
      this.showGroupChat = false;
      this.isPeerCaller = true;
      this.partnerId = user.userId;
      this.dataService.setCurrentPartnerId(user.userId);
      this.dataService.setCurrentGroupId("NOT-SET");
      this.videoService.setCurrentPartnerId(user.userId);
      this.videoService.setCurrentGroupId("NOT-SET");
      this.userDetail = {};
      this.userDetail = this.dataService.getFriendById(user.userId);
      this.userDetail.userStatusIcon = user.userStatus.userStatusIcon;
      if (this.userDetail.userImages) {
        this.userDetail.userImages.forEach(element => {
          if (element.selectedAsDP) {
            this.userDetail.userProfilePic = this.cloudImageUrl + element.imageName;
          }
        });
      }
      if (!this.userDetail.userProfilePic) {
        this.userDetail.userProfilePic = this.dataService.staticUserProfilePic;
      }
      this.makeTextChat();
      if (!this.checkVideoStatus) {
        this.ongoingVedioPartenerId = this.dataService.getOngoingVedioPartenerId();
        this.ongoingVedioPartenerName = this.dataService.getUser(this.ongoingVedioPartenerId).username;
      }
      this.watchPeerChat();
      document.getElementById('mySidenav').style.width = '0';
      this.getWindowInfo();
      this.getOldMesseges(this.partnerId, this.isPeerCaller, 1, 10);
    }

    this.dataService.clearUnreadMesseges(this.dataService.getLoggedInUser()['uid'], user.userId, true)
      .subscribe((res) => {
        if (this.friends && this.friends.length > 0) {
          for (let index = 0; index < this.friends.length; index++) {
            if (this.friends[index].userId == user.userId) {
              this.friends[index]['unreadMessage'] = 0;
            }
          }
        }
      }, (err) => {
        console.log("Something is wrong in unread message :: ", err);
      });
  }


  /* VK Kushwah Start */

  private muteStatus: any = false;

  muteAll() {
    if (this.muteStatus) {
      this.muteStatus = false;
    } else {
      this.muteStatus = true;
    }
    this.videoService.muteAll(this.muteStatus);
  }

  openGroupChatWindow(group) {
    this.showWelcomeMessage = false;
    this.showSearchedUsers = false;
    this.showGroupChat = true;
    this.displayedName = group.name;
    if (group.groupAdmin) {
      if (group.groupAdmin == this.dataService.getLoggedInUser().uid)
        this.dataService.setGroupAdminStatus(true);
      else
        this.dataService.setGroupAdminStatus(false);
    } else {
      this.dataService.setGroupAdminStatus(false);
    }
    this.switchWindow("text", true);
    this.isPeerCaller = false;
    this.groupDetail = group;
    console.log("grpDetail==>", this.groupDetail);
    this.dataService.setCurrentGroupId(group.id);
    this.videoService.setCurrentGroupId(group.id);
    this.watchGroupChat();
    this.userDetail = {};
    this.userDetail = {
      username: group.name, userId: group.id,
      userProfilePic: this.dataService.staticGroupIcon
    };
    document.getElementById('mySidenav').style.width = '0';
    //this.dataService.setCurrentGroup(group);
    //this.keepGroupAlive();
    this.getWindowInfo();
    this.getOldMesseges(group.id, this.isPeerCaller, 1, 10);

    this.dataService.clearUnreadMesseges(this.dataService.getLoggedInUser()['uid'], group.id, false)
      .subscribe((res) => {
        if (this.groups && this.groups.length > 0) {
          for (let index = 0; index < this.groups.length; index++) {
            if (this.groups[index].id == group.id) {
              this.groups[index]['unreadMessage'] = 0;

            }
          }
        }
      }, (err) => {
        console.log("Something is wrong in unread message :: ", err);
      });
  }

  keepGroupAlive() {
    let timer = Observable.timer(0, this.refreshStatusInterval);
    this.groupStatesubscription = timer.subscribe((data) => {
      //service to activate group chat
      if (this.groupDetail && this.groupDetail.type) {
        this.dataService.activateGroupChat(this.groupDetail.id, this.groupDetail.type, this.groupDetail.status).subscribe(
          (res) => {
            //console.log("Backend Updated", res);
          }, (err) => {
            //console.log("GroupAlive Err=>", err);
          }
        );
      }
    });
  }

  watchGroupChat() {
    let groupMessages = this.dataService.getSGroupTextChats(this.dataService.getCurrGroupID());
    if (groupMessages && groupMessages.messages && groupMessages.messages.length > 0) {
      this.groupChatMessages = groupMessages.messages;

      if (this.groupOldMessages && this.groupOldMessages.length > 0) {
        let status = false;
        for (let i = this.groupOldMessages.length - 1; i >= 0; i--) {
          if (this.groupOldMessages[i].date) {
            if (this.groupOldMessages[i].date == "Today") {
              status = true;
            }
            break;
          }
        }
        if (!status) {
          this.groupChatMessages[0]["date"] = "Today";
        }
      } else {
        this.groupChatMessages[0]["date"] = "Today";
      }

    } else if (this.groupChatMessages && this.groupChatMessages['length'] != 'undefined') {
      this.groupChatMessages = [];
    }
  }

  /***** Text Chatting Start *****/
  makeTextChat() {
    this.dataService.startTextChat(this.partnerId);
    this.switchWindow("text", true);
  }

  subscribe() {
    this.dataService.fileSharing.subscribe({
      next: (event: FileShare) => {

        //console.log(`Home Chat Component File Share Listening-> #${event.msg} , #${event.meetingId}`);
        if (event.msg == "websocketconnection") {
          this.initializeWebSocketConnection();
          // this.specificUserWebsocket();
        }

        if (event.msg == "StopAudio") {
          if (event.meetingId) {
            this.stopAudioChat();
            this.managePlaceddCalls(event);
          } else {
            clearTimeout(this.clearCallingtime);
            this.callerModel(null, false, null);
          }
          // if (!event.from) {
          //   if (this.groupStatesubscription) {
          //     console.log("Unsubscribing frm grp audio");
          //     this.groupStatesubscription.unsubscribe();
          //   }
          // }
        } else if (event.msg === "StopVideo") {
          if (event.meetingId) {
            this.stopVideoChat();
            this.managePlaceddCalls(event);
          } else {
            clearTimeout(this.clearCallingtime);
            this.callerModel(null, false, null);
          }
          // if (!event.from) {
          //   if (this.groupStatesubscription) {
          //     console.log("Unsubscribing frm grp video");
          //     this.groupStatesubscription.unsubscribe();
          //   }
          // }
        } else if (event.msg === "StopScreen") {
          if (event.meetingId) {
            this.stopScreenSharing();
            this.managePlaceddCalls(event);
          } else {
            clearTimeout(this.clearCallingtime);
            this.callerModel(null, false, null);
          }
          // if (!event.from) {
          //   if (this.groupStatesubscription) {
          //     console.log("Unsubscribing frm grp screen");
          //     this.groupStatesubscription.unsubscribe();
          //   }
          // }
        } else if (event.msg === "AnswerGroupScreen" && event.from != this.dataService.getLoggedInUser().uid) {
          this.answerBox("Answer To Allow Group Screen Share !!", "Screen", "Audio").then((answer) => {
            if (answer["status1"] == false && answer["status2"] == false) {
              this.manageMissedCalls(event, "screen missed", false, true);
            } else if (answer["status1"] == false && answer["status2"] == true) {
              this.manageMissedCalls(event, "screen missed", false, false);
            }

            if (answer["status1"]) {
              this.screenService.setAnsweringCall(true);
              this.switchWindow("screen", true);
              this.isPeerCaller = false;
              this.dataService.setconnectionInProgress("ScreenGroup");
              this.groupDetail = this.dataService.getGroup(this.dataService.getCurrGroupID());
              if (this.groupDetail.groupAdmin) {
                if (this.groupDetail.groupAdmin == this.dataService.getLoggedInUser().uid)
                  this.dataService.setGroupAdminStatus(true);
                else
                  this.dataService.setGroupAdminStatus(false);
              } else {
                this.dataService.setGroupAdminStatus(false);
              }
              this.userDetail = { "username": this.groupDetail.name };
              this.screenService.startScreenSharing(event.meetingId, this.isPeerCaller, answer["status2"]);
              this.dataService.sendStopEvents("StopScreen", { "status": false, "gid": this.dataService.getCurrGroupID(), "uid": event.from })
            } else {
              this.dataService.sendStopEvents("StopScreen", { "status": true, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
            }
          }, (err) => {
            this.dataService.sendStopEvents("StopScreen", { "status": true, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
          });
        } else if (event.msg === "ShareScreen") {
          this.answerBox("Answer To Allow Screen Share !!", "Screen", "Audio").then((answer) => {
            if (answer["status1"] == false && answer["status2"] == false) {
              this.manageMissedCalls(event, "screen missed", true, true);
            } else if (answer["status1"] == false && answer["status2"] == true) {
              this.manageMissedCalls(event, "screen missed", true, false);
            }

            if (answer["status1"]) {
              this.screenService.setAnsweringCall(true);
              this.isAnswering = true;
              this.switchWindow("screen", true);
              this.partnerId = event.from;
              this.dataService.setCurrentPartnerId(this.partnerId);
              this.userDetail = this.dataService.getFriendById(this.partnerId);
              if (event.meetingId) {
                this.dataService.setconnectionInProgress("Screen");
                this.screenService.startScreenSharing(event.meetingId, this.isPeerCaller, answer["status2"]);
              }
              this.dataService.sendStopEvents("StopScreen", { "status": false, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
            } else {
              this.dataService.sendStopEvents("StopScreen", { "status": true, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
            }
          }, (err) => {
            this.dataService.sendStopEvents("StopScreen", { "status": true, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
          });
        } else if (event.msg === "AnswerGroupAudio" && event.from != this.dataService.getLoggedInUser().uid) {
          //console.log("received AnswerGroupAudio ..");
          this.answerBox("Answer Group Audio Call !!", "Audio", null).then((answer) => {
            if (answer["status1"] == false && answer["status2"] == false) {
              this.manageMissedCalls(event, "audio missed", false, true);
            } else if (answer["status1"] == false && answer["status2"] == true) {
              this.manageMissedCalls(event, "audio missed", false, false);
            }
            if (answer["status1"]) {
              this.dataService.setAnsweringCall(true);
              this.switchWindow("audio", true);
              this.isPeerCaller = false;
              this.dataService.setconnectionInProgress("AudioGroup");
              this.groupDetail = this.dataService.getGroup(this.dataService.getCurrGroupID());
              //vk
              if (this.groupDetail.groupAdmin) {
                if (this.groupDetail.groupAdmin == this.dataService.getLoggedInUser().uid)
                  this.dataService.setGroupAdminStatus(true);
                else
                  this.dataService.setGroupAdminStatus(false);
              } else {
                this.dataService.setGroupAdminStatus(false);
              }

              this.userDetail = { "username": this.groupDetail.name };
              this.audioService.startAudioChatting(event.from, event.meetingId, this.isPeerCaller);
              this.dataService.sendStopEvents("StopAudio", { "status": false, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
            } else {
              this.dataService.sendStopEvents("StopAudio", { "status": true, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
            }
          }, (err) => {
            this.dataService.sendStopEvents("StopAudio", { "status": true, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
          });
        } else if (event.msg === "AnswerAudio") {
          console.log("Answering the audio call ...");
          this.answerBox("Answer Audio Call !!", "Audio", null).then((answer) => {

            if (answer["status1"] == false && answer["status2"] == false) {
              this.manageMissedCalls(event, "audio missed", true, true);
            } else if (answer["status1"] == false && answer["status2"] == true) {
              this.manageMissedCalls(event, "audio missed", true, false);
            }

            if (answer["status1"]) {
              this.dataService.setAnsweringCall(true);
              this.switchWindow("audio", true);
              this.partnerId = event.from;
              this.dataService.setCurrentPartnerId(this.partnerId);
              this.userDetail = this.dataService.getFriendById(this.partnerId);
              if (event.meetingId) {
                this.dataService.setconnectionInProgress("Audio");
                this.audioService.startAudioChatting(this.partnerId, event.meetingId, true);
              }
              console.log("Answering the audio call ...status: false");
              this.dataService.sendStopEvents("StopAudio", { "status": false, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
            } else {
              console.log("Answering the audio call ...status: true");
              this.dataService.sendStopEvents("StopAudio", { "status": true, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
            }
          }, (err) => {
            console.log("Answering the audio call ...status: true << GOT ERROR >>");
            this.dataService.sendStopEvents("StopAudio", { "status": true, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
          });
        } else if (event.msg === "AnswerGroupVideo" && event.from != this.dataService.getLoggedInUser().uid) {
          this.answerBox("Answer Group Video Call !!", "Video", "Audio").then((answer) => {
            if (answer["status1"] == false && answer["status2"] == false) {
              this.manageMissedCalls(event, "video missed", false, true);
            } else if (answer["status1"] == false && answer["status2"] == true) {
              this.manageMissedCalls(event, "video missed", false, false);
            }

            if (answer["status1"]) {
              this.dataService.setAnsweringCall(true);
              this.switchWindow("video", true);
              this.isPeerCaller = false;
              this.dataService.setconnectionInProgress("VideoGroup");
              this.groupDetail = this.dataService.getGroup(this.dataService.getCurrGroupID());
              if (this.groupDetail.groupAdmin) {
                if (this.groupDetail.groupAdmin == this.dataService.getLoggedInUser().uid)
                  this.dataService.setGroupAdminStatus(true);
                else
                  this.dataService.setGroupAdminStatus(false);
              } else {
                this.dataService.setGroupAdminStatus(false);
              }
              this.userDetail = { "username": this.groupDetail.name };
              this.videoService.startVideoChatting(event.from, event.meetingId, this.isPeerCaller, answer["status2"]);
              this.dataService.sendStopEvents("StopVideo", { "status": false, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
            } else {
              this.dataService.sendStopEvents("StopVideo", { "status": true, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
            }
          }, (err) => {
            this.dataService.sendStopEvents("StopVideo", { "status": true, "gid": this.dataService.getCurrGroupID(), "uid": event.from });
          });

        } else if (event.msg === "AnswerVideo") {
          this.answerBox("Answer Video Call !!", "Video", "Audio").then((answer) => {
            if (answer["status1"] == false && answer["status2"] == false) {
              this.manageMissedCalls(event, "video missed", true, true);
            } else if (answer["status1"] == false && answer["status2"] == true) {
              this.manageMissedCalls(event, "video missed", true, false);
            }

            if (answer["status1"]) {
              this.dataService.setAnsweringCall(true);
              this.switchWindow("video", true);
              this.partnerId = event.from;
              this.dataService.setCurrentPartnerId(this.partnerId);
              this.userDetail = this.dataService.getFriendById(this.partnerId);
              if (event.meetingId) {
                this.dataService.setconnectionInProgress("Video");
                this.videoService.startVideoChatting(this.partnerId, event.meetingId, true, answer["status2"]);
              }
              this.dataService.sendStopEvents("StopVideo", { "status": false, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
            } else {
              this.dataService.sendStopEvents("StopVideo", { "status": true, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
            }
          }, (err) => {
            this.dataService.sendStopEvents("StopVideo", { "status": true, "pid": event.from, "uid": this.dataService.getLoggedInUser().uid });
          });
        } else if (event.msg === "ReceivedFile") {
          console.log("receive event passing to service", event);
        } else if (event.msg === "updateTextChat") {
          this.watchPeerChat();
          this.scrollTo(null);
        }
      }
    });
  }

  //Supported Languages//
  getSupportedLanguages() {
    return [
      { "code": "ar", "language": "Arabic" },
      { "code": "es", "language": "Spanish" },
      { "code": "hi", "language": "Hindi" },
      { "code": "fr", "language": "French" },
      { "code": "el", "language": "Greek" },
      { "code": "iw", "language": "Hebrew" },
      { "code": "en", "language": "English" }
    ];
  }

  selectedLanguage() {
    // event.preventDefault();
    for (let i = 0; i < this.languages.length; i++) {
      if (this.languages[i].language === this.preferredLanguage) {
        this.langCode = this.languages[i].code;
      }
    }
  }

  valuechange(newValue) {
    this.textMessage = newValue;
  }


  sendText() {
    if (this.textMessage.length <= 1) {
      return;
    } else if (this.isPeerCaller) {
      this.sendTextMessage(this.textMessage, this.dataService.getLoggedInUser().username);
      let messageObject = [
        { "ownerMessage": this.textMessage, "timestamp": Date.now(), "uid": this.dataService.loggedInUser.uid, "pid": this.dataService.getCurrentPartnerId() }
      ];
      this.dataService.saveTextMessages(messageObject, this.isPeerCaller)
        .subscribe((res) => {
          this.textMessage = '';
        }, (err) => { console.log("Error in storing messages : ", err); });
      this.scrollTo(null);
      this.textMessage = '';
    } else {
      this.dataService.sendGroupTextMessage(this.groupDetail.id, this.textMessage);
      let messageObject = [
        {
          "gid": this.groupDetail.id, "ownerMessage": this.textMessage, "timestamp": Date.now(), "uid": this.dataService.loggedInUser.uid,
          "pid": this.dataService.getCurrentPartnerId(), "userProfilePic": this.dataService.getUserProficPic()
        }
      ];
      this.dataService.saveTextMessages(messageObject, this.isPeerCaller)
        .subscribe((res) => {
          this.textMessage = '';
        }, (err) => { console.log("Error in storing messages : ", err); });
      this.scrollTo(null);
      this.textMessage = '';
    }
  }


  sendTextonEnter() {
    if (this.textMessage.length == 1) {
      this.textMessage = '';
      return;
    } else {
      this.sendText();
    }
  }

  sendTextMessage(msg, username) {
    this.dataService.sendTextMessage(msg, this.partnerId);
  }
  /***** Text Chatting End *****/
  //---------------------------//
  /***** File Sharing Start ****/

  public dragFileOverStart() {
  }

  // File being dragged has moved out of the drop region
  public dragFileOverEnd() {
  }
  // File being dragged has been dropped and is valid

  dragedFileName: any;
  fileSize: any;

  dragFileAccepted(aFile: Ng2FileDropAcceptedFile) {
    let acceptedFile = aFile['acceptedFile'];
    let dragedFileName = acceptedFile.name;
    let fSize = acceptedFile.size;
    this.dataService.setDrpoFile(acceptedFile, false);

    if (this.isPeerCaller) {
      this.dataService.setSTexChatMessage("urs", this.partnerId, {
        timeStamp: new Date(),
        message: {
          message: 'file sent',
          from: this.dataService.getLoggedInUser().uid
        }, dragedFileName: dragedFileName, fileSize: fSize, fIcon: 'glyphicon glyphicon-file iconSize'
      });
      this.dataService.startFileSharing(this.isPeerCaller);
    } else {
      let fileInfo = {
        "mediaLink": undefined,
        "name": acceptedFile.name,
        "dragedFileName": dragedFileName,
        "fIcon": 'glyphicon glyphicon-file iconSize',
        "fileSize": fSize
      }
      this.dataService.updateGroupChatMessageWithFile("File Sent", this.groupDetail.id,
        this.dataService.getLoggedInUser().uid, fileInfo);
      this.dataService.startFileSharing(this.isPeerCaller);
    }

    let fileName = UUID.UUID(); //Create unique name
    let fileObj = [
      { "name": fileName, "duration": "", "timestamp": Date.now(), "fromUId": this.dataService.loggedInUser.uid, "toUId": this.dataService.getCurrentPartnerId(), "group": { "id": "" } }
    ];
    //console.log("chat.ts " + fileObj);
    this.dataService.fileUpload(acceptedFile, fileObj, fileName, this.isPeerCaller);
  }


  sharedFile: any;

  sendFileAttachment(e) {
    let acceptedFile = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    this.sharedFile = acceptedFile;
    let dragedFileName = acceptedFile.name;
    let fSize = Math.floor((acceptedFile.size) / 1024);
    this.dataService.setDrpoFile(acceptedFile, false);
    let loggedInUserProfilePic = this.dataService.getUserProficPic();

    if (this.isPeerCaller) {
      this.dataService.setSTexChatMessage("urs", this.partnerId, {
        timeStamp: new Date(),
        message: {
          message: 'file sent',
          from: this.dataService.getLoggedInUser().uid,
          userProfilePic: loggedInUserProfilePic
        }, dragedFileName: dragedFileName, fileSize: fSize, fIcon: 'glyphicon glyphicon-file iconSize'
      });
      this.dataService.startFileSharing(this.isPeerCaller);
    } else {
      let fileInfo = {
        "mediaLink": undefined,
        "name": acceptedFile.name,
        "dragedFileName": dragedFileName,
        "fIcon": 'glyphicon glyphicon-file iconSize',
        "fileSize": fSize
      }
      this.dataService.updateGroupChatMessageWithFile("File Sent", this.groupDetail.id,
        this.dataService.getLoggedInUser().uid, fileInfo);
      this.dataService.startFileSharing(this.isPeerCaller);
    }

    let fileName = UUID.UUID(); //Create unique name
    let fileObj = [
      {
        "name": fileName, "duration": "", "timestamp": Date.now(),
        "mediaLink": "", "originalName": acceptedFile.name, "fileSize": fSize,
        "fromUId": this.dataService.loggedInUser.uid, "toUId": this.dataService.getCurrentPartnerId(), "group": { "id": "" }
      }
    ];
    this.dataService.fileUpload(acceptedFile, fileObj, fileName, this.isPeerCaller);
  }

  // File being dragged has been dropped and has been rejected
  private dragFileRejected(rejectedFile: Ng2FileDropRejectedFile) {
  }
  dynamicFile: any;
  mydata: any;
  private receivedFile: any = {};
  /***** File Sharing Start ****/


  downloadFile(file) {
    var url = window.URL;
    var a = document.createElement("a");
    a.href = file;
    a.download = this.dataService.getMetaData().name;
    a.target = "_self";
    a.click();
    url.revokeObjectURL(file);
  }


  startFileSharing(meetingId) {
    this.FileWebRTC = null;
    this.FileWebRTC = new SimpleWebRTC({
      localVideoEl: "",
      remoteVideosEl: "",
      debug: false,
      media: { video: false, audio: false }
    });

    this.FileWebRTC.joinRoom(meetingId);
    this.FileWebRTC.on("createdPeer", peer => {
      //console.log("createdPeer", peer);

      const div = this.renderer.createElement("div");
      const input = this.renderer.createElement("input");
      this.renderer.appendChild(div, input);
      this.renderer.addClass(div, "container");

      this.renderer.setAttribute(input, "type", "file");
      this.renderer.setAttribute(input, "class", "btn btn-sm btn-info");
      this.renderer.appendChild(this.el.nativeElement, div);

      this.renderer.listen(input, "change", event => {
        //console.log(event.target.files[0]);
        this.renderer.setAttribute(input, "disabled", "true");
        let file = event.target.files[0];
        let sender = peer.sendFile(file);
      });

      if (this.droppedFile) {
        //console.log("peer send->", this.droppedFile.acceptedFile);
        let sender = peer.sendFile(this.droppedFile.acceptedFile);
      }

      // receiving an incoming filetransfer
      peer.on("fileTransfer", (metadata, receiver) => {
        //console.log("incoming filetransfer", metadata.name, metadata);
        receiver.on("progress", bytesReceived => {
          const progress = this.renderer.createElement("progress");
          this.renderer.appendChild(div, progress);
          this.renderer.setAttribute(
            progress,
            "class",
            "progress-bar progress-bar-primary"
          );
          this.renderer.setAttribute(progress, "value", bytesReceived);
          this.renderer.setAttribute(progress, "max", metadata.size);
          this.renderer.setStyle(progress, "margin", "1%");
          console.log(
            "receive progress",
            bytesReceived,
            "out of",
            metadata.size
          );
        });
        // get notified when file is done
        receiver.on("receivedFile", (file, metadata) => {
          //console.log("received file", metadata.name, metadata.size);
          const anchor = this.renderer.createElement("a");
          const textNode = this.renderer.createText("Download");
          this.renderer.appendChild(anchor, textNode);
          this.renderer.appendChild(div, anchor);
          this.renderer.setAttribute(anchor, "href", URL.createObjectURL(file));
          this.renderer.setAttribute(anchor, "download", metadata.name);
          this.renderer.setAttribute(anchor, "class", "btn btn-sm btn-success");
          // close the channel
          receiver.channel.close();
        });
      });
    });
  }
  //----Prem File Share End---//

  //---------Video Chatting Start-----//
  checkVideoStatus: boolean = true;
  hideElement: boolean = true;

  makeVideoChat() {
    this.dataService.setAnsweringCall(false);
    this.switchWindow("video", true);
    this.callerModel("video", true, "Video Calling To " + this.userDetail.username + ".....");
    clearTimeout(this.clearCallingtime);
    this.clearCallingtime = setTimeout(() => { this.callerModel(null, false, null); this.stopVideoChat(); }, this.callingTime);

    if (this.isPeerCaller) {
      this.dataService.getUserById(this.dataService.getCurrentPartnerId()).subscribe(
        (res) => {
          this.partnerInfo = res;
          if (this.partnerInfo.userStatus.userStatusId === 3) {
            // alert("User is now busy. Please try after sometime.");
            this.toasterService.pop("warning", "User is now busy. Please try after sometime.");
          } else {
            this.dataService.setconnectionInProgress("Video");
            this.dataService.setOngoingVedioPartenerId(this.partnerId);
            this.meetingId = this.dataService.startVideoChatting(this.isPeerCaller);
            this.videoService.startVideoChatting(this.partnerId, this.meetingId, this.isPeerCaller, true);
          }
        }, (err) => {
          //console.log(err);
        }
      );
    } else {
      if (this.groupDetail && this.groupDetail.status === 'Active') {
        this.videoService.startVideoChatting(this.groupDetail.id, "Video_" + this.groupDetail.name, this.isPeerCaller, true);
      } else {

        this.dataService.activateGroupChat(this.groupDetail.id, "Video", "Active").subscribe(
          (res) => {
            this.groupDetail = res;
            this.dataService.setconnectionInProgress("VideoGroup");
            this.meetingId = this.dataService.startVideoChatting(this.isPeerCaller);
            this.videoService.startVideoChatting(this.groupDetail.id, "Video_" + this.groupDetail.name, this.isPeerCaller, true);
          }, (err) => {
            //console.log(err);
          }
        );
      }
    }
  }

  backToMainPage() {
    this.openVideoChat = false;
    this.openScreenShare = false;
    // this.hideElement = true;
    this.checkVideoStatus = false;
  }

  moveToVideoFrame() {
    this.checkVideoStatus = true;
    this.openTextChat = false;
    this.openVideoChat = true;
    this.openScreenShare = false;
    //console.log("Video MeetingId->", this.meetingId);
  }

  stopVideoChat() {
    this.switchWindow("video", false);
  }
  //---------Video Chatting End-----//

  //------Audio Chatting Start ----//
  makeAudioChat() {
    this.dataService.setAnsweringCall(false);
    this.switchWindow("audio", true);
    this.callerModel("audio", true, "Audio Calling To " + this.userDetail.username + ".....");
    clearTimeout(this.clearCallingtime);
    this.clearCallingtime = setTimeout(() => { this.callerModel(null, false, null); this.stopAudioChat(); }, this.callingTime);
    //---status Merged--Prem--start//
    if (this.isPeerCaller) {
      this.dataService.getUserById(this.dataService.getCurrentPartnerId()).subscribe(
        (res) => {
          this.partnerInfo = res;
          if (this.partnerInfo.userStatus.userStatusId === 3) {
            alert("User is now busy. Please try after sometime.");
          } else {
            this.dataService.setconnectionInProgress("Audio");
            this.meetingId = this.dataService.startAudioChatting(this.isPeerCaller);
            this.audioService.startAudioChatting(this.partnerId, this.meetingId, this.isPeerCaller);
            this.openTextChat = false;
            this.openVideoChat = false;
            this.openScreenShare = false;
            this.openAudioChat = true;
          }
        }, (err) => {
          //console.log(err);
        }
      );
    } else {
      //service to activate group chat
      if (this.groupDetail && this.groupDetail.status === 'Active') {
        this.audioService.startAudioChatting(this.groupDetail.id, "Audio_" + this.groupDetail.name, this.isPeerCaller);
      }
      else {
        //service to activate group chat
        this.dataService.activateGroupChat(this.groupDetail.id, "Audio", "Active").subscribe(
          (res) => {
            // this.dataService.setCurrentGroup(res);
            this.groupDetail = res;
            // console.log("Updated One group=>", this.groupDetail);
            this.dataService.setconnectionInProgress("AudioGroup");
            this.meetingId = this.dataService.startAudioChatting(this.isPeerCaller);
            this.audioService.startAudioChatting(this.groupDetail.id, "Audio_" + this.groupDetail.name, this.isPeerCaller);
          }, (err) => {
            //console.log(err);
          }
        );
      }
    }
    //---status Merged--Prem--end//

    //====>``VK`` Previous Version//
    //----
    // if (this.isPeerCaller) {
    //   this.dataService.setconnectionInProgress("Audio");
    //   this.meetingId = this.dataService.startAudioChatting(this.isPeerCaller);
    //   this.audioService.startAudioChatting(this.partnerId, this.meetingId, this.isPeerCaller);
    // } else {
    //   this.dataService.setconnectionInProgress("AudioGroup");
    //   this.meetingId = this.dataService.startAudioChatting(this.isPeerCaller);
    //   this.audioService.startAudioChatting(this.groupDetail.id, "Audio_" + this.groupDetail.name, this.isPeerCaller);
    // }
  }

  stopAudioChat() {
    this.spinnerService.hide();
    this.switchWindow("audio", false);
  }
  //------Audio Chatting End-------//
  //--------Screen Share Start -----------//
  startScreenShare() {
    this.screenService.setAnsweringCall(false);
    this.switchWindow("screen", true);
    this.callerModel("screen", true, "Screen Sharing Requesting To " + this.userDetail.username + ".....");
    clearTimeout(this.clearCallingtime);
    this.clearCallingtime = setTimeout(() => { this.callerModel(null, false, null); this.stopScreenSharing(); }, this.callingTime);
    //--status merged prem --start--//
    if (this.isPeerCaller) {
      this.dataService.getUserById(this.dataService.getCurrentPartnerId()).subscribe(
        (res) => {
          this.partnerInfo = res;
          if (this.partnerInfo.userStatus.userStatusId === 3) {
            alert("User is now busy. Please try after sometime.");
          } else {
            let meetingId = this.dataService.startScreenSharing(this.isPeerCaller);
            this.dataService.setconnectionInProgress("Screen");
            this.screenService.startScreenSharing(meetingId, this.isPeerCaller, true);
            // this.openTextChat = false;
            // this.openVideoChat = false;
            // this.openAudioChat = false;
            // this.openScreenShare = true;
            // this.dataService.setAnsweringCall(false);
          }
        }, (err) => {
          //console.log(err);
        }
      );
    } else {
      if (this.groupDetail && this.groupDetail.status === 'Active') {
        this.screenService.startScreenSharing("Screen_" + this.groupDetail.name, this.isPeerCaller, true);
      } else {
        //service to activate group chat
        this.dataService.activateGroupChat(this.groupDetail.id, "Screen", "Active").subscribe(
          (res) => {
            this.groupDetail = res;
            //console.log("Updated One group for Screen Sharing.=>", this.groupDetail);
            this.dataService.startScreenSharing(this.isPeerCaller);
            this.dataService.setconnectionInProgress("ScreenGroup");
            this.screenService.startScreenSharing("Screen_" + this.groupDetail.name, this.isPeerCaller, true);
          }, (err) => {
            //console.log(err);
          }
        );
      }
    }
    //--status merged prem --end--//

    //====>``VK`` Previous Version//
    // if (this.isPeerCaller) {
    //   let meetingId = this.dataService.startScreenSharing(this.isPeerCaller);
    //   this.dataService.setconnectionInProgress("Screen");
    //   this.screenService.startScreenSharing(meetingId, this.isPeerCaller, true);
    // } else {
    //   this.dataService.startScreenSharing(this.isPeerCaller);
    //   this.dataService.setconnectionInProgress("ScreenGroup");
    //   this.screenService.startScreenSharing("Screen_" + this.groupDetail.name, this.isPeerCaller, true);
    // }
  }


  stopScreenSharing() {
    this.switchWindow("screen", false);
  }
  //--------Screen Share End -------------//

  logout() {
    this.dataService.closebaseWebRTC();
    if (this.timer1Subscribe && this.timer2Subscribe) {
      this.timer1Subscribe.unsubscribe();
      this.timer2Subscribe.unsubscribe();
    }
    this.dataService.updateUserStatus(this.loggedInUser.uid, this.offlineStatusId).subscribe(
      (res) => {
        //console.log(res);
      }, (err) => {
        //console.log(err);
      }
    );
    localStorage.removeItem("token");
    localStorage.removeItem("access_token");
    localStorage.removeItem("peerConnectionConfig");
    this.router.navigate(["/login"]);
  }

  callerModel(type, status, msg) {
    let model = document.getElementById("answerModel");
    if (status) {
      this.audio = new Audio('assets/sounds/tune.mp3');
      this.audio.play();
      model.style.display = "block";
      document.getElementById("answerText").innerHTML = msg;
      document.getElementById("answerBoth").style.display = "none";
      document.getElementById("answerYes").style.display = "none";
      document.getElementById("answerNo").style.marginLeft = "40%";
      document.getElementById("answerNo").onclick = () => {
        this.audio.pause();
        model.style.display = "none";
        if (type === "audio") {
          if (this.isPeerCaller) {
            this.dataService.sendStopEvents("StopAudio", { "status": false, "pid": this.partnerId, "uid": this.dataService.getLoggedInUser().uid });
            this.stopAudioChat();
          } else {
            this.dataService.sendStopEvents("StopAudio", { "type": "self", "status": false, "gid": this.dataService.getCurrGroupID(), "uid": this.dataService.getLoggedInUser().uid });
            this.stopAudioChat();
          }
        } else if (type === "video") {
          if (this.isPeerCaller) {
            this.dataService.sendStopEvents("StopVideo", { "status": false, "pid": this.partnerId, "uid": this.dataService.getLoggedInUser().uid });
            this.stopVideoChat();
          } else {
            this.dataService.sendStopEvents("StopVideo", { "type": "self", "status": false, "gid": this.dataService.getCurrGroupID(), "uid": this.dataService.getLoggedInUser().uid });
            this.stopVideoChat();
          }
        } else if (type === "screen") {
          if (this.isPeerCaller) {
            this.dataService.sendStopEvents("StopScreen", { "status": false, "pid": this.partnerId, "uid": this.dataService.getLoggedInUser().uid });
            this.stopScreenSharing();
          } else {
            this.dataService.sendStopEvents("StopScreen", { "type": "self", "status": false, "gid": this.dataService.getCurrGroupID(), "uid": this.dataService.getLoggedInUser().uid });
            this.stopScreenSharing();
          }
        }
        //console.log(this.isPeerCaller);
      };
    } else {
      if (model) {
        model.style.display = "none";
      }
      if (this.audio) { this.audio.pause(); }
    }
  }

  // answerBox(msg, btnText1, btnText2) {
  //   //console.log("answerBox ... ");
  //   this.audio = new Audio('assets/sounds/tune.mp3');
  //   this.audio.play();
  //   return new Promise((resolve, reject) => {
  //     let model = document.getElementById("answerModel");
  //     model.style.display = "block";
  //     document.getElementById("answerText").innerHTML = msg;
  //     document.getElementById("answerBoth").innerHTML = btnText1;
  //     if (btnText2 != null)
  //       document.getElementById("answerYes").innerHTML = btnText2;
  //     else
  //       document.getElementById("answerYes").style.display = "none";
  //     document.getElementById("answerBoth").onclick = () => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": true, "status2": true }); };
  //     document.getElementById("answerYes").onclick = () => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": true, "status2": false }); };
  //     document.getElementById("answerNo").onclick = () => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": false, "status2": false }); };
  //     setTimeout(() => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": false, "status2": true }); }, 15000);
  //   });
  // }

  //changevinod
  answerBox(msg, btnText1, btnText2) {
    this.audio = new Audio('assets/sounds/tune.mp3');
    this.audio.play();
    return new Promise((resolve, reject) => {
      let model = document.getElementById("answerModel");
      model.style.display = "block";
      document.getElementById("answerBoth").style.display = "inline-block";
      document.getElementById("answerYes").style.display = "inline-block";
      document.getElementById("answerText").innerHTML = msg;
      document.getElementById("answerBoth").innerHTML = btnText1;
      if (btnText2 != null)
        document.getElementById("answerYes").innerHTML = btnText2;
      else
        document.getElementById("answerYes").style.display = "none";
      document.getElementById("answerBoth").onclick = () => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": true, "status2": true }); };
      document.getElementById("answerYes").onclick = () => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": true, "status2": false }); };
      document.getElementById("answerNo").onclick = () => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": false, "status2": false }); };
      setTimeout(() => { this.audio.pause(); model.style.display = "none"; resolve({ "status1": false, "status2": true }); }, 15000);
    });
  }

  switchWindow(wind, status) {
    //console.log(">check>>", wind, status);

    this.openChatWindow = true;

    if (wind === "text") {
      if (status) {
        this.openAudioChat = false;
        this.openVideoChat = false;
        this.openScreenShare = false;
        this.openTextChat = true;
        this.callerModel(null, false, null);
      } else {
        //console.log("Coming Soon...");
      }
    } else if (wind === "audio") {
      if (status) {
        this.openTextChat = false;
        this.openVideoChat = false;
        this.openScreenShare = false;
        this.openAudioChat = true;
      } else {
        this.callerModel(null, false, null);
        this.openVideoChat = false;
        this.openAudioChat = false;
        this.openScreenShare = false;
        this.openTextChat = true;
        console.log("Closing..");

        this.audioService.closeAudioChat();
        if (this.groupStatesubscription) {
          console.log("unsubscribing group AUDIO");
          this.groupStatesubscription.unsubscribe();
        }
        this.dataService.setconnectionInProgress("Text");
      }
    } else if (wind === "video") {
      if (status) {
        this.openTextChat = false;
        this.openAudioChat = false;
        this.openScreenShare = false;
        this.openVideoChat = true;
      } else {
        this.callerModel(null, false, null);
        this.checkVideoStatus = true;
        this.openVideoChat = false;
        this.openScreenShare = false;
        this.openScreenShare = false;
        this.openTextChat = true;
        this.videoService.closeVideoChat();
        if (this.groupStatesubscription) {
          this.groupStatesubscription.unsubscribe();
          console.log("unsubscribing group Video");
        }
        this.dataService.setconnectionInProgress("Text");
      }
    } else if (wind === "screen") {
      if (status) {
        this.openTextChat = false;
        this.openAudioChat = false;
        this.openVideoChat = false;
        this.openScreenShare = true;
      } else {
        this.callerModel(null, false, null);
        this.openAudioChat = false;
        this.openVideoChat = false;
        this.openScreenShare = false;
        this.openTextChat = true;
        this.screenService.stopScreenSharing();
        if (this.groupStatesubscription) {
          this.groupStatesubscription.unsubscribe();
          console.log("unsubscribing group screen");
        }
        this.dataService.setconnectionInProgress("Text");
      }
    }
  }

  //Darshan
  checkAudioStatus: boolean = true;

  backToMainPageForAudioCall() {
    this.openAudioChat = false;
    this.checkAudioStatus = false;
  }

  moveToAudioFrame() {
    this.openAudioChat = true;
    this.checkAudioStatus = true;
  }

  openNav() {
    document.getElementById('mySidenav').style.width = '250px';
  }
  closeNav() {
    document.getElementById('mySidenav').style.width = '0';
  }

  public currentWindowInfoUserId: number = 0;
  public currentWindowInfoGroupId: number = 0;
  getWindowInfo() {
    setTimeout(() => {
      let detail = document.getElementById('currentWindowInfo_id');
      if (detail) {
        if (this.isPeerCaller && detail.getAttribute("value")) {
          this.currentWindowInfoUserId = parseInt(detail.getAttribute("value"));
        } else {
          this.currentWindowInfoGroupId = parseInt(detail.getAttribute("value"));
        }
      }
    }, 1000);
  }

  //VK

  private messageLoadingStatus = true;
  public myOldMessages: any = [];
  public groupOldMessages: any = [];
  private firstResult: any = 0;
  private maxSize: any = 0;
  private partnerIdOrGroupId: any = 0;

  private timestampCounter: any = 46; //testing 

  getOldMesseges(partnerIdOrGroupId, isPeerCaller, firstResult, maxSize) {
    this.firstResult = firstResult;
    this.maxSize = maxSize;
    this.partnerIdOrGroupId = partnerIdOrGroupId;

    if (isPeerCaller) {
      if (this.myMessages && this.myMessages.length > 0) {
        for (const key in this.myMessages) {
          this.myOldMessages.push(this.myMessages[key]);
        }
        this.dataService.flushAllTextChats(partnerIdOrGroupId);
        this.myMessages = [];
      }

      if (firstResult == 1) {
        this.myOldMessages = [];
        this.messageLoadingStatus = true;
      }

      this.dataService.getOldMesseges(this.dataService.getLoggedInUser().uid, partnerIdOrGroupId, isPeerCaller, firstResult, maxSize)
        .subscribe((res) => {
          console.log("OldMsgResponse=>", res);
          if (res && res['length']) {
            for (const key in res) {
              let message = {};
              if (res[key]['type'])
                message['type'] = res[key]['type'];

              if (res[key]['ownerMessage']) {
                message['message'] = res[key]['ownerMessage'];
                message['username'] = this.dataService.getLoggedInUser().username;
                message['from'] = +res[key]['uid'];

                if (res[key]['type'] && res[key]['type'] == "file") {
                  let ownnerMsg = JSON.parse(JSON.stringify(res));
                  message['file'] = JSON.parse(ownnerMsg[key].ownerMessage);
                }
              } else {
                message['message'] = res[key]['partnerMessage'];
                let friend = this.dataService.getFriendById(+res[key]['pid']);
                message['username'] = friend['firstname'] + " " + friend['lastname'];
                message['from'] = +res[key]['pid'];

                if (res[key]['type'] && res[key]['type'] == "file") {
                  let partnerMessage = JSON.parse(JSON.stringify(res));
                  message['file'] = JSON.parse(partnerMessage[key].partnerMessage);
                } else {
                  console.log("No PArtner File Type Found");
                }
              }
              //this.myOldMessages.unshift({ timeStamp: res[key]['timestamp'], message: message, date:null });
              this.timestampCounter--; //testing
              if (this.timestampCounter < 10)
                this.myOldMessages.unshift({ timeStamp: "1524" + this.timestampCounter + "03979637", message: message, date: null });
              else
                this.myOldMessages.unshift({ timeStamp: "152" + this.timestampCounter + "03979637", message: message, date: null });

            }

            for (let i = 0; i < this.myOldMessages.length; i++) {
              this.myOldMessages[i]['date'] = null;
              if (i == 0) {
                let date = this.datesConversion(null, this.myOldMessages[i].timeStamp);
                if (date)
                  this.myOldMessages[i]['date'] = date;
              } else {
                let date = this.datesConversion(this.myOldMessages[i - 1].timeStamp, this.myOldMessages[i].timeStamp);
                if (date)
                  this.myOldMessages[i]['date'] = date;
              }
            }

            if (res.length < this.maxSize) {
              this.messageLoadingStatus = false;
              this.scrollTo(null);
              console.log("No More Messages for This Peer !!");
            } else if (res.length == this.maxSize && !(firstResult == 1)) {
              this.messageLoadingStatus = true;
              this.scrollTo(firstResult * 10);
            } else {
              this.scrollTo(null);
            }
            console.log("Array Size : ", this.myOldMessages['length'], this.myOldMessages);

          } else {
            this.messageLoadingStatus = false;
            console.log("No More Messages for This Peer !!");
          }
        }, (err) => { console.log("Error in fetching messages for Peer : ", err); });
    } else {

      if (this.groupChatMessages && this.groupChatMessages.length > 0) {
        for (const key in this.groupChatMessages) {
          this.groupOldMessages.push(this.groupChatMessages[key]);
        }
        this.dataService.flushAllGroupChat(partnerIdOrGroupId);
        this.groupChatMessages = [];
      }

      if (firstResult == 1) {
        this.groupOldMessages = [];
        this.messageLoadingStatus = true;
      }

      this.dataService.getOldMesseges(partnerIdOrGroupId, null, isPeerCaller, firstResult, maxSize)
        .subscribe((res) => {
          if (res && res['length']) {
            console.log("res size : ", res['length'])
            for (const key in res) {
              let message = {};

              if (res[key]['type']) {
                message['type'] = res[key]['type'];
                if (res[key]['type'].includes("missed") && +res[key]['uid'] == this.dataService.getLoggedInUser().uid) {
                  message['message'] = this.messagesConversion(res[key]['type']);
                } else if (res[key]['type'] == "file") {
                  let ownnerMsg = JSON.parse(JSON.stringify(res));
                  message['file'] = JSON.parse(ownnerMsg[key].ownerMessage);
                } else {
                  message['message'] = res[key]['ownerMessage'];
                }
              } else {
                message['message'] = res[key]['ownerMessage'];
              }
              message['from'] = +res[key]['uid'];
              message['to'] = +res[key]['group'];

              let groupUsers = this.dataService.getGroup(+res[key]['gid'])['users'];
              if (groupUsers) {
                for (const userKey in groupUsers) {
                  if (groupUsers[userKey]['userId'] === +res[key]['uid']) {
                    message['username'] = groupUsers[userKey]['firstName'] + " " + groupUsers[userKey]['lastName'];
                    if (groupUsers[userKey].userImages) {
                      groupUsers[userKey].userImages.forEach(element => {
                        if (element.selectedAsDP) {
                          message['userProfilePic'] = this.cloudImageUrl + element.imageName;
                        }
                      });
                    } else {
                      message['userProfilePic'] = res[key]['userProfilePic'];
                    }
                    break;
                  }
                }
              } else {
                message['username'] = 'Unknown';
              }

              this.groupOldMessages.unshift({ timeStamp: res[key]['timestamp'], message: message });
            }

            for (let i = 0; i < this.groupOldMessages.length; i++) {
              this.groupOldMessages[i]['date'] = null;
              if (i == 0) {
                let date = this.datesConversion(null, this.groupOldMessages[i].timeStamp);
                if (date)
                  this.groupOldMessages[i]['date'] = date;
              } else {
                let date = this.datesConversion(this.groupOldMessages[i - 1].timeStamp, this.groupOldMessages[i].timeStamp);
                if (date)
                  this.groupOldMessages[i]['date'] = date;
              }
            }

            if (res.length < this.maxSize) {
              this.messageLoadingStatus = false;
              console.log("No More Messages for This Group !!");
            } else if (res.length == this.maxSize && !(firstResult == 1)) {
              this.messageLoadingStatus = true;
              this.scrollTo(firstResult * 10);
            } else {
              this.scrollTo(null);
            }
            console.log("Array Size : ", this.groupOldMessages['length']);

          } else {
            this.messageLoadingStatus = false;
            console.log("No More Messages for This Group !!");
          }
        }, (err) => { console.log("Error in fetching messages : ", err); });
    }
  }

  private isScrolling: any;

  chatWindowScoll() {
    this.scrollToBottomStatus = true;
    if (this.isScrolling !== null) {
      clearTimeout(this.isScrolling);
    }
    this.isScrolling = setTimeout(() => {
      this.scrollToBottomStatus = true;
    }, 500);

    if (this.isPeerCaller) {
      if (this.messageLoadingStatus && document.getElementById('windowForPeerMessages') && document.getElementById('windowForPeerMessages').scrollTop) {
        const scrollPosition = document.getElementById('windowForPeerMessages').scrollTop;
        if (scrollPosition <= 50) {
          this.getOldMesseges(this.partnerIdOrGroupId, this.isPeerCaller, ++this.firstResult, this.maxSize);
          console.log("Current Scroll ------unshift()----> : ", scrollPosition);
          this.messageLoadingStatus = false;
        }
      }
    } else {
      if (this.messageLoadingStatus && document.getElementById('windowForGroupMessages') && document.getElementById('windowForGroupMessages').scrollTop) {
        const scrollPosition = document.getElementById('windowForGroupMessages').scrollTop;
        if (scrollPosition <= 50) {
          this.getOldMesseges(this.partnerIdOrGroupId, this.isPeerCaller, ++this.firstResult, this.maxSize);
          console.log("Current Scroll ------unshift()----> : ", scrollPosition);
          this.messageLoadingStatus = false;
        }
      }
    }
  }

  datesConversion(previousDateTimestame, nextDateTimestame): any {
    let dateFormat;
    let currentDate = new Date();
    let previousDate;
    let nextDate;

    if (!previousDateTimestame) {
      nextDate = new Date(parseInt(nextDateTimestame));
      let days = this.daysDifferenceBetweenTwoDates(currentDate, nextDate);

      if (days != null) {
        if (days == 0) {
          dateFormat = "Today";
        } else if (days == 1) {
          dateFormat = "Yesterday";
        } else {
          let todayDate = new Date(currentDate)
          for (let i = 1; i <= days; i++) {
            todayDate = new Date(todayDate.setDate(todayDate.getDate() - 1));
          }
          dateFormat = "" + this.dayNames[todayDate.getDay()];
        }
      } else {
        dateFormat = "" + this.dayNames[nextDate.getDay()] + ", " + this.monthNames[nextDate.getMonth()] + " " + nextDate.getDate() + ", " + nextDate.getFullYear();
      }

    } else if (previousDateTimestame && nextDateTimestame) {
      previousDate = new Date(parseInt(previousDateTimestame));
      nextDate = new Date(parseInt(nextDateTimestame));

      let days = this.daysDifferenceBetweenTwoDates(nextDate, previousDate);
      if (days && days > 0) {
        let daysDifference = this.daysDifferenceBetweenTwoDates(currentDate, nextDate);

        if (daysDifference != null) {
          if (daysDifference == 0) {
            dateFormat = "Today";
          } else if (daysDifference == 1) {
            dateFormat = "Yesterday";
          } else {
            let todayDate = new Date(currentDate)
            for (let i = 1; i <= daysDifference; i++) {
              todayDate = new Date(todayDate.setDate(todayDate.getDate() - 1));
            }
            dateFormat = "" + this.dayNames[todayDate.getDay()];
          }
        } else {
          dateFormat = "" + this.dayNames[nextDate.getDay()] + ", " + this.monthNames[nextDate.getMonth()] + " " + nextDate.getDate() + ", " + nextDate.getFullYear();
        }

      }
    }

    // console.log("day dateFormat : ", dateFormat)
    return dateFormat;
  }

  daysDifferenceBetweenTwoDates(date1, date2): any {
    let days = -1;
    let start = null;
    let end = null;

    start = new Date(date2);
    start.setHours(0, 0, 0, 0);
    end = new Date(date1);
    end.setHours(0, 0, 0, 0);

    while (start <= end) {
      //  console.log("Loop Date :: ", start.getDate())
      days++;
      if (days > 6) {
        days = null;
        break;
      }
      start = new Date(start.setDate(start.getDate() + 1));
    }

    // console.log("Total Days : ", days)

    if (days >= 0 && days <= 6) {
      return days;
    }

    return null;
  }

  private scrollToBottomStatus: any;
  private intervalForscroller: any;

  scrollTo(pixels) {
    this.scrollToBottomStatus = pixels;
    if (pixels) {
      if (this.isPeerCaller) {
        document.getElementById("windowForPeerMessages").scrollTo(0, pixels);
      } else {
        document.getElementById("windowForGroupMessages").scrollTo(0, pixels);
      }
    } else if (!this.intervalForscroller) {
      let timer = Observable.timer(100, 1000);
      this.intervalForscroller = timer.subscribe(t => {
        if (!this.scrollToBottomStatus) {
          if (document.getElementById("windowForPeerMessages")) {
            document.getElementById("windowForPeerMessages").scrollTo(0, document.getElementById("windowForPeerMessages").scrollHeight);
          }

          if (document.getElementById("windowForGroupMessages")) {
            document.getElementById("windowForGroupMessages").scrollTo(0, document.getElementById("windowForGroupMessages").scrollHeight);
          }
        }
      });
    }
  }

  watchPeerChat() {
    let data = this.dataService.getSTextChats(this.partnerId);

    if (data && data.messages && data.messages.length > 0) {
      this.myMessages = data.messages;
      for (let i = 0; i < this.myMessages.length; i++) {
        if (this.langCode) {
          if (this.myMessages[i].message.to == this.loggedInUser.uid) {
            this.dataService.translateMessageText(this.myMessages[i].message.message, this.langCode).subscribe(
              (res) => {
                this.myMessages[i].message.message = res['data'].translations[0].translatedText;
              },
              (err) => {
                //console.log(err);
              }
            );
          }
        }
      }

      if (this.myOldMessages && this.myOldMessages.length > 0) {
        let status = false;
        for (let i = this.myOldMessages.length - 1; i >= 0; i--) {
          if (this.myOldMessages[i].date) {
            if (this.myOldMessages[i].date == "Today") {
              status = true;
            }
            break;
          }
        }
        if (!status) {
          this.myMessages[0]["date"] = "Today";
        }
      } else {
        this.myMessages[0]["date"] = "Today";
      }
    }
  }

  messagesConversion(callType): any {
    switch (callType) {
      case "audio missed":
        return "Audio call placed, no answer";
      case "video missed":
        return "Video call placed, no answer";
      case "screen missed":
        return "Call placed for screen sharing, no answer";
      default:
        return "Call placed, no answer";
    }
  }

  manageMissedCalls(data, callType, isPeerCaller, action) {
    let messages = [{}];
    messages[0]["timestamp"] = Date.now();

    switch (callType) {
      case "audio missed":
        messages[0]["type"] = "audio missed"
        if (action)
          messages[0]["partnerMessage"] = "Audio call, not answered";
        else
          messages[0]["partnerMessage"] = "Audio call missed";
        break;
      case "video missed":
        messages[0]["type"] = "video missed"
        if (action)
          messages[0]["partnerMessage"] = "Video call, not answered";
        else
          messages[0]["partnerMessage"] = "Video call missed";
        break;
      case "screen missed":
        messages[0]["type"] = "screen missed"
        if (action)
          messages[0]["partnerMessage"] = "Screen sharing request, not answered";
        else
          messages[0]["partnerMessage"] = "Missed call for screen sharing";
        break;
      default:
        console.log("Sorry !! Unknown Call Type For Missed Call......");
        return;
    }

    if (isPeerCaller) {
      messages[0]["uid"] = this.dataService.loggedInUser.uid;
      messages[0]["pid"] = data.from;
      this.dataService.updatePeerMissedCallsMessages(messages[0]["partnerMessage"], data.from, null);
      this.dataService.saveTextMessages(messages, isPeerCaller).subscribe((res) => {
        console.log("Messages for Peer Missed calls have been stored !!");
      }, (err) => { console.log("Error in storing messages : ", err); });

      this.watchPeerChat();
      this.scrollTo(null);
    } else {
      messages[0]["uid"] = data.from;
      messages[0]["pid"] = this.dataService.loggedInUser.uid;
      messages[0]["gid"] = this.dataService.getCurrGroupID();
      messages[0]["ownerMessage"] = messages[0]["partnerMessage"];
      messages[0]["partnerMessage"] = null;
      this.dataService.updateGroupMissedCallsMessages(messages[0]["ownerMessage"], this.dataService.getCurrGroupID(), data.from);
      this.dataService.saveTextMessages(messages, isPeerCaller).subscribe((res) => {
        console.log("Messages for Group Missed calls have been stored !!");
      }, (err) => { console.log("Error in storing messages : ", err); });

      this.watchGroupChat();
      this.scrollTo(null);
    }

    //console.log("data :: ", data)
    //console.log("callType :: ", callType)
    //console.log("isPeerCaller :: ", isPeerCaller)
  }

  managePlaceddCalls(data) {
    let message = "unknown";
    switch (data.msg) {
      case "StopAudio":
        message = "Audio call placed, no answer";
        break;
      case "StopVideo":
        message = "Video call placed, no answer";
        break;
      case "StopScreen":
        message = "Call placed for screen sharing, no answer";
        break;
      default:
        console.log("Sorry !! Unknown Call Type......");
        return;
    }

    if (this.isPeerCaller) {
      this.dataService.updatePeerMissedCallsMessages(message, this.partnerId, this.dataService.getLoggedInUser().uid);
      this.watchPeerChat();
      this.scrollTo(null);
    } else {
      this.dataService.updateGroupMissedCallsMessages(message, this.dataService.getCurrGroupID(), this.dataService.getLoggedInUser().uid);
      this.watchGroupChat();
      this.scrollTo(null);

      console.log("Data... :: ", data)

    }

  }

  private dayNames: any = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  private monthNames: any = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

}
