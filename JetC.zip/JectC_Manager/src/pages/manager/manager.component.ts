import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from '../../services/data/data-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UUID } from 'angular2-uuid';
import { ToasterService } from 'angular2-toaster';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {

  loggedInUser: any = {};
  public form: FormGroup;
  private newImages: any = [];
  private selectedImage: any;
  private selectedImageFileName: any
  private userInfo: any = {};
  public guestUsers: any = [];
  public currentGuestInfo: any = {};
  public allUsers: any;
  public allGuestUsers : any = [];

  constructor(private dataService: DataServiceService, private router: Router, private UUID: UUID,
    private formBuilder: FormBuilder, private spinnerService: Ng4LoadingSpinnerService, private toasterService: ToasterService) {
    this.form = formBuilder.group({
      firstName: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(20), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      lastName: ['', Validators.compose([Validators.maxLength(20), Validators.pattern('[a-zA-Z ]*'), Validators.required])],
      username: ['', Validators.compose([Validators.minLength(6), Validators.maxLength(15), Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      email: ['', Validators.compose([Validators.maxLength(35), Validators.required])],
      contact: ['', Validators.compose([Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[0-9]*'), Validators.required])],
      password: ['', Validators.compose([Validators.minLength(5), Validators.maxLength(16), Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      confirmPassword: ['', Validators.compose([Validators.minLength(5), Validators.maxLength(16), Validators.pattern('[a-zA-Z0-9]*'), Validators.required])]

    });
  }

  ngOnInit() {
    this.getAllUsers();
    this.loggedInUser = this.dataService.getLoggedInUser();
    console.log("LoggedIn =>", this.loggedInUser);
  }

  getAllUsers() {
    this.allGuestUsers = [];
    this.dataService.getGuestUserList().
      subscribe(res => {
        this.allUsers = res;
        this.allUsers.forEach(element => {
         element.userProfiles.forEach(profileElem => {
           console.log("Profile=>",profileElem);
           if(profileElem.type == "GUEST"){
                this.allGuestUsers.push(element);
           }
         });
        });
        console.log("Guest=>", this.allGuestUsers);
      }, err => {
        console.log("All Users err=>", err);
      });
  }

  getGuestUsers(users){

  }

  getImage(event) {
    this.newImages = [];
    this.selectedImageFileName = UUID.UUID();
    this.newImages.push({
      imageName: this.selectedImageFileName,
      selectedAsDP: true
    });
    this.userInfo.newImages = this.newImages;
    this.selectedImage = event.target.files[0];
    console.log("File=>", this.selectedImage);
  }

  onSubmit() {
    this.userInfo.firstName = this.form.value.firstName;
    this.userInfo.lastName = this.form.value.lastName;
    this.userInfo.username = this.form.value.username;
    this.userInfo.email = this.form.value.email;
    this.userInfo.mobile = this.form.value.contact;
    this.userInfo.password = this.form.value.password;
    if (this.form.value.password != this.form.value.confirmPassword) {
      // alert("Password doesn't match !");
      this.toasterService.pop("warning", "Password doesn't match");
    } else {
      this.uploadUserImage();
    }
  }

  onEdit(userId) {
    console.log("Edit User Id=>", userId);
    console.log("Update=>", this.form);
    this.allGuestUsers.forEach(element => {
      if(element.userId == userId){
        console.log("Matched=>", element);
        if(element.userImages){
          this.userInfo.newImages = element.userImages;
        }else{
          this.userInfo.newImages =[];
        }
      }
    });
    this.spinnerService.show();
    this.userInfo.userId = userId;
    this.userInfo.firstName = this.form.value.firstName;
    this.userInfo.lastName = this.form.value.lastName;
    this.userInfo.username = this.form.value.username;
    this.userInfo.email = this.form.value.email;
    this.userInfo.mobile = this.form.value.contact;
    this.userInfo.password = this.form.value.password;
    if (this.form.value.password != this.form.value.confirmPassword) {
      // alert("Password doesn't match !");
      this.toasterService.pop("warning", "Password doesn't match");
    } else {
      //this.uploadUserImage();
      console.log("Edit Data=>", this.userInfo);
      this.dataService.updateUserInfo(this.userInfo)
      .subscribe(res => {
        console.log("updation=>", res);
        this.getAllUsers();
        this.spinnerService.hide();
        this.toasterService.pop("success", "Profile Updated!");
        window.location.reload();
      }, err => {
        console.log("Backend==>", err);
        this.toasterService.pop("warning", "Updation Failed.");
        this.spinnerService.hide();
      });
    }
  }

  cancel() {
    this.form.reset();
    this.userInfo = {};
    this.newImages = [];
  }

  disableGuest(user) {
    console.log("Disable user- >", user);
    this.dataService.disableGuestUser(user.userId)
    .subscribe(res=>{
       console.log("disable res",res);
     this.getAllUsers();
     this.toasterService.pop("success", "User Disabled.");
    },err=>{
      console.log("disable",err);
      this.toasterService.pop("warning", "Something went wrong.");
    });
  }

  uploadUserImage() {
    if (this.selectedImage && this.selectedImageFileName) {
      this.spinnerService.show();
      this.dataService.doUploadOnGoogleCloud(this.selectedImage, this.selectedImageFileName)
        .subscribe(res => {
          console.log("cloudRes=>", res);
          this.submitUserInformation();
        }, err => {
          console.log(err);
        });
    }
  }

  editGuestInfo(userId) {
    console.log("GuestId=>", userId);
    this.allGuestUsers.forEach(element => {
      if (element.userId == userId) {
        this.currentGuestInfo = element;
        console.log("Assigned=>", this.currentGuestInfo);
      }
    });
  }


  submitUserInformation() {
    console.log("Submitting=>", this.userInfo);
    if (this.userInfo) {
      this.dataService.doUserRegistration(this.userInfo)
        .subscribe(res => {
          console.log("DBRes=>", res);
          this.spinnerService.hide();
          this.toasterService.pop("success", "Guest User Registered.");
          this.userInfo = {};
          this.newImages = [];
          this.form.reset();
        }, err => {
          console.log("DBErr=>", err);
          this.spinnerService.hide();
          this.toasterService.pop("warning", "Registration failed.");
          this.userInfo = {};
          this.newImages = [];
          this.form.reset();
        });
    }
  }

  logout() {
    if (localStorage.removeItem("token")) {
      localStorage.removeItem("token");
    }
    this.router.navigate(['/login']);
  }

}
